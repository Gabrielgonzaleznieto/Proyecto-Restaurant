/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.time.LocalDate;

/**
 *
 * @author Usuario
 */
public class Agrega {
  
   private Producto producto;
   private Pedido pedido;
   private int cantidad;
  

   public Agrega(){}
   
   public Agrega(Producto producto,Pedido pedido,int cantidad)
   {
     this.producto=producto;
     this.pedido=pedido;
     this.cantidad=cantidad;
      
   }
   public Agrega(Producto producto,Pedido pedido)
   {
     this.producto=producto;
     this.pedido=pedido;
   }
    
    public Producto getProducto() {
        return producto;
    }

    public void setProducto(Producto producto) {
        this.producto = producto;
    }

    public Pedido getPedido() {
        return pedido;
    }

    public void setPedido(Pedido pedido) {
        this.pedido = pedido;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }
   public String toString(){
    
        return producto.getId_producto()+"-"+pedido.getId_pedido() +"-"+cantidad;
    }
}
