/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;


import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.ArrayList;

/**
 *
 * @author Usuario
 */
public class AgregaData {
private Connection connection = null;


public AgregaData() {
         connection = conexion.getConnection();

}

public int guardarAgrega(Agrega agrega){
    int rta=0;
    int idPoducto=agrega.getProducto().getId_producto();
    try {
        String sql = "INSERT INTO agregado (id_producto,id_pedido,cantidad) VALUES ( ?, ? ,?);";
        PreparedStatement statement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
        statement.setInt(1,idPoducto );
        statement.setInt(2, agrega.getPedido().getId_pedido());
        statement.setInt(3, agrega.getCantidad());
        rta=statement.executeUpdate();
        statement.close();
       }
    catch (SQLException ex) {
        System.out.println("Error al insertar un producto agregado: " + ex.getMessage());}
return rta;
}

public Agrega buscarAgrega(int idProducto,int idPedido){
 Producto producto;
 Pedido pedido;
 Agrega agrega=null;
 try {
        String sql = "SELECT * FROM agregado WHERE id_producto = ? AND id_pedido =?;";
        PreparedStatement statement = connection.prepareStatement(sql);
        statement.setInt(1,idProducto);
        statement.setInt(2,idPedido);
        ResultSet resultSet = statement.executeQuery();
        while(resultSet.next()){
            producto=new Producto(resultSet.getInt("id_producto"));

            pedido=new Pedido(resultSet.getInt("id_pedido"));

            int cantidad=resultSet.getInt("cantidad");
            agrega=new Agrega(producto,pedido,cantidad);
        }     
        statement.close();
 }
catch (SQLException ex) 
    {System.out.println("Error al buscar producto agregado: " + ex.getMessage());}

return agrega;
}


public int actualizarAgrega(Agrega agrega){
int rta=0;
try {
    String sql = "UPDATE agregado SET cantidad=?  WHERE id_producto=? AND id_pedido=? ;";
    PreparedStatement statement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
    statement.setInt(1, agrega.getCantidad());
    statement.setInt(2, agrega.getProducto().getId_producto());
    statement.setInt(3, agrega.getPedido().getId_pedido());
    rta=statement.executeUpdate();
    statement.close();
   }
catch (SQLException ex) {
    System.out.println("Error al actualizar un producto agregado: " + ex.getMessage());}

return rta; 
}



public int borrarAgrega(Agrega agregado){
int idProducto=agregado.getProducto().getId_producto();
int idPedido=agregado.getPedido().getId_pedido();
int rta=0;
try {
     String sql = "DELETE FROM agregado WHERE id_producto=? AND id_pedido=? ;";
     PreparedStatement statement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
     statement.setInt(1, idProducto);
     statement.setInt(2, idPedido);
     rta=statement.executeUpdate();
     statement.close();
    } 
catch (SQLException ex) 
    { System.out.println("Error al borrar un producto agregado: " + ex.getMessage());}
return rta;   
}

public List<Agrega> listarAgregadosPorPedido(int idPedido){
List<Agrega> agregados = new ArrayList<Agrega>();
Agrega agrega=null; 
Producto producto=new Producto();
Pedido pedido=new Pedido();
try {
String sql = "SELECT * FROM agregado WHERE id_pedido=? ;";
PreparedStatement statement = connection.prepareStatement(sql);
statement.setInt(1,idPedido );
ResultSet resultSet = statement.executeQuery();
while(resultSet.next()){
            producto=new Producto(resultSet.getInt("id_producto"));

            pedido=new Pedido(resultSet.getInt("id_pedido"));

            int cantidad=resultSet.getInt("cantidad");
            agrega=new Agrega(producto,pedido,cantidad);
            agregados.add(agrega);
        }   
 statement.close();
} 
catch (SQLException ex) {
System.out.println("Error al obtener los AGREGADOS: " + ex.getMessage());
}
return agregados;
}
public List<Agrega> listarAgregadosPorProducto(int idProducto){
List<Agrega> agregados = new ArrayList<Agrega>();
Agrega agrega=null; 
Producto producto=new Producto();
Pedido pedido=new Pedido();
try {
String sql = "SELECT * FROM agregado WHERE id_producto=? ";
PreparedStatement statement = connection.prepareStatement(sql);
statement.setInt(1,idProducto );
ResultSet resultSet = statement.executeQuery();
while(resultSet.next()){
           producto=new Producto(resultSet.getInt("id_producto"));

            pedido=new Pedido(resultSet.getInt("id_pedido"));

            int cantidad=resultSet.getInt("cantidad");
            agrega=new Agrega(producto,pedido,cantidad);
            agregados.add(agrega);
        }   
 statement.close();
} 
catch (SQLException ex) {
System.out.println("Error al obtener los AGREGADOS: " + ex.getMessage());
}
return agregados;
}
public List<Agrega> listarAgregados(){
List<Agrega> agregados = new ArrayList<Agrega>();
Agrega agrega=null; 
Producto producto=new Producto();
Pedido pedido=new Pedido();
try {
String sql = "SELECT * FROM agregado ;";
PreparedStatement statement = connection.prepareStatement(sql);
ResultSet resultSet = statement.executeQuery();
while(resultSet.next()){
            producto=new Producto(resultSet.getInt("id_producto"));

            pedido=new Pedido(resultSet.getInt("id_pedido"));

            int cantidad=resultSet.getInt("cantidad");
            agrega=new Agrega(producto,pedido,cantidad);
            agregados.add(agrega);
        }   
 statement.close();
} 
catch (SQLException ex) {
System.out.println("Error al obtener los AGREGADOS: " + ex.getMessage());
}
return agregados;
}
  
}
