/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 *
 * @author Usuario
 */
public class Categoria {
private int id_categoria;
private String tarea_desempeniada;
private String tipo_categoria;
private double sueldo;

   
public Categoria(int id_categoria,String tarea_desempeniada, String tipo_categoria,double sueldo){
    this.id_categoria =id_categoria ;
    this.tarea_desempeniada=tarea_desempeniada;    
    this.tipo_categoria=tipo_categoria;
    this.sueldo=sueldo;
  }
public Categoria(String tarea_desempeniada, String tipo_categoria,double sueldo){
    this.tarea_desempeniada=tarea_desempeniada;    
    this.tipo_categoria=tipo_categoria;
    this.sueldo=sueldo;
  }
public Categoria(int id_categoria){
    this.id_categoria =id_categoria ;
   }
public Categoria(){}
  public int getId_categoria() {
        return id_categoria;
    }

    public void setId_categoria(int id_categoria) {
        this.id_categoria = id_categoria;
    }

    public String getTarea_desempeniada() {
        return tarea_desempeniada;
    }

    public void setTarea_desempeniada(String tarea_desempeniada) {
        this.tarea_desempeniada = tarea_desempeniada;
    }

    public String getTipo_categoria() {
        return tipo_categoria;
    }

    public void setTipo_categoria(String tipo_categoria) {
        this.tipo_categoria = tipo_categoria;
    }

    public double getSueldo() {
        return sueldo;
    }

    public void setSueldo(double sueldo) {
        this.sueldo = sueldo;
    }
 public String toString(){
    
        return id_categoria+"-"+tarea_desempeniada+"_"+tipo_categoria;
    }
}
