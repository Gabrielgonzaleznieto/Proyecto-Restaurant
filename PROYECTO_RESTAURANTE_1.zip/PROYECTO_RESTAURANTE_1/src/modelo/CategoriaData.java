/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class CategoriaData {
private Connection connection = null;
    
    public CategoriaData() {
      connection = conexion.getConnection();
    }
    
    public int guardarCategoria(Categoria categoria){
        int rta=0;
        try {
            String sql = "INSERT INTO categoria (tarea_desempeniada,tipo_categoria,sueldo) VALUES ( ?, ?,? );";
            PreparedStatement statement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            statement.setString(1,categoria.getTarea_desempeniada() );
            statement.setString(2,categoria.getTipo_categoria() );
            statement.setDouble(3, categoria.getSueldo() );
            rta=statement.executeUpdate();
            statement.close();
           }
        catch (SQLException ex) {
            System.out.println("Error al insertar una CATEGORIA: " + ex.getMessage());}
    return rta;
    }
    
    public Categoria buscarCategoria(int id){
    Categoria categoria=null;
    try {
        String sql = "SELECT * FROM categoria WHERE id_categoria =?;";
        PreparedStatement statement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
        statement.setInt(1, id);
           
        ResultSet resultSet=statement.executeQuery();
        while(resultSet.next())
        {
           categoria = new Categoria();
           categoria.setId_categoria(resultSet.getInt("id_categoria"));
           categoria.setTarea_desempeniada(resultSet.getString("tarea_desempeniada"));
           categoria.setTipo_categoria(resultSet.getString("tipo_categoria"));
           categoria.setSueldo(resultSet.getDouble("sueldo"));
        }      
        statement.close();
      } 
    catch (SQLException ex) 
        {System.out.println("Error al ingresar una CATEGORIA: " + ex.getMessage());}
    return categoria;
   }
     public Categoria buscarCategoriaTC(String tarea,String tipo){
    Categoria categoria=null;
    try {
        String sql = "SELECT * FROM categoria WHERE tarea_desempeniada =? and tipo_categoria=?;";
        PreparedStatement statement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
        statement.setString(1,tarea);
        statement.setString(2,tipo);
           
        ResultSet resultSet=statement.executeQuery();
        while(resultSet.next())
        {
           categoria = new Categoria();
           categoria.setId_categoria(resultSet.getInt("id_categoria"));
           categoria.setTarea_desempeniada(resultSet.getString("tarea_desempeniada"));
           categoria.setTipo_categoria(resultSet.getString("tipo_categoria"));
           categoria.setSueldo(resultSet.getDouble("sueldo"));
        }      
        statement.close();
      } 
    catch (SQLException ex) 
        {System.out.println("Error al ingresar una CATEGORIA: " + ex.getMessage());}
    return categoria;
   }
public int actualizarCategoria(Categoria categoria){
    int rta=0; 
    try {
          String sql = "UPDATE  categoria SET tarea_desempeniada=? , tipo_categoria=?, sueldo=?   WHERE id_categoria = ?;";
            PreparedStatement statement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            statement.setString(1,categoria.getTarea_desempeniada() );
            statement.setString(2,categoria.getTipo_categoria() );
            statement.setDouble(3, categoria.getSueldo() );
            statement.setInt(4, categoria.getId_categoria() );
            rta=statement.executeUpdate();
            statement.close();
         } 
    catch (SQLException ex) 
           { System.out.println("Error al actualizar una CATEGORIA: " + ex.getMessage());}
    return rta;
   }
public int borrarCategoria(int id){
    int rta=0;
    try {
         String sql = "DELETE FROM categoria WHERE id_categoria =?;";
         PreparedStatement statement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
         statement.setInt(1, id);
         rta=statement.executeUpdate();
         statement.close();
        } 
    catch (SQLException ex) 
        { System.out.println("Error al borrar una CATEGORIA: " + ex.getMessage());}
return rta;   
}
public List<Categoria> listarCategorias(){
List<Categoria> categorias = new ArrayList<Categoria>();
try {
    String sql = "SELECT * FROM categoria;";
    PreparedStatement statement = connection.prepareStatement(sql);
    ResultSet resultSet = statement.executeQuery();
    Categoria categoria;
    while(resultSet.next()){
         categoria = new Categoria();
         categoria.setId_categoria(resultSet.getInt("id_categoria"));
         categoria.setTarea_desempeniada(resultSet.getString("tarea_desempeniada"));
         categoria.setTipo_categoria(resultSet.getString("tipo_categoria"));
         categoria.setSueldo(resultSet.getDouble("sueldo"));
         categorias.add( categoria);
    }      
    statement.close();
  } 
catch (SQLException ex) {
    System.out.println("Error al obtener las  CATEGORIAS: " + ex.getMessage());
   }
 return  categorias;
 }

    
}
