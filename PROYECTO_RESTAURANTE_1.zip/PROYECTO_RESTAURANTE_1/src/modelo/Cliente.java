/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 *
 * @author Usuario
 */
public class Cliente {
   private String dni;
   private String nombre; 
   private String telefono; 
   private String e_mail; 

   public Cliente(){}
   
   public Cliente(String dni,String nombre,String telefono,String e_mail)
   {
     this.dni=dni;
     this.nombre=nombre;
     this.telefono=telefono;
     this.e_mail=e_mail;
   }
   public Cliente(String dni,String nombre)
   {
     this.dni=dni;
     this.nombre=nombre;
   }
    public Cliente(String dni)
   {
     this.dni=dni;
   }
    public String getDni() {
        return dni;
    }

    public String getNombre() {
        return nombre;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
   
    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getE_mail() {
        return e_mail;
    }

    public void setE_mail(String e_mail) {
        this.e_mail = e_mail;
    }
     public String toString(){
    
        return dni+"-"+nombre;
    }
}
