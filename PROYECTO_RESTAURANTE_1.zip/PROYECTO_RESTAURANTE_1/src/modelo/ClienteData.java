/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Usuario
 */
public class ClienteData {
    private Connection connection = null;
    
    public ClienteData() {
      connection = conexion.getConnection();
    }
    
public int guardarCliente(Cliente cliente){
    int rta=0;
    try {
        String sql = "INSERT INTO cliente (dni,nombre,telefono,e_mail) VALUES ( ?, ?,?,? );";
        PreparedStatement statement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
        statement.setString(1, cliente.getDni());
        statement.setString(2, cliente.getNombre());
        statement.setString(3, cliente.getTelefono());
        statement.setString(4, cliente.getE_mail());
        rta=statement.executeUpdate();
        statement.close();
       }
    catch (SQLException ex) {
        System.out.println("Error al insertar un cliente: " + ex.getMessage());}
return rta;
}
public Cliente buscarClienteDni(String dni){
    Cliente cliente=null;
    try {
        String sql = "SELECT * FROM cliente WHERE dni =?;";
        PreparedStatement statement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
        statement.setString(1, dni);
           
        ResultSet resultSet=statement.executeQuery();
        while(resultSet.next())
        {
            cliente = new Cliente();
            cliente.setDni(resultSet.getString("dni"));
            cliente.setNombre(resultSet.getString("nombre"));
            cliente.setTelefono(resultSet.getString("telefono"));
            cliente.setE_mail(resultSet.getString("e_mail"));
           
        }      
        statement.close();
      } 
    catch (SQLException ex) 
        {System.out.println("Error al insertar un cliente: " + ex.getMessage());}
    return cliente;
   }
public Cliente buscarClienteNombre(String nombre){
    Cliente cliente=null;
    try {
        String sql = "SELECT * FROM cliente WHERE nombre =?;";
        PreparedStatement statement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
        statement.setString(1, nombre);
           
        ResultSet resultSet=statement.executeQuery();
        while(resultSet.next())
        {
            cliente = new Cliente();
            cliente.setDni(resultSet.getString("dni"));
            cliente.setNombre(resultSet.getString("nombre"));
            cliente.setTelefono(resultSet.getString("telefono"));
            cliente.setE_mail(resultSet.getString("e_mail"));
        }      
        statement.close();
      } 
    catch (SQLException ex) 
        {System.out.println("Error al insertar un cliente: " + ex.getMessage());}
    return cliente;
   }
public int actualizarCliente(Cliente cliente){
     System.out.println("cliente recibido "+cliente.getDni()+"-"+cliente.getNombre()+"-"+cliente.getTelefono()+"-"+cliente.getE_mail());
    int rta=0;  
    try {
            String sql = "UPDATE cliente SET nombre =? ,telefono=? ,e_mail=?  WHERE dni = ?;";
            PreparedStatement statement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            statement.setString(1, cliente.getNombre());
            statement.setString(2, cliente.getTelefono());
            statement.setString(3, cliente.getE_mail());
            statement.setString(4, cliente.getDni());

            rta=statement.executeUpdate();
            statement.close();
         } 
    catch (SQLException ex) 
           { System.out.println("Error al insertar un cliente: " + ex.getMessage());}
    return rta;
   }
public int borrarCliente(String dni){
    int rta=0;
    try {
         String sql = "DELETE FROM cliente WHERE dni =?;";
         PreparedStatement statement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
         statement.setString(1, dni);
         rta=statement.executeUpdate();
         statement.close();
        } 
    catch (SQLException ex) 
        { System.out.println("Error al insertar un cliente: " + ex.getMessage());}
return rta;   
}
public List<Cliente> listarClientes(){
List<Cliente> clientes = new ArrayList<Cliente>();
try {
    String sql = "SELECT * FROM cliente;";
    PreparedStatement statement = connection.prepareStatement(sql);
    ResultSet resultSet = statement.executeQuery();
    Cliente cliente;
    while(resultSet.next()){
        cliente = new Cliente();
        cliente.setDni(resultSet.getString("dni"));
        cliente.setNombre(resultSet.getString("nombre"));
        cliente.setTelefono(resultSet.getString("telefono"));
        cliente.setE_mail(resultSet.getString("e_mail"));
        clientes.add(cliente);
    }      
    statement.close();
  } 
catch (SQLException ex) {
    System.out.println("Error al obtener los CLIENTES: " + ex.getMessage());
   }
 return clientes;
}
}
