/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.time.LocalDate;

/**
 *
 * @author Usuario
 */
public class Empleado {
   private int id_empleado;
   private String dni;
   private String nombre; 
  // private LocalDate fechaNacimiento; 
   private String refrencias;
   private Categoria categoria;
   private String telefono; 
   private String e_mail; 
   private String contrasenia; 

   public Empleado(int id_empleado,String dni,String nombre,String refrencias,Categoria categoria, String telefono,String e_mail,String contraesnia ){
   this.id_empleado = id_empleado;
   this.dni =dni ;
   this.nombre = nombre;
   //this.fechaNacimiento =fechaNacimiento ;
   this.refrencias =refrencias ;
   this.categoria =categoria ;
   this.telefono =telefono ;
   this.e_mail =e_mail ;
   this.contrasenia = contraesnia;
   
}
 public Empleado(String dni,String nombre,String refrencias,Categoria categoria, String telefono,String e_mail,String contraesnia ){
   this.dni =dni ;
   this.nombre = nombre;
//   this.fechaNacimiento =fechaNacimiento ;
   this.refrencias =refrencias ;
   this.categoria =categoria ;
   this.telefono =telefono ;
   this.e_mail =e_mail ;
   this.contrasenia = contraesnia;
   
}
 
   public Empleado(int id_empleado){
     this.id_empleado =id_empleado ;   
   }
   public Empleado(){}
   
    public int getId_empleado() {
        return id_empleado;
    }

    public void setId_empleado(int id_empleado) {
        this.id_empleado = id_empleado;
    }

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

//    public LocalDate getFechaNacimiento() {
//        return fechaNacimiento;
//    }
//
//    public void setFechaNacimiento(LocalDate fechaNacimiento) {
//        this.fechaNacimiento = fechaNacimiento;
//    }

    public String getRefrencias() {
        return refrencias;
    }

    public void setRefrencias(String refrencias) {
        this.refrencias = refrencias;
    }

    public Categoria getCategoria() {
        return categoria;
    }

    public void setCategoria(Categoria categoria) {
        this.categoria = categoria;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getE_mail() {
        return e_mail;
    }

    public void setE_mail(String e_mail) {
        this.e_mail = e_mail;
    }

    public String getContrasenia() {
        return contrasenia;
    }

    public void setContrasenia(String contrasenia) {
        this.contrasenia = contrasenia;
    }
}
