/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Usuario
 */
public class EmpleadoData {
   private Connection connection = null;
    
     public EmpleadoData() {
      connection = conexion.getConnection();
    }
     
     public int guardarEmpleado(Empleado empleado){
        int rta=0;
        try {
            //String sql = "INSERT INTO empleado (dni,nombre,fechaNacimiento,referencias,id_categoria,telefono,e_mail,contrasenia) VALUES (?,?,?,?,?,?,?,?);";
           String sql = "INSERT INTO empleado (dni,nombre,referencias,id_categoria,telefono,e_mail,contrasenia) VALUES (?,?,?,?,?,?,?);";

            PreparedStatement statement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            statement.setString(1,empleado.getDni() );
            statement.setString(2,empleado.getNombre() );
            statement.setString(3,empleado.getRefrencias());
            statement.setInt(4,empleado.getCategoria().getId_categoria() );
            statement.setString(5,empleado.getTelefono() );
            statement.setString(6,empleado.getE_mail() );
            statement.setString(7,empleado.getContrasenia() );
            rta=statement.executeUpdate();
            statement.close();
           }
        catch (SQLException ex) {
            System.out.println("Error al insertar un EMPLEADO: " + ex.getMessage());}
    return rta;
    }
      public Empleado buscarEmpleado(int id){
      Empleado empleado=null; 
      Categoria categoria;
      try {
            String sql = "SELECT * FROM empleado WHERE id_empleado = ?;";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setInt(1,id);
            ResultSet resultSet = statement.executeQuery();
            while(resultSet.next()){
                int idEmpleado=resultSet.getInt("id_empleado");
                String dni=resultSet.getString("dni");
                String nombre=resultSet.getString("nombre");
               // LocalDate fecha=resultSet.getDate("fechaNacimiento").toLocalDate();
                String referencias=resultSet.getString("referencias");
                int idCategoria= resultSet.getInt("id_categoria");
                categoria=new Categoria(idCategoria);
                String telefono=resultSet.getString("telefono");
                String e_mail=resultSet.getString("e_mail");
                String contrasenia=resultSet.getString("contrasenia");
                
                //empleado=new Empleado(idEmpleado,dni,nombre,fecha,referencias,categoria,telefono,e_mail,contrasenia);
                 empleado=new Empleado(idEmpleado,dni,nombre,referencias,categoria,telefono,e_mail,contrasenia);
            }     
            statement.close();
     }
    catch (SQLException ex) 
        {System.out.println("Error al ingresar un EMPLEADO: " + ex.getMessage());}
 
    return empleado;
   }
      
      public Empleado buscarEmpleadoDni(String dniBuscado){
      Empleado empleado=null; 
      Categoria categoria;
      try {
            String sql = "SELECT * FROM empleado WHERE dni = ?;";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1,dniBuscado);
            ResultSet resultSet = statement.executeQuery();
            while(resultSet.next()){
                int idEmpleado=resultSet.getInt("id_empleado");
                String dni=resultSet.getString("dni");
                String nombre=resultSet.getString("nombre");
                //LocalDate fecha=resultSet.getDate("fechaNacimiento").toLocalDate();
                String referencias=resultSet.getString("referencias");
                int idCategoria= resultSet.getInt("id_categoria");
                categoria=new Categoria(idCategoria);
                String telefono=resultSet.getString("telefono");
                String e_mail=resultSet.getString("e_mail");
                String contrasenia=resultSet.getString("contrasenia");
                
                //empleado=new Empleado(idEmpleado,dni,nombre,fecha,referencias,categoria,telefono,e_mail,contrasenia);
                empleado=new Empleado(idEmpleado,dni,nombre,referencias,categoria,telefono,e_mail,contrasenia);
            }     
            statement.close();
     }
    catch (SQLException ex) 
        {System.out.println("Error al ingresar un EMPLEADO: " + ex.getMessage());}
 
    return empleado;
   }
   public int borrarEmpleado(int id_empleado){
    int rta=0;
    try {
         String sql = "DELETE FROM empleado WHERE id_empleado =?;";
         PreparedStatement statement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
         statement.setInt(1, id_empleado);
         rta=statement.executeUpdate();
         statement.close();
        } 
    catch (SQLException ex) 
        { System.out.println("Error al borrar un EMPLEADO: " + ex.getMessage());}
return rta;   
}
    public int actualizarEmpleado(Empleado empleado){
    int rta=0;
    try {
       //String sql = "UPDATE empleado SET dni=?,nombre=?,fechaNacimiento=?,referencias=?,id_categoria=?,telefono=?,e_mail=?,contrasenia=? WHERE id_empleado=?;";
       String sql = "UPDATE empleado SET dni=?,nombre=?,referencias=?,id_categoria=?,telefono=?,e_mail=?,contrasenia=? WHERE id_empleado=?;";
 
        PreparedStatement statement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
        statement.setString(1,empleado.getDni() );
        statement.setString(2,empleado.getNombre() );
        //statement.setDate(3,Date.valueOf(empleado.getFechaNacimiento()));
        statement.setString(3,empleado.getRefrencias());
        statement.setInt(4,empleado.getCategoria().getId_categoria() );
        statement.setString(5,empleado.getTelefono() );
        statement.setString(6,empleado.getE_mail() );
        statement.setString(7,empleado.getContrasenia() );
        statement.setInt(8,empleado.getId_empleado() );
        rta=statement.executeUpdate();
        statement.close();
       }
    catch (SQLException ex) {
        System.out.println("Error al actualizar un EMPLEADO: " + ex.getMessage());}
    
return rta; 
 }
public List<Empleado> listarEmpleado(){
List<Empleado> empleados = new ArrayList<Empleado>();
Empleado empleado =null; 
Categoria categoria;
try {
    String sql = "SELECT * FROM empleado;";
    PreparedStatement statement = connection.prepareStatement(sql);
    ResultSet resultSet = statement.executeQuery();
    while(resultSet.next()){
               int idEmpleado=resultSet.getInt("id_empleado");
                String dni=resultSet.getString("dni");
                String nombre=resultSet.getString("nombre");
                //LocalDate fecha=resultSet.getDate("fechaNacimiento").toLocalDate();
                String referencias=resultSet.getString("referencias");
                int idCategoria= resultSet.getInt("id_categoria");
                categoria=new Categoria(idCategoria);
                String telefono=resultSet.getString("telefono");
                String e_mail=resultSet.getString("e_mail");
                String contrasenia=resultSet.getString("contrasenia");
                
                //empleado=new Empleado(idEmpleado,dni,nombre,fecha,referencias,categoria,telefono,e_mail,contrasenia);
                empleado=new Empleado(idEmpleado,dni,nombre,referencias,categoria,telefono,e_mail,contrasenia);
                empleados.add(empleado);
            }     
            statement.close();
    
  } 
  catch (SQLException ex) {
    System.out.println("Error al obtener los EMPLEADOS: " + ex.getMessage());
   }
  return empleados;
 }
}
