/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

public class Mesa {
    private int id_mesa;
    private int cantidad;
    private boolean ocupada;
    private Empleado empleado;

   
    
     public Mesa(int id_mesa, int cantidad, boolean ocupada,Empleado empleado)
    {
        this.id_mesa = id_mesa;
        this.cantidad = cantidad;
        this.ocupada = ocupada;
        this.empleado=empleado;
    }

    public Mesa(int cantidad, boolean ocupada,Empleado empleado)
    {
        this.cantidad = cantidad;
        this.ocupada = ocupada;
        this.empleado=empleado;
    }
    public Mesa(int cantidad, boolean ocupada)
    {
        this.cantidad = cantidad;
        this.ocupada = ocupada;
    }
    public Mesa(int id_mesa)
    {
        this.id_mesa = id_mesa;
    }
    public Mesa(){}
   
    public int getId_mesa() {
        return id_mesa;
    }

    public void setId_mesa(int id_mesa) {
        this.id_mesa = id_mesa;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }
 
    public boolean getOcupada() {
        return ocupada;
    }

    public void setOcupada(boolean ocupada) {
        this.ocupada = ocupada;
    }
     public Empleado getEmpleado() {
        return empleado;
    }

    public void setEmpleado(Empleado empleado) {
        this.empleado = empleado;
    }
    public String toString(){
    
        return id_mesa+"-"+cantidad;
    }
}
