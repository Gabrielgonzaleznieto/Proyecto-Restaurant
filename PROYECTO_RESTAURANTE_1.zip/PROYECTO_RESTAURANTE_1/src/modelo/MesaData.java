/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Usuario
 */
public class MesaData {
    private Connection connection = null;
    EmpleadoData empleadoData;
   
    
    public MesaData() {
        connection = conexion.getConnection();
        empleadoData=new EmpleadoData();
    }
    
    public int guardarMesa(Mesa mesa){
        int rta=0;
        try {
            String sql = "INSERT INTO mesa (cantidad,ocupada,id_empleado) VALUES ( ?, ?,? );";
            PreparedStatement statement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            statement.setInt(1, mesa.getCantidad());
            statement.setBoolean(2, mesa.getOcupada());
            statement.setInt(3, mesa.getEmpleado().getId_empleado() );
            rta=statement.executeUpdate();
            statement.close();
           }
        catch (SQLException ex) {
            System.out.println("Error al insertar una mesa: " + ex.getMessage());}
    return rta;
    }
public Mesa buscarMesa(int id_mesa){
    Mesa mesa=null;
    
    Empleado empleado;
     try {
        String sql = "SELECT * FROM mesa WHERE id_mesa =?;";
        PreparedStatement statement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
        statement.setInt(1, id_mesa);
           
        ResultSet resultSet=statement.executeQuery();
        while(resultSet.next())
        {
            mesa = new Mesa();
            mesa.setId_mesa(resultSet.getInt("id_mesa"));
            mesa.setCantidad(resultSet.getInt("cantidad"));
            mesa.setOcupada(resultSet.getBoolean("ocupada"));
             empleado=empleadoData.buscarEmpleado(resultSet.getInt("id_empleado"));
            mesa.setEmpleado(empleado);
        }      
        statement.close();
      } 
    catch (SQLException ex) 
        {System.out.println("Error al insertar una mesa: " + ex.getMessage());}
    return mesa;
   }
public List<Mesa> buscarMesasCantidad(int cantidadBuscada){
    List<Mesa> mesas = new ArrayList<Mesa>();
     Empleado empleado;
    try {
        String sql = "SELECT * FROM mesa where cantidad=cantidadBuscada;";
        PreparedStatement statement = connection.prepareStatement(sql);
        ResultSet resultSet = statement.executeQuery();
        Mesa mesa;
        while(resultSet.next()){
            mesa = new Mesa();
            mesa.setId_mesa(resultSet.getInt("id_mesa"));  
            mesa.setCantidad(resultSet.getInt("cantidad"));
            mesa.setOcupada(resultSet.getBoolean("ocupada"));
             empleado=empleadoData.buscarEmpleado(resultSet.getInt("id_empleado"));
            mesa.setEmpleado(empleado);
            mesas.add(mesa);
        }      
        statement.close();
        } 
    catch (SQLException ex) 
       {System.out.println("Error al obtener las mesas: " + ex.getMessage());}
    return mesas;
   }
public List<Mesa> listarMesas(){
    List<Mesa> mesas = new ArrayList<Mesa>();
    Empleado empleado;
    try {
        String sql = "SELECT * FROM mesa ;";
        PreparedStatement statement = connection.prepareStatement(sql);
        ResultSet resultSet = statement.executeQuery();
        Mesa mesa;
        while(resultSet.next()){
            mesa = new Mesa();
            mesa.setId_mesa(resultSet.getInt("id_mesa"));
            mesa.setCantidad(resultSet.getInt("cantidad"));
            mesa.setOcupada(resultSet.getBoolean("ocupada"));
              empleado=empleadoData.buscarEmpleado(resultSet.getInt("id_empleado"));
            mesa.setEmpleado(empleado);
            mesas.add(mesa);
        }      
        statement.close();
        } 
    catch (SQLException ex) 
       {System.out.println("Error al obtener las MESAS: " + ex.getMessage());}
    return mesas;
   }


public List<Mesa> listarMesasSegunEstado(boolean ocupada){
    List<Mesa> mesas = new ArrayList<Mesa>();
    Empleado empleado;
    try {
        String sql = "SELECT * FROM mesa WHERE ocupada=?;";
        PreparedStatement statement = connection.prepareStatement(sql);
        statement.setBoolean(1,ocupada);
        ResultSet resultSet = statement.executeQuery();
        Mesa mesa;
        while(resultSet.next()){
            mesa = new Mesa();
            mesa.setId_mesa(resultSet.getInt("id_mesa"));
            mesa.setCantidad(resultSet.getInt("cantidad"));
            mesa.setOcupada(resultSet.getBoolean("ocupada"));
               empleado=empleadoData.buscarEmpleado(resultSet.getInt("id_empleado"));
            mesa.setEmpleado(empleado);
            mesas.add(mesa);
        }      
        statement.close();
        } 
    catch (SQLException ex) 
       {System.out.println("Error al obtener las MESAS: " + ex.getMessage());}
    return mesas;
   }
public List<Mesa> listarMesasCapacidad(int cantidad){
    List<Mesa> mesas = new ArrayList<Mesa>();
     Empleado empleado;
    try {
        String sql = "SELECT * FROM mesa WHERE cantidad=? ;";
        PreparedStatement statement = connection.prepareStatement(sql);
        statement.setInt(1,cantidad );
        ResultSet resultSet = statement.executeQuery();
        Mesa mesa;
        while(resultSet.next()){
            mesa = new Mesa();
            mesa.setId_mesa(resultSet.getInt("id_mesa"));
            mesa.setCantidad(resultSet.getInt("cantidad"));
            mesa.setOcupada(resultSet.getBoolean("ocupada"));
               empleado=empleadoData.buscarEmpleado(resultSet.getInt("id_empleado"));
            mesa.setEmpleado(empleado);
            mesas.add(mesa);
        }      
        statement.close();
        } 
    catch (SQLException ex) 
       {System.out.println("Error al obtener las MESAS: " + ex.getMessage());}
    return mesas;
   }
public List<Mesa> listarMesasCapacidadLibre(int cantidad){
    List<Mesa> mesas = new ArrayList<Mesa>();
     Empleado empleado;
     boolean ocupada=false;
    try {
        String sql = "SELECT * FROM mesa WHERE cantidad=? AND ocupada=? ;";
        PreparedStatement statement = connection.prepareStatement(sql);
        statement.setInt(1,cantidad );
        statement.setBoolean(2,ocupada );
        ResultSet resultSet = statement.executeQuery();
        Mesa mesa;
        while(resultSet.next()){
            mesa = new Mesa();
            mesa.setId_mesa(resultSet.getInt("id_mesa"));
            mesa.setCantidad(resultSet.getInt("cantidad"));
            mesa.setOcupada(resultSet.getBoolean("ocupada"));
               empleado=empleadoData.buscarEmpleado(resultSet.getInt("id_empleado"));
            mesa.setEmpleado(empleado);
            mesas.add(mesa);
        }      
        statement.close();
        } 
    catch (SQLException ex) 
       {System.out.println("Error al obtener las MESAS: " + ex.getMessage());}
    return mesas;
   }
public int actualizarMesa(Mesa mesa){
    int rta=0;  
    try {
            String sql = "UPDATE mesa SET cantidad = ?, ocupada=?,id_empleado=?  WHERE id_mesa = ?;";
            PreparedStatement statement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            statement.setInt(1, mesa.getCantidad());
            statement.setBoolean(2, mesa.getOcupada());
            statement.setInt(3, mesa.getEmpleado().getId_empleado() );
            statement.setInt(4, mesa.getId_mesa());
            rta=statement.executeUpdate();
            statement.close();
         } 
    catch (SQLException ex) 
           { System.out.println("Error al insertar una mesa: " + ex.getMessage());}
    return rta;
   }
public int actualizarMesaEmpleado(int idMesa, int idEmpleado){
    int rta=0;  
    try {
            String sql = "UPDATE mesa SET id_empleado=?  WHERE id_mesa = ?;";
            PreparedStatement statement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
             statement.setInt(1,idEmpleado);
            statement.setInt(2, idMesa);
            rta=statement.executeUpdate();
            statement.close();
         } 
    catch (SQLException ex) 
           { System.out.println("Error al insertar una mesa: " + ex.getMessage());}
    return rta;
   }
public int borrarMesa(int id_mesa){
    int rta=0;
    try {
         String sql = "DELETE FROM mesa WHERE id_mesa =?;";
         PreparedStatement statement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
         statement.setInt(1, id_mesa);
         rta=statement.executeUpdate();
         statement.close();
        } 
    catch (SQLException ex) 
        { System.out.println("Error al borrar una mesa: " + ex.getMessage());}
return rta;   
}

}
