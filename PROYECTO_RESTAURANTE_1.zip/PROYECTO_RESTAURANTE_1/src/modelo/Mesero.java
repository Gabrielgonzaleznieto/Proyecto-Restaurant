/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 *
 * @author Usuario
 */
public class Mesero {
   private int id_mesero;
   private String dni;
   private String nombre; 

   public Mesero(){}
   
   public Mesero(int id_mesero,String dni,String nombre)
   {
     this.id_mesero=id_mesero;
     this.dni=dni;
     this.nombre=nombre;
   }
   public Mesero(String dni,String nombre)
   {
     this.dni=dni;
     this.nombre=nombre;
   }

    public Mesero(int id_mesero) {
     this.id_mesero=id_mesero;
    }
   
    public String getDni() {
        return dni;
    }

    public String getNombre() {
        return nombre;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getId_mesero() {
        return id_mesero;
    }

    public void setId_mesero(int id_mesero) {
        this.id_mesero = id_mesero;
    }
   
    public String toString(){
    
        return id_mesero+"-"+nombre;
    }
}
