/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Usuario
 */
public class MeseroData {
    private Connection connection = null;
    
    public MeseroData() {
      connection = conexion.getConnection();
    }
    
    public int guardarMesero(Mesero mesero){
        int rta=0;
        try {
            String sql = "INSERT INTO mesero (dni,nombre) VALUES ( ?, ? );";
            PreparedStatement statement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            statement.setString(1, mesero.getDni());
            statement.setString(2, mesero.getNombre());
            rta=statement.executeUpdate();
            statement.close();
           }
        catch (SQLException ex) {
            System.out.println("Error al insertar un mesero: " + ex.getMessage());}
    return rta;
    }
    public Mesero buscarMeseroId(int id){
    Mesero mesero=null;
    try {
        String sql = "SELECT * FROM mesero WHERE id_mesero =?;";
        PreparedStatement statement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
        statement.setInt(1, id);
           
        ResultSet resultSet=statement.executeQuery();
        while(resultSet.next())
        {
            mesero = new Mesero();
            mesero.setId_mesero(resultSet.getInt("id_mesero"));
            mesero.setDni(resultSet.getString("dni"));
            mesero.setNombre(resultSet.getString("nombre"));
        }      
        statement.close();
      } 
    catch (SQLException ex) 
        {System.out.println("Error al ingresar un mesero: " + ex.getMessage());}
    return mesero;
   }
public Mesero buscarMeseroDni(String dni){
    Mesero mesero=null;
    try {
        String sql = "SELECT * FROM mesero WHERE dni =?;";
        PreparedStatement statement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
        statement.setString(1, dni);
           
        ResultSet resultSet=statement.executeQuery();
        while(resultSet.next())
        {
            mesero = new Mesero();
            mesero.setId_mesero(resultSet.getInt("id_mesero"));
            mesero.setDni(resultSet.getString("dni"));
            mesero.setNombre(resultSet.getString("nombre"));
        }      
        statement.close();
      } 
    catch (SQLException ex) 
        {System.out.println("Error al ingresar un mesero: " + ex.getMessage());}
    return mesero;
   }
public Mesero buscarMeseroNombre(String nombre){
     Mesero mesero=null;
    try {
        String sql = "SELECT * FROM mesero WHERE nombre =?;";
        PreparedStatement statement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
        statement.setString(1, nombre);
           
        ResultSet resultSet=statement.executeQuery();
        while(resultSet.next())
        {
            mesero = new Mesero();
            mesero.setId_mesero(resultSet.getInt("id_mesero"));
            mesero.setDni(resultSet.getString("dni"));
            mesero.setNombre(resultSet.getString("nombre"));
        }      
        statement.close();
      } 
    catch (SQLException ex) 
        {System.out.println("Error al ingresar un mesero: " + ex.getMessage());}
    return mesero;
   }

public int actualizarMesero(Mesero mesero){
    int rta=0;  
    try {
           String sql = "UPDATE mesero SET dni=? , nombre = ? WHERE id_mesero = ?;";
            PreparedStatement statement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            statement.setString(1, mesero.getDni());
            statement.setString(2, mesero.getNombre());
            statement.setInt(3, mesero.getId_mesero());
            rta=statement.executeUpdate();
            statement.close();
         } 
    catch (SQLException ex) 
           { System.out.println("Error al actualizar un mesero: " + ex.getMessage());}
    return rta;
   }
public int borrarMesero(int id_mesero){
    int rta=0;
    try {
         String sql = "DELETE FROM mesero WHERE id_mesero =?;";
         PreparedStatement statement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
         statement.setInt(1, id_mesero);
         rta=statement.executeUpdate();
         statement.close();
        } 
    catch (SQLException ex) 
        { System.out.println("Error al borrar un mesero: " + ex.getMessage());}
return rta;   
}

public List<Mesero> listarMeseros(){
List<Mesero> meseros = new ArrayList<Mesero>();
try {
    String sql = "SELECT * FROM mesero;";
    PreparedStatement statement = connection.prepareStatement(sql);
    ResultSet resultSet = statement.executeQuery();
    Mesero mesero;
    while(resultSet.next()){
        mesero = new Mesero();
        mesero.setId_mesero(resultSet.getInt("id_mesero"));
        mesero.setDni(resultSet.getString("dni"));
        mesero.setNombre(resultSet.getString("nombre"));
        meseros.add(mesero);
    }      
    statement.close();
  } 
catch (SQLException ex) {
    System.out.println("Error al obtener los MESEROS: " + ex.getMessage());
   }
 return meseros;
}
}
