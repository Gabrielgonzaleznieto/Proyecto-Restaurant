/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.time.LocalDate;

/**
 *
 * @author Usuario
 */
public class Pedido {
   private int id_pedido;
   private Mesa mesa;
   private Mesero mesero;
   private LocalDate fecha; 
   private boolean pagado;
   private boolean entregado;
   
   public Pedido(){}
   
   public Pedido(Mesa mesa,Mesero mesero,LocalDate fecha,boolean pagado,boolean entregado)
   {
     this.mesa=mesa;
     this.mesero=mesero;
     this.fecha=fecha;
     this.pagado=pagado;
     this.entregado=entregado;
   }
   
    public Pedido(int id_pedido,Mesa mesa,Mesero mesero,LocalDate fecha,boolean pagado,boolean entregado)
   {
     this.id_pedido=id_pedido;
     this.mesa=mesa;
     this.mesero=mesero;
     this.fecha=fecha;
     this.pagado=pagado;
     this.entregado=entregado;
   }
 public Pedido(int id_pedido)
   {
     this.id_pedido=id_pedido;
   }
    public int getId_pedido() {
        return id_pedido;
    }

    public void setId_pedido(int id_pedido) {
        this.id_pedido = id_pedido;
    }

    public Mesero getMesero() {
        return mesero;
    }

    public void setMesero(Mesero mesero) {
        this.mesero = mesero;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }

    public boolean getPagado() {
        return pagado;
    }

    public void setPagado(boolean pagado) {
        this.pagado = pagado;
    }

    public boolean getEntregado() {
        return entregado;
    }

    public void setEntregado(boolean entregado) {
        this.entregado = entregado;
    }

    public Mesa getMesa() {
        return mesa;
    }

    public void setMesa(Mesa mesa) {
        this.mesa = mesa;
    }
   
     public String toString(){
    
        return id_pedido+"-"+mesa.getId_mesa()+"-"+mesero.getId_mesero()+"-"+fecha;
    }
}
