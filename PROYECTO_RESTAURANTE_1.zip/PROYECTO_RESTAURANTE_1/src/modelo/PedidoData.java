/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.List;
import java.util.ArrayList;

/**
 *
 * @author Usuario
 */
public class PedidoData {
    private Connection connection = null;
    
    public PedidoData() {
      connection = conexion.getConnection();
    }
    
    public int guardarPedido(Pedido pedido){
        int rta=0;
        try {
            String sql = "INSERT INTO pedido (id_mesa,id_mesero,fecha,pagado,entregado) VALUES ( ?, ? ,?,?,?);";
            PreparedStatement statement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            statement.setInt(1, pedido.getMesa().getId_mesa());
            statement.setInt(2, pedido.getMesero().getId_mesero());
            statement.setDate(3, Date.valueOf(pedido.getFecha()));
            statement.setBoolean(4, pedido.getPagado());
            statement.setBoolean(5, pedido.getEntregado());
            rta=statement.executeUpdate();
            statement.close();
           }
        catch (SQLException ex) {
            System.out.println("Error al insertar un PEDIDO: " + ex.getMessage());}
    return rta;
    }
   
    public Pedido buscarPedidoId(int id){
      Pedido pedido=null; 
      Mesero mesero=new Mesero();
      Mesa mesa=new Mesa();
      try {
            String sql = "SELECT * FROM pedido WHERE id_pedido = ?;";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setInt(1,id);
            ResultSet resultSet = statement.executeQuery();
            while(resultSet.next()){
                int idPedido=resultSet.getInt("id_pedido");
                
                int idMesa=resultSet.getInt("id_mesa");
                mesa=new Mesa(idMesa);
                
                int idMesero=resultSet.getInt("id_mesero");
                mesero=new Mesero(idMesero);
                
                LocalDate fecha=resultSet.getDate("fecha").toLocalDate();
                
                boolean pagado=resultSet.getBoolean("pagado");
                boolean entregado=resultSet.getBoolean("entregado");
                pedido=new Pedido(idPedido,mesa,mesero,fecha,pagado,entregado);
            }     
            statement.close();
     }
    catch (SQLException ex) 
        {System.out.println("Error al ingresar un PEDIDO: " + ex.getMessage());}
 
    return pedido;
   }
     public Pedido buscarPedidoMesa(Mesa mesa){
      Pedido pedido=null; 
      Mesero mesero=new Mesero();
      int id=mesa.getId_mesa();
      try {
            String sql = "SELECT * FROM pedido WHERE id_mesa = ?;";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setInt(1,id);
            ResultSet resultSet = statement.executeQuery();
            while(resultSet.next()){
                int idPedido=resultSet.getInt("id_pedido");
                
                int idMesa=resultSet.getInt("id_mesa");
                mesa=new Mesa(idMesa);
                
                int idMesero=resultSet.getInt("id_mesero");
                mesero=new Mesero(idMesero);
                
                LocalDate fecha=resultSet.getDate("fecha").toLocalDate();
                
                boolean pagado=resultSet.getBoolean("pagado");
                boolean entregado=resultSet.getBoolean("entregado");
                pedido=new Pedido(idPedido,mesa,mesero,fecha,pagado,entregado);
            }     
            statement.close();
     }
    catch (SQLException ex) 
        {System.out.println("Error al ingresar un PEDIDO: " + ex.getMessage());}
 
    return pedido;
   }
    public int actualizarPedido(Pedido pedido){
    int rta=0;
    try {
        String sql = "UPDATE pedido SET id_mesa=? ,id_mesero=? , fecha=? ,pagado=?, entregado=? WHERE id_reserva=?;";
        PreparedStatement statement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
        statement.setInt(1, pedido.getMesa().getId_mesa());
        statement.setInt(2, pedido.getMesero().getId_mesero());
        statement.setDate(3, Date.valueOf(pedido.getFecha()));
        statement.setBoolean(4, pedido.getPagado());
        statement.setBoolean(5, pedido.getEntregado());
        statement.setInt(6, pedido.getId_pedido());
        rta=statement.executeUpdate();
        statement.close();
       }
    catch (SQLException ex) {
        System.out.println("Error al actualizar un pedido: " + ex.getMessage());}
    
return rta; 
 }

public int borrarPedido(int id_pedido){
    int rta=0;
    try {
         String sql = "DELETE FROM pedido WHERE id_pedido =?;";
         PreparedStatement statement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
         statement.setInt(1, id_pedido);
         rta=statement.executeUpdate();
         statement.close();
        } 
    catch (SQLException ex) 
        { System.out.println("Error al borrar un pedido: " + ex.getMessage());}
return rta;   
}
 
public Mesero buscarMesero(int id){
    MeseroData md=new MeseroData();
    return md.buscarMeseroId(id);
}

public List<Pedido> listarPedidos(){
List<Pedido> pedidos = new ArrayList<Pedido>();
Pedido pedido=null; 
Mesero mesero=new Mesero();
Mesa mesa=new Mesa();
try {
    String sql = "SELECT * FROM pedido;";
    PreparedStatement statement = connection.prepareStatement(sql);
    ResultSet resultSet = statement.executeQuery();
    while(resultSet.next()){
                int idPedido=resultSet.getInt("id_pedido");
                
                int idMesa=resultSet.getInt("id_mesa");
                mesa=new Mesa(idMesa);
                
                int idMesero=resultSet.getInt("id_mesero");
                mesero=new Mesero(idMesero);
                
                LocalDate fecha=resultSet.getDate("fecha").toLocalDate();
                
                boolean pagado=resultSet.getBoolean("pagado");
                boolean entregado=resultSet.getBoolean("entregado");
                pedido=new Pedido(idPedido,mesa,mesero,fecha,pagado,entregado);
                pedidos.add(pedido);
            }     
            statement.close();
    
  } 
  catch (SQLException ex) {
    System.out.println("Error al obtener los PEDIDOS: " + ex.getMessage());
   }
  return pedidos;
 }
}
