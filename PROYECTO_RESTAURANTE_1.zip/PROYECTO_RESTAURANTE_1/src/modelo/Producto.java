/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 *
 * @author Usuario
 */
public class Producto {
   private int id_producto;
   private String descripcion;
   private double precio; 

   public Producto(){}
   
   public Producto(int id_producto,String descripcion,double precio)
   {
     this.id_producto=id_producto;
     this.descripcion=descripcion;
     this.precio=precio;
   }
   public Producto(String descripcion,double precio)
   {
     this.descripcion=descripcion;
     this.precio=precio;
   }

   public Producto(int id_producto) {
       this.id_producto=id_producto;  
    }

    public int getId_producto() {
        return id_producto;
    }

    public void setId_producto(int id_producto) {
        this.id_producto = id_producto;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }
    public String toString(){
    
        return id_producto+"-"+descripcion;
    }
   
}
