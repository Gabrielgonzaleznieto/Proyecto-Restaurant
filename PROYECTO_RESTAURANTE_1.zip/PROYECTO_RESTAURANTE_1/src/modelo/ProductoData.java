/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Usuario
 */
public class ProductoData {
    private Connection connection = null;
    
    public ProductoData() {
      connection = conexion.getConnection();
    }
    
    public int guardarProducto(Producto producto){
        int rta=0;
        try {
            String sql = "INSERT INTO producto (descripcion, precio) VALUES ( ?, ? );";
            PreparedStatement statement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            statement.setString(1, producto.getDescripcion());
            statement.setDouble(2, producto.getPrecio());
            rta=statement.executeUpdate();
            statement.close();
           }
        catch (SQLException ex) {
            System.out.println("Error al insertar un Producto: " + ex.getMessage());}
    return rta;
    }
    
    public Producto buscarProductoId(int id){
    Producto producto=null;
    try {
        String sql = "SELECT * FROM producto WHERE id_producto =?;";
        PreparedStatement statement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
        statement.setInt(1, id);
           
        ResultSet resultSet=statement.executeQuery();
        while(resultSet.next())
        {
            producto = new Producto();
            producto.setId_producto(resultSet.getInt("id_producto"));
            producto.setDescripcion(resultSet.getString("descripcion"));
            producto.setPrecio(resultSet.getDouble("precio"));
        }      
        statement.close();
      } 
    catch (SQLException ex) 
        {System.out.println("Error al ingresar un Producto: " + ex.getMessage());}
    return producto;
   }
public Producto buscarProductoDescripcion(String descripcion){
    Producto producto=null;
    try {
        String sql = "SELECT * FROM producto WHERE descripcion =?;";
        PreparedStatement statement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
        statement.setString(1, descripcion);
           
        ResultSet resultSet=statement.executeQuery();
        while(resultSet.next())
        {
            producto = new Producto();
            producto.setId_producto(resultSet.getInt("id_producto"));
            producto.setDescripcion(resultSet.getString("descripcion"));
            producto.setPrecio(resultSet.getDouble("precio"));
        }      
        statement.close();
      } 
    catch (SQLException ex) 
        {System.out.println("Error al ingresar un Producto: " + ex.getMessage());}
    return producto;
   }

public int actualizarProducto(Producto producto){
    int rta=0; 
    try {
          String sql = "UPDATE  producto SET descripcion=? , precio=?   WHERE id_producto = ?;";
            PreparedStatement statement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            statement.setString(1, producto.getDescripcion());
            statement.setDouble(2, producto.getPrecio());
            statement.setInt(3,producto.getId_producto());
            rta=statement.executeUpdate();
            statement.close();
         } 
    catch (SQLException ex) 
           { System.out.println("Error al actualizar un producto: " + ex.getMessage());}
    return rta;
   }
public int borrarProducto(int id_producto){
    int rta=0;
    try {
         String sql = "DELETE FROM producto WHERE id_producto =?;";
         PreparedStatement statement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
         statement.setInt(1, id_producto);
         rta=statement.executeUpdate();
         statement.close();
        } 
    catch (SQLException ex) 
        { System.out.println("Error al borrar un producto: " + ex.getMessage());}
return rta;   
}
public List<Producto> listarProductos(){
List<Producto> productos = new ArrayList<Producto>();
try {
    String sql = "SELECT * FROM producto;";
    PreparedStatement statement = connection.prepareStatement(sql);
    ResultSet resultSet = statement.executeQuery();
    Producto producto;
    while(resultSet.next()){
        producto = new Producto();
        producto.setId_producto(resultSet.getInt("id_producto"));
        producto.setDescripcion(resultSet.getString("descripcion"));
        producto.setPrecio(resultSet.getDouble("precio"));
        productos.add(producto);
    }      
    statement.close();
  } 
catch (SQLException ex) {
    System.out.println("Error al obtener los PRODUCTOS: " + ex.getMessage());
   }
 return productos;
 }
}
