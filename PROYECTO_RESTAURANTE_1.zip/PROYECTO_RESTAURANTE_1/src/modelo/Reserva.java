/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.time.LocalDate;

/**
 *
 * @author Usuario
 */
public class Reserva {
   private int id_reserva;
   private Mesa mesa;
   private Cliente cliente;
   private LocalDate fecha; 
   private int hora;
   private int numPersonas;
   private double senia;
   private String obsevacion;
   private boolean vigente;
    
   

   public Reserva(){}
   
   public Reserva(Mesa mesa,Cliente cliente,LocalDate fecha,int hora,int numPersonas,double senia,String obsevacion,boolean vigente)
   {
     this.mesa=mesa;
     this.cliente=cliente;
     this.fecha=fecha;
     this.hora=hora;
     this.numPersonas=numPersonas;
     this.senia=senia;
     this.obsevacion=obsevacion;
     this.vigente=vigente;
   }
   
 
public Reserva(int id_reserva,Mesa mesa,Cliente cliente,LocalDate fecha,int hora,int numPersonas,double senia,String obsevacion,boolean vigente)
   {
     this.id_reserva=id_reserva;
     this.mesa=mesa;
     this.cliente=cliente;
     this.fecha=fecha;
     this.hora=hora;
     this.numPersonas=numPersonas;
     this.senia=senia;
     this.obsevacion=obsevacion;
     this.vigente=vigente;
   }

//public Reserva(Mesa mesa,LocalDate fecha)
//   {
//     this.mesa=mesa;
//     this.fecha=fecha;
//   }
public Reserva(int id_reserva)
   {
     this.id_reserva=id_reserva;
    
   }
    public int getId_reserva() {
        return id_reserva;
    }

    public void setId_reserva(int id_reserva) {
        this.id_reserva = id_reserva;
    }

    public Mesa getMesa() {
        return mesa;
    }

    public void setMesa(Mesa mesa) {
        this.mesa = mesa;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }

    public int getHora() {
        return hora;
    }

    public void setHora(int hora) {
        this.hora = hora;
    }
 public int getNumPersonas() {
        return numPersonas;
    }

    public void setNumPersonas(int numPersonas) {
        this.numPersonas = numPersonas;
    }

    public double getSenia() {
        return senia;
    }

    public void setSenia(double senia) {
        this.senia = senia;
    }

    public String getObsevacion() {
        return obsevacion;
    }

    public void setObsevacion(String obsevacion) {
        this.obsevacion = obsevacion;
    }
  public String toString(){
    
        return id_reserva+"-"+mesa.getId_mesa()+"-"+cliente.getDni()+"-"+fecha+"-"+hora;
    }

    public boolean getVigente() {
        return vigente;
    }

    public void setVigente(boolean vigente) {
        this.vigente = vigente;
    }
   
   
}
