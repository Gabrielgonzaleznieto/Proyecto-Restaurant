/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.List;
import java.util.ArrayList;

/**
 *
 * @author Usuario
 */
public class ReservaData {
    private Connection connection = null;
   MesaData mesaData;
   ClienteData clienteData; 
    
    public ReservaData() {
      connection = conexion.getConnection();
    }
    
public int guardarReserva(Reserva reserva){
        int rta=0;
        System.out.println("entro a guardar reserva");
        try {
            String sql = "INSERT INTO reserva (id_mesa,dni,fecha,hora,num_personas,senia,observacion,vigente) VALUES ( ?, ? ,?,?,? ,? ,?,?);";
            PreparedStatement statement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            statement.setInt(1, reserva.getMesa().getId_mesa());
            statement.setString(2, reserva.getCliente().getDni());
            statement.setDate(3, Date.valueOf(reserva.getFecha()));
            statement.setInt(4, reserva.getHora());
            statement.setInt(5, reserva.getNumPersonas());
            statement.setDouble(6,reserva.getSenia() );
            statement.setString(7,reserva.getObsevacion());
            statement.setBoolean(8,reserva.getVigente());
            rta=statement.executeUpdate();
            statement.close();
           }
        catch (SQLException ex) {
            System.out.println("Error al insertar una reserva: " + ex.getMessage());}
    return rta;
    }
 public Reserva buscarReservaId(int id){
      Reserva reserva=null; 
      Mesa mesa=new Mesa();
      Cliente cliente=new Cliente();
      try {
            String sql = "SELECT * FROM reserva WHERE id_reserva = ?;";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setInt(1,id);
            ResultSet resultSet = statement.executeQuery();
            while(resultSet.next()){
                int idReserva=resultSet.getInt("id_reserva");
                
                int idMesa=resultSet.getInt("id_mesa");
                mesa=new Mesa(resultSet.getInt("id_mesa"));
                
                String dni=resultSet.getString("dni");
                cliente=new Cliente(dni);
               
                LocalDate fecha=resultSet.getDate("fecha").toLocalDate();
                                                
                int hora=resultSet.getInt("hora");
                int numPersonas=resultSet.getInt("num_personas");
                double senia=resultSet.getDouble("senia");
                String observacion=resultSet.getString("observacion");
                boolean vigente=resultSet.getBoolean("vigente");
                reserva=new Reserva(idReserva,mesa,cliente,fecha,hora,numPersonas,senia,observacion,vigente);
            }     
            statement.close();
     }
    catch (SQLException ex) 
        {System.out.println("Error al ingresar un reserva: " + ex.getMessage());}
 
    return reserva;
   }
public int actualizarReserva(Reserva reserva){
    int rta=0;
    
    try {
        String sql = "UPDATE reserva SET id_mesa=? , dni=? ,fecha=? ,hora=?, num_personas=?, senia=?,observacion=?,vigente=? WHERE id_reserva=?;";
        PreparedStatement statement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
        statement.setInt(1, reserva.getMesa().getId_mesa());
        statement.setString(2, reserva.getCliente().getDni());
        statement.setDate(3, Date.valueOf(reserva.getFecha()));
        statement.setInt(4, reserva.getHora());
        statement.setInt(5, reserva.getNumPersonas());
        statement.setDouble(6,reserva.getSenia() );
        statement.setString(7,reserva.getObsevacion());
        statement.setBoolean(8,reserva.getVigente());
        statement.setInt(9, reserva.getId_reserva());
        rta=statement.executeUpdate();
        statement.close();
       }
    catch (SQLException ex) {
        System.out.println("Error al insertar una reserva: " + ex.getMessage());}
    
return rta; 
 }
public int borrarReserva(int id_reserva){
    int rta=0;
    try {
         String sql = "DELETE FROM reserva WHERE id_reserva =?;";
         PreparedStatement statement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
         statement.setInt(1, id_reserva);
         rta=statement.executeUpdate();
         statement.close();
        } 
    catch (SQLException ex) 
        { System.out.println("Error al borrar una reserva: " + ex.getMessage());}
return rta;   
}
public List<Reserva> listarReservas(){
List<Reserva> reservas = new ArrayList<Reserva>();
Reserva reserva=null; 
Mesa mesa=new Mesa();
Cliente cliente=new Cliente();
try {
    String sql = "SELECT * FROM reserva;";
    PreparedStatement statement = connection.prepareStatement(sql);
    ResultSet resultSet = statement.executeQuery();
    while(resultSet.next()){
                int idReserva=resultSet.getInt("id_reserva");
                
                int idMesa=resultSet.getInt("id_mesa");
                mesa=new Mesa(resultSet.getInt("id_mesa"));
                
                String dni=resultSet.getString("dni");
                cliente=new Cliente(dni);
               
                LocalDate fecha=resultSet.getDate("fecha").toLocalDate();
                
                int hora=resultSet.getInt("hora");
                int numPersonas=resultSet.getInt("num_personas");
                double senia=resultSet.getDouble("senia");
                String observacion=resultSet.getString("observacion");
                boolean vigente=resultSet.getBoolean("vigente");
                reserva=new Reserva(idReserva,mesa,cliente,fecha,hora,numPersonas,senia,observacion,vigente);
                reservas.add(reserva);
        }     
            statement.close();
     }
catch (SQLException ex) {
    System.out.println("Error al obtener las RESERVAS: " + ex.getMessage());
   }
 return reservas;
}
public List<Reserva> listarReservasPorDni(String dniBuscado){
List<Reserva> reservas = new ArrayList<Reserva>();
Reserva reserva=null; 
Mesa mesa=new Mesa();
Cliente cliente=new Cliente();
try {
    String sql = "SELECT * FROM reserva WHERE dni=?;";
    PreparedStatement statement = connection.prepareStatement(sql);
    statement.setString(1,dniBuscado);
    ResultSet resultSet = statement.executeQuery();
    while(resultSet.next()){
                int idReserva=resultSet.getInt("id_reserva");
                
                int idMesa=resultSet.getInt("id_mesa");
                mesa=new Mesa(resultSet.getInt("id_mesa"));
                
                String dni=resultSet.getString("dni");
                cliente=new Cliente(dni);
               
                LocalDate fecha=resultSet.getDate("fecha").toLocalDate();
                
                int hora=resultSet.getInt("hora");
                int numPersonas=resultSet.getInt("num_personas");
                double senia=resultSet.getDouble("senia");
                String observacion=resultSet.getString("observacion");
                boolean vigente=resultSet.getBoolean("vigente");
                reserva=new Reserva(idReserva,mesa,cliente,fecha,hora,numPersonas,senia,observacion,vigente);
                reservas.add(reserva);
        }     
            statement.close();
     }
catch (SQLException ex) {
    System.out.println("Error al obtener las RESERVAS: " + ex.getMessage());
   }
 return reservas;  
    }


}
