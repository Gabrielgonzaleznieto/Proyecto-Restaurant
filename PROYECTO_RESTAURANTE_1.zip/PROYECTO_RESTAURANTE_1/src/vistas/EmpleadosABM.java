package vistas;

import java.awt.Color;
import java.awt.Toolkit;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import modelo.conexion;
import java.util.Date;
import modelo.Categoria;
import modelo.CategoriaData;
import modelo.Empleado;
import modelo.EmpleadoData;
import javax.swing.DefaultComboBoxModel;
/**
 *
 * @author gabriel gonzalez
 */
public class EmpleadosABM extends javax.swing.JFrame {
EmpleadoData empleadoData;
CategoriaData categoriaData;
private ArrayList<Categoria> listaCategorias;
DefaultComboBoxModel modeloPuesto;

    public EmpleadosABM() {

        initComponents();
        empleadoData=new EmpleadoData();
        categoriaData=new CategoriaData();
        
        this.setLocationRelativeTo(null);
        Toolkit lo = Toolkit.getDefaultToolkit();                                          //AQUI LE DOY UN ICONO AL PROGRAMA.
        setIconImage(lo.getImage(getClass().getResource("/Imagenes/Portada.jpg")));       //AQUI LE DOY UN ICONO AL PROGRAMA.

        Connection conn;
        conn = conexion.getConnection(); //Para tener conexión a la Base de Datos. 
        //acá es para cargar el combo      
        listaCategorias=(ArrayList)categoriaData.listarCategorias();
        cargaCategorias();
       
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnSalir = new javax.swing.JButton();
        btnAgregar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtReferencias = new javax.swing.JTextArea();
        txtDni = new javax.swing.JTextField();
        txtNombre = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        txtId = new javax.swing.JTextField();
        jPanel1 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        jPanel8 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jPanel10 = new javax.swing.JPanel();
        jLabel13 = new javax.swing.JLabel();
        jPanel11 = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();
        txtTelefono = new javax.swing.JTextField();
        txtMail = new javax.swing.JTextField();
        cbPuesto = new javax.swing.JComboBox<>();
        txtSueldo = new javax.swing.JTextField();
        btnLimpiar = new javax.swing.JButton();
        btnActualizar = new javax.swing.JButton();
        btnBuscar = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setUndecorated(true);
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnSalir.setBackground(new java.awt.Color(255, 204, 0));
        btnSalir.setFont(new java.awt.Font("Segoe UI Black", 1, 20)); // NOI18N
        btnSalir.setText("REGRESAR");
        btnSalir.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalirActionPerformed(evt);
            }
        });
        getContentPane().add(btnSalir, new org.netbeans.lib.awtextra.AbsoluteConstraints(820, 460, 170, 40));

        btnAgregar.setFont(new java.awt.Font("Segoe UI Black", 1, 20)); // NOI18N
        btnAgregar.setText("AGREGAR");
        btnAgregar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnAgregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAgregarActionPerformed(evt);
            }
        });
        getContentPane().add(btnAgregar, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 460, 170, 40));

        txtReferencias.setBackground(new java.awt.Color(227, 227, 227));
        txtReferencias.setColumns(20);
        txtReferencias.setRows(5);
        jScrollPane1.setViewportView(txtReferencias);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(820, 260, 250, 160));

        txtDni.setBackground(new java.awt.Color(227, 227, 227));
        txtDni.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtDniKeyTyped(evt);
            }
        });
        getContentPane().add(txtDni, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 250, 240, 40));

        txtNombre.setBackground(new java.awt.Color(227, 227, 227));
        txtNombre.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtNombreKeyTyped(evt);
            }
        });
        getContentPane().add(txtNombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 190, 240, 40));

        jLabel1.setFont(new java.awt.Font("Segoe Script", 1, 35)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(102, 102, 102));
        jLabel1.setText("EMPLEADOS");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 40, 700, 50));

        txtId.setBackground(new java.awt.Color(227, 227, 227));
        getContentPane().add(txtId, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 130, 70, 40));

        jPanel1.setBackground(new java.awt.Color(227, 227, 227));

        jLabel6.setFont(new java.awt.Font("Segoe Script", 1, 23)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(102, 102, 102));
        jLabel6.setText("ID_EMPLEADO");
        jPanel1.add(jLabel6);

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 130, 280, 40));

        jPanel2.setBackground(new java.awt.Color(227, 227, 227));

        jLabel2.setFont(new java.awt.Font("Segoe Script", 1, 21)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(102, 102, 102));
        jLabel2.setText("NOMBRE Y APELLIDO");
        jPanel2.add(jLabel2);

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 190, 280, 40));

        jPanel3.setBackground(new java.awt.Color(227, 227, 227));

        jLabel5.setFont(new java.awt.Font("Segoe Script", 1, 23)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(102, 102, 102));
        jLabel5.setText("REFERENCIAS");
        jPanel3.add(jLabel5);

        getContentPane().add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 260, 190, 40));

        jPanel4.setBackground(new java.awt.Color(227, 227, 227));

        jLabel3.setFont(new java.awt.Font("Segoe Script", 1, 21)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(102, 102, 102));
        jLabel3.setText("NUMERO DOCUMENTO");
        jPanel4.add(jLabel3);

        getContentPane().add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 250, 280, 40));

        jPanel5.setBackground(new java.awt.Color(227, 227, 227));
        jPanel5.setForeground(new java.awt.Color(102, 102, 102));

        jLabel7.setFont(new java.awt.Font("Segoe Script", 1, 23)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(102, 102, 102));
        jLabel7.setText("SUELDO");
        jPanel5.add(jLabel7);

        getContentPane().add(jPanel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 190, 140, 40));

        jPanel8.setBackground(new java.awt.Color(227, 227, 227));

        jLabel8.setFont(new java.awt.Font("Segoe Script", 1, 23)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(102, 102, 102));
        jLabel8.setText("PUESTO");
        jPanel8.add(jLabel8);

        getContentPane().add(jPanel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 130, 180, 40));

        jPanel10.setBackground(new java.awt.Color(227, 227, 227));

        jLabel13.setFont(new java.awt.Font("Segoe Script", 1, 23)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(102, 102, 102));
        jLabel13.setText("E_MAIL");
        jPanel10.add(jLabel13);

        getContentPane().add(jPanel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 370, 140, 40));

        jPanel11.setBackground(new java.awt.Color(227, 227, 227));

        jLabel12.setFont(new java.awt.Font("Segoe Script", 1, 23)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(102, 102, 102));
        jLabel12.setText("NUMERO TELEFONO");
        jPanel11.add(jLabel12);

        getContentPane().add(jPanel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 310, 280, 40));

        txtTelefono.setBackground(new java.awt.Color(227, 227, 227));
        getContentPane().add(txtTelefono, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 310, 240, 40));

        txtMail.setBackground(new java.awt.Color(227, 227, 227));
        getContentPane().add(txtMail, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 370, 240, 40));

        cbPuesto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbPuestoActionPerformed(evt);
            }
        });
        getContentPane().add(cbPuesto, new org.netbeans.lib.awtextra.AbsoluteConstraints(820, 130, 240, 40));

        txtSueldo.setEditable(false);
        txtSueldo.setBackground(new java.awt.Color(227, 227, 227));
        getContentPane().add(txtSueldo, new org.netbeans.lib.awtextra.AbsoluteConstraints(820, 190, 240, 40));

        btnLimpiar.setFont(new java.awt.Font("Segoe UI Black", 1, 20)); // NOI18N
        btnLimpiar.setText("LIMPIAR");
        btnLimpiar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnLimpiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimpiarActionPerformed(evt);
            }
        });
        getContentPane().add(btnLimpiar, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 460, 170, 40));

        btnActualizar.setFont(new java.awt.Font("Segoe UI Black", 1, 20)); // NOI18N
        btnActualizar.setText("ACTUALIZAR");
        btnActualizar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnActualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnActualizarActionPerformed(evt);
            }
        });
        getContentPane().add(btnActualizar, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 460, 170, 40));

        btnBuscar.setFont(new java.awt.Font("Segoe UI Black", 1, 20)); // NOI18N
        btnBuscar.setText("BUSCAR");
        btnBuscar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarActionPerformed(evt);
            }
        });
        getContentPane().add(btnBuscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 460, 170, 40));

        jLabel4.setFont(new java.awt.Font("Trebuchet MS", 1, 25)); // NOI18N
        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/FondoM.png"))); // NOI18N
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1100, 580));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalirActionPerformed
        dispose();
    }//GEN-LAST:event_btnSalirActionPerformed

    private void btnAgregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAgregarActionPerformed
    Empleado empleado=null; 
    int seleccion=cbPuesto.getSelectedIndex();
     //controlo que los campos NO estén vacíos
    if(!txtDni.getText().equals("")&& !txtNombre.getText().equals("") && !txtReferencias.getText().equals("") && 
           !txtTelefono.getText().equals("")&&  !txtMail.getText().equals("") && seleccion!=-1)
     { 
        camposColor(1);
        if(verificarDniUnico()){
           
            String dni=txtDni.getText();
            String nombre=txtNombre.getText();
            String referencias=txtReferencias.getText();
            String telefono=txtTelefono.getText();
            String e_mail=txtMail.getText();
            String contrasenia="12345";//carga contraseña por defecto

            //armo el objeto categoría para después instanciar empleado
            String seleccionado=cbPuesto.getSelectedItem().toString();
            String[] parts = seleccionado.split("-");
            String part1 = parts[0]; // devuelve el id
            int id=Integer.parseInt(part1);
            Categoria categoria=categoriaData.buscarCategoria(id);
            empleado=new Empleado(dni,nombre,referencias,categoria,telefono,e_mail,contrasenia); 
            //aviso si guardó el mpleado o no
            int rta=empleadoData.guardarEmpleado(empleado);
            if(rta==1) JOptionPane.showMessageDialog(this, "Operacion exitosa");
            else JOptionPane.showMessageDialog(this, "Fallo de operacion");
        }
        else  JOptionPane.showMessageDialog(this, "El DNI pertenece a un EMPLEADO REGISTRADO");
       }
    else
    {//aviso si hay campos vacíos
        JOptionPane.showMessageDialog(this, "Complete TODOS Los DATOS");
        camposColor(2);
    }
//
//        Connection conn = conexion.getConnection(); //Para tener conexión a la Base de Datos.
//
//        String sql = "INSERT INTO empleados(id_empleado,nombre,dni,edad,referencias,sueldo,contraseña,mesas,rango,telefono,e_mail) VALUES (?,?,?,?,?,?,?,?,?,?,?)";
//
//        try {
//            PreparedStatement pst = conn.prepareStatement(sql);
//            pst.setString(1, null);
//            pst.setString(2, nomb);
//            pst.setInt(3, dni);
//            pst.setInt(4, edad);
//            pst.setString(5, ref);
//            pst.setDouble(6, sueld);
//            pst.setString(7, contr);
//            pst.setString(8, mesas);
//            pst.setString(9, rango);
//            pst.setString(10, tel);
//            pst.setString(11, mail);
//
//            int n = pst.executeUpdate();
//
//            if (n > 0) {
//                JOptionPane.showMessageDialog(this, "Empleado registrado");
//                txtNombre.setText("");
//                txtDni.setText("");
//                txtEdad.setText("");
//                txtSueldo.setText("");
//                txtAreaReferencias.setText("");
//                txtContraseña.setText("");
//                txtMesasAsignadas.setText("");
//                txtrango.setText("");
//                txtTelefono.setText("");
//                txtMail.setText("");         
//            }
//        } catch (Exception e) {
//            JOptionPane.showMessageDialog(this, "El error es:" + e.getMessage());
//        }

    }//GEN-LAST:event_btnAgregarActionPerformed

    private void txtNombreKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtNombreKeyTyped

        char a = evt.getKeyChar();                               //VALIDACION SOLO LETRAS.
        if (Character.isDigit(a)) {
            Toolkit.getDefaultToolkit().beep();
            evt.consume();
        }
    }//GEN-LAST:event_txtNombreKeyTyped

    private void txtDniKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtDniKeyTyped
char []p={'1','2','3','4','5','6','7','8','9','0','.'}; //VALIDACION SOLO NUMEROS o punto
    int b=0;
    for(int i=0;i<=10;i++){
       if (p[i]==evt.getKeyChar())
           {b=1;}
    }
    if(b==0){
        evt.consume();  
        getToolkit().beep(); 
    }
//        char a = evt.getKeyChar();           //VALIDACION SOLO NUMEROS.
//        if (!Character.isDigit(a)) {
//            Toolkit.getDefaultToolkit().beep();
//            evt.consume();
//        }
    }//GEN-LAST:event_txtDniKeyTyped

    private void cbPuestoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbPuestoActionPerformed
        //al seleccionar el puesto me aparece directamente el sueldo
        //recupero elpuesto seleccioado, es un string con el id, puesto y rango
         String seleccionado=cbPuesto.getSelectedItem().toString();
         //aislo el id
         String[] parts = seleccionado.split("-");
         String part1 = parts[0]; // devuelve el id
         int id=Integer.parseInt(part1);
         //busco la categoría y el sueldo del puesto
         Categoria categoria=categoriaData.buscarCategoria(id);
         String sueldo=String.valueOf(categoria.getSueldo());
         txtSueldo.setText(sueldo);
    }//GEN-LAST:event_cbPuestoActionPerformed

    private void btnLimpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimpiarActionPerformed
       limpiar(); 
    }//GEN-LAST:event_btnLimpiarActionPerformed

    private void btnActualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnActualizarActionPerformed
    Color  color=new Color(227,227,227);
    Empleado empleado=null;
    int seleccion=cbPuesto.getSelectedIndex();
    //me fijo que el empleado exista
    if(!txtId.getText().equals("")){
        int idEmpleado=Integer.parseInt(txtId.getText());
        empleado=empleadoData.buscarEmpleado(idEmpleado);
        
        if(empleado!=null){
           //controlo que los campos NO estén vacíos
           if(!txtDni.getText().equals("")&& !txtNombre.getText().equals("") && !txtReferencias.getText().equals("") && !txtTelefono.getText().equals("")&&  !txtMail.getText().equals("") && seleccion!=-1)
           { 
                camposColor(1);
                String dni=txtDni.getText();
                String nombre=txtNombre.getText();
                String referencias=txtReferencias.getText();
                String telefono=txtTelefono.getText();
                String e_mail=txtMail.getText();
                String contrasenia="12345";//carga contraseña por defecto

                //armo el objeto categoría para después instanciar empleado
                String seleccionado=cbPuesto.getSelectedItem().toString();
                String[] parts = seleccionado.split("-");
                String part1 = parts[0]; // devuelve el id
                int id=Integer.parseInt(part1);
                Categoria categoria=categoriaData.buscarCategoria(id);
                empleado=new Empleado(idEmpleado,dni,nombre,referencias,categoria,telefono,e_mail,contrasenia); 
                //aviso si guardó el mpleado o no
                int rta=empleadoData.actualizarEmpleado(empleado);
                 if(rta==1) 
                        JOptionPane.showMessageDialog(this, "Operacion exitosa");
                    else 
                        JOptionPane.showMessageDialog(this, "Fallo de operacion");
            }
            else
             {//aviso si hay campos vacíos
               JOptionPane.showMessageDialog(this, "Complete TODOS Los DATOS");
               camposColor(2);
             } 
          }
        else  JOptionPane.showMessageDialog(this, "El empleado NO existe");    
      }
    else  { 
        JOptionPane.showMessageDialog(this, "Ingrese el ID");
        color=new Color(255,255,153);
        txtId.setBackground(color);
        }
    }//GEN-LAST:event_btnActualizarActionPerformed

    private void btnBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarActionPerformed
       Color  color=new Color(227,227,227);

        if(!txtId.getText().equals("")){
          txtId.setBackground(color);
          int idEmpleado=Integer.parseInt(txtId.getText());
          Empleado empleado=empleadoData.buscarEmpleado(idEmpleado);
          mostrarEmpleado(empleado);
        }
        else  { 
        JOptionPane.showMessageDialog(this, "Ingrese el ID");
        color=new Color(255,255,153);
        txtId.setBackground(color);
        }
    }//GEN-LAST:event_btnBuscarActionPerformed

    public void mostrarEmpleado(Empleado empleado){
    String id= String.valueOf(empleado.getId_empleado());
    txtId.setText(id);
    txtDni.setText(empleado.getDni());
    txtNombre.setText(empleado.getNombre());
    txtReferencias.setText(empleado.getRefrencias());
    txtTelefono.setText(empleado.getTelefono());
    txtMail.setText(empleado.getE_mail());
    //recupero la categoría (o el rango) del empleado y muestro los datos
    //traigo el Id de la categoria del empleado
    int idCategoria=empleado.getCategoria().getId_categoria();
    Categoria categoria=categoriaData.buscarCategoria(idCategoria);
    String cadenaBuscada=categoria.getId_categoria()+"-"+categoria.getTarea_desempeniada()+"-"+categoria.getTipo_categoria();
    String aux="";
    int i=0;
    for (Categoria m:listaCategorias){
         aux=m.getId_categoria()+"-"+m.getTarea_desempeniada()+"-"+m.getTipo_categoria();
         if (cadenaBuscada.equals(aux))
         { 
           cbPuesto.setSelectedIndex(i);
           JOptionPane.showMessageDialog(this,"cadenaBuscada "+cadenaBuscada +"-aux "+aux+ " -i"+i);
         }
         i++;
     }
    txtSueldo.setText(String.valueOf(categoria.getSueldo()));
}

 
 public void limpiar(){
    txtId.setText("");
    txtDni.setText("");
    txtNombre.setText("");
    txtTelefono.setText("");
    txtMail.setText("");
    txtReferencias.setText("");
    txtSueldo.setText("");
    cbPuesto.setSelectedIndex(-1); 
    camposColor(1);
   } 
  
    public void camposColor(int nuevoColor){
    Color color;
    if(nuevoColor==2)
    { 
        color=new Color(255,255,153);
    if(txtId.getText().equals("")) txtId.setBackground(color);
   if(txtDni.getText().equals("")) txtDni.setBackground(color);
   if(txtNombre.getText().equals("")) txtNombre.setBackground(color);
   if(txtTelefono.getText().equals("")) txtTelefono.setBackground(color);
   if(txtMail.getText().equals("")) txtMail.setBackground(color);
   if(txtReferencias.getText().equals("")) txtReferencias.setBackground(color);
   if(txtSueldo.getText().equals("")) txtSueldo.setBackground(color);
    int seleccionado=cbPuesto.getSelectedIndex();
   if(seleccionado==-1) cbPuesto.setBackground(color);
   }
    else 
        color=new Color(227,227,227);
   txtId.setBackground(color);
   txtDni.setBackground(color);
   txtNombre.setBackground(color);
   txtTelefono.setBackground(color);
   txtMail.setBackground(color);
   txtReferencias.setBackground(color);
   txtSueldo.setBackground(color);
    int seleccionado=cbPuesto.getSelectedIndex();
   if(seleccionado!=-1) cbPuesto.setBackground(color);
}
    
    public void cargaCategorias(){
    for(Categoria m:listaCategorias){
         cbPuesto.addItem(m.toString());
   }
}
public boolean verificarDniUnico(){
    boolean rta=true;
    Empleado empleado=null;
    empleado= empleadoData.buscarEmpleadoDni(txtDni.getText());
    if(empleado!=null) rta=false;
    return rta; 
}
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(EmpleadosABM.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(EmpleadosABM.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(EmpleadosABM.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(EmpleadosABM.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new EmpleadosABM().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnActualizar;
    private javax.swing.JButton btnAgregar;
    private javax.swing.JButton btnBuscar;
    private javax.swing.JButton btnLimpiar;
    private javax.swing.JButton btnSalir;
    private javax.swing.JComboBox<String> cbPuesto;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField txtDni;
    private javax.swing.JTextField txtId;
    private javax.swing.JTextField txtMail;
    private javax.swing.JTextField txtNombre;
    private javax.swing.JTextArea txtReferencias;
    private javax.swing.JTextField txtSueldo;
    private javax.swing.JTextField txtTelefono;
    // End of variables declaration//GEN-END:variables
}
