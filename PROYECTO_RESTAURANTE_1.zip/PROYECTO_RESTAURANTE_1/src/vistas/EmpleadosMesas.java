package vistas;

import java.awt.Color;
import java.awt.Toolkit;
import java.sql.Connection;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import modelo.Categoria;
import modelo.CategoriaData;
import modelo.Empleado;
import modelo.EmpleadoData;
import modelo.Mesa;
import modelo.MesaData;
import modelo.conexion;





/**
 *
 * @author gabriel gonzalez
 */
public class EmpleadosMesas extends javax.swing.JFrame {
    MesaData mesaData;
    EmpleadoData empleadoData;
    CategoriaData categoriaData;
    Mesa mesa;
    int idEmpleado;
    private ArrayList<Mesa> listaMesas;
    private ArrayList<Empleado> listaMeseros;
    private Color color1,color2,color3,color4,color5,color6,color7,colorPintar;
    private int idMesero;
    public EmpleadosMesas() {

        initComponents();
        
        idMesero=0;
        mesaData=new MesaData();
        empleadoData=new EmpleadoData();
        categoriaData=new CategoriaData();
        mesa=new Mesa();
        color1 =campo1.getBackground();
        color2 =campo2.getBackground();
        color3 =campo3.getBackground();
        color4 =campo4.getBackground();
        color5 =campo5.getBackground();
        color6 =campo6.getBackground();
        color7=campo7.getBackground();
        
        this.setLocationRelativeTo(null);
        Toolkit lo = Toolkit.getDefaultToolkit();                                          //AQUI LE DOY UN ICONO AL PROGRAMA.
        setIconImage(lo.getImage(getClass().getResource("/Imagenes/Portada.jpg")));       //AQUI LE DOY UN ICONO AL PROGRAMA.
        Connection conn = conexion.getConnection(); //Para tener conexión a la Base de Datos.
        idMesero=0;
      
        cargarListaMeseros();
        cargarEmpleados();
        pintarMesas();

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        mesa1 = new javax.swing.JButton();
        mesa2 = new javax.swing.JButton();
        mesa3 = new javax.swing.JButton();
        mesa4 = new javax.swing.JButton();
        mesa5 = new javax.swing.JButton();
        mesa6 = new javax.swing.JButton();
        mesa7 = new javax.swing.JButton();
        mesa8 = new javax.swing.JButton();
        mesa9 = new javax.swing.JButton();
        mesa10 = new javax.swing.JButton();
        mesa11 = new javax.swing.JButton();
        mesa12 = new javax.swing.JButton();
        mesa13 = new javax.swing.JButton();
        mesa14 = new javax.swing.JButton();
        mesa15 = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        campo6 = new javax.swing.JTextField();
        campo1 = new javax.swing.JTextField();
        campo2 = new javax.swing.JTextField();
        campo3 = new javax.swing.JTextField();
        campo4 = new javax.swing.JTextField();
        campo5 = new javax.swing.JTextField();
        btnSALIR = new javax.swing.JButton();
        campo7 = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Mapa de mesas");
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Segoe Script", 1, 28)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(102, 102, 102));
        jLabel1.setText("ASIGNAR MESEROS A LAS MESAS");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 20, 610, 50));

        mesa1.setBackground(new java.awt.Color(227, 227, 227));
        mesa1.setFont(new java.awt.Font("Segoe Script", 1, 15)); // NOI18N
        mesa1.setText("MESA 1");
        mesa1.setBorder(new javax.swing.border.MatteBorder(null));
        mesa1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mesa1ActionPerformed(evt);
            }
        });
        getContentPane().add(mesa1, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 110, 110, 40));

        mesa2.setFont(new java.awt.Font("Segoe Script", 1, 15)); // NOI18N
        mesa2.setText("MESA 2");
        mesa2.setBorder(new javax.swing.border.MatteBorder(null));
        mesa2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mesa2ActionPerformed(evt);
            }
        });
        getContentPane().add(mesa2, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 180, 110, 40));

        mesa3.setFont(new java.awt.Font("Segoe Script", 1, 15)); // NOI18N
        mesa3.setText("MESA 3");
        mesa3.setBorder(new javax.swing.border.MatteBorder(null));
        mesa3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mesa3ActionPerformed(evt);
            }
        });
        getContentPane().add(mesa3, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 250, 110, 40));

        mesa4.setFont(new java.awt.Font("Segoe Script", 1, 15)); // NOI18N
        mesa4.setText("MESA 4");
        mesa4.setBorder(new javax.swing.border.MatteBorder(null));
        mesa4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mesa4ActionPerformed(evt);
            }
        });
        getContentPane().add(mesa4, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 330, 110, 40));

        mesa5.setFont(new java.awt.Font("Segoe Script", 1, 15)); // NOI18N
        mesa5.setText("MESA 5");
        mesa5.setBorder(new javax.swing.border.MatteBorder(null));
        mesa5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mesa5ActionPerformed(evt);
            }
        });
        getContentPane().add(mesa5, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 400, 110, 40));

        mesa6.setFont(new java.awt.Font("Segoe Script", 1, 15)); // NOI18N
        mesa6.setText("MESA 6");
        mesa6.setBorder(new javax.swing.border.MatteBorder(null));
        mesa6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mesa6ActionPerformed(evt);
            }
        });
        getContentPane().add(mesa6, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 110, 110, 40));

        mesa7.setFont(new java.awt.Font("Segoe Script", 1, 15)); // NOI18N
        mesa7.setText("MESA 7");
        mesa7.setBorder(new javax.swing.border.MatteBorder(null));
        mesa7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mesa7ActionPerformed(evt);
            }
        });
        getContentPane().add(mesa7, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 180, 110, 40));

        mesa8.setFont(new java.awt.Font("Segoe Script", 1, 15)); // NOI18N
        mesa8.setText("MESA  8");
        mesa8.setBorder(new javax.swing.border.MatteBorder(null));
        mesa8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mesa8ActionPerformed(evt);
            }
        });
        getContentPane().add(mesa8, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 250, 110, 40));

        mesa9.setFont(new java.awt.Font("Segoe Script", 1, 15)); // NOI18N
        mesa9.setText("MESA  9");
        mesa9.setBorder(new javax.swing.border.MatteBorder(null));
        mesa9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mesa9ActionPerformed(evt);
            }
        });
        getContentPane().add(mesa9, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 330, 110, 40));

        mesa10.setFont(new java.awt.Font("Segoe Script", 1, 15)); // NOI18N
        mesa10.setText("MESA 10");
        mesa10.setBorder(new javax.swing.border.MatteBorder(null));
        mesa10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mesa10ActionPerformed(evt);
            }
        });
        getContentPane().add(mesa10, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 400, 110, 40));

        mesa11.setFont(new java.awt.Font("Segoe Script", 1, 15)); // NOI18N
        mesa11.setText("MESA 11");
        mesa11.setBorder(new javax.swing.border.MatteBorder(null));
        mesa11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mesa11ActionPerformed(evt);
            }
        });
        getContentPane().add(mesa11, new org.netbeans.lib.awtextra.AbsoluteConstraints(539, 110, 100, 40));

        mesa12.setFont(new java.awt.Font("Segoe Script", 1, 15)); // NOI18N
        mesa12.setText("MESA 12");
        mesa12.setBorder(new javax.swing.border.MatteBorder(null));
        mesa12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mesa12ActionPerformed(evt);
            }
        });
        getContentPane().add(mesa12, new org.netbeans.lib.awtextra.AbsoluteConstraints(539, 180, 100, 40));

        mesa13.setFont(new java.awt.Font("Segoe Script", 1, 15)); // NOI18N
        mesa13.setText("MESA 13");
        mesa13.setBorder(new javax.swing.border.MatteBorder(null));
        mesa13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mesa13ActionPerformed(evt);
            }
        });
        getContentPane().add(mesa13, new org.netbeans.lib.awtextra.AbsoluteConstraints(539, 250, 100, 40));

        mesa14.setFont(new java.awt.Font("Segoe Script", 1, 15)); // NOI18N
        mesa14.setText("MESA 14");
        mesa14.setBorder(new javax.swing.border.MatteBorder(null));
        mesa14.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mesa14ActionPerformed(evt);
            }
        });
        getContentPane().add(mesa14, new org.netbeans.lib.awtextra.AbsoluteConstraints(539, 330, 100, 40));

        mesa15.setFont(new java.awt.Font("Segoe Script", 1, 15)); // NOI18N
        mesa15.setText("MESA 15");
        mesa15.setBorder(new javax.swing.border.MatteBorder(null));
        mesa15.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mesa15ActionPerformed(evt);
            }
        });
        getContentPane().add(mesa15, new org.netbeans.lib.awtextra.AbsoluteConstraints(539, 400, 100, 40));

        jPanel2.setBackground(new java.awt.Color(227, 227, 227));

        jLabel4.setFont(new java.awt.Font("Segoe Script", 1, 23)); // NOI18N
        jLabel4.setText("MESEROS");
        jPanel2.add(jLabel4);

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(770, 30, 250, 40));

        campo6.setBackground(new java.awt.Color(153, 153, 0));
        campo6.setFont(new java.awt.Font("Segoe Script", 1, 14)); // NOI18N
        campo6.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        campo6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                campo6MouseClicked(evt);
            }
        });
        getContentPane().add(campo6, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 400, 240, 30));

        campo1.setBackground(new java.awt.Color(255, 255, 204));
        campo1.setFont(new java.awt.Font("Segoe Script", 1, 14)); // NOI18N
        campo1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        campo1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                campo1MouseClicked(evt);
            }
        });
        getContentPane().add(campo1, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 140, 240, 30));

        campo2.setBackground(new java.awt.Color(255, 255, 153));
        campo2.setFont(new java.awt.Font("Segoe Script", 1, 14)); // NOI18N
        campo2.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        campo2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                campo2MouseClicked(evt);
            }
        });
        getContentPane().add(campo2, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 190, 240, 30));

        campo3.setBackground(new java.awt.Color(255, 204, 102));
        campo3.setFont(new java.awt.Font("Segoe Script", 1, 14)); // NOI18N
        campo3.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        campo3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                campo3MouseClicked(evt);
            }
        });
        getContentPane().add(campo3, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 240, 240, 30));

        campo4.setBackground(new java.awt.Color(255, 153, 0));
        campo4.setFont(new java.awt.Font("Segoe Script", 1, 14)); // NOI18N
        campo4.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        campo4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                campo4MouseClicked(evt);
            }
        });
        getContentPane().add(campo4, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 290, 240, 30));

        campo5.setBackground(new java.awt.Color(204, 204, 0));
        campo5.setFont(new java.awt.Font("Segoe Script", 1, 14)); // NOI18N
        campo5.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        campo5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                campo5MouseClicked(evt);
            }
        });
        campo5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                campo5ActionPerformed(evt);
            }
        });
        getContentPane().add(campo5, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 340, 240, 30));

        btnSALIR.setFont(new java.awt.Font("Segoe UI Black", 1, 20)); // NOI18N
        btnSALIR.setText("REGRESAR");
        btnSALIR.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnSALIR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSALIRActionPerformed(evt);
            }
        });
        getContentPane().add(btnSALIR, new org.netbeans.lib.awtextra.AbsoluteConstraints(920, 490, 160, 60));

        campo7.setBackground(new java.awt.Color(227, 227, 227));
        campo7.setFont(new java.awt.Font("Segoe Script", 1, 14)); // NOI18N
        campo7.setText("0 - SIN MESERO");
        campo7.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        campo7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                campo7MouseClicked(evt);
            }
        });
        getContentPane().add(campo7, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 100, 240, 30));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/FondoM.png"))); // NOI18N
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1100, 580));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void mesa1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mesa1ActionPerformed
       mesaData.actualizarMesaEmpleado(1, idEmpleado);
       mesa1.setBackground(colorPintar);
    }//GEN-LAST:event_mesa1ActionPerformed

    private void mesa2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mesa2ActionPerformed
         mesaData.actualizarMesaEmpleado(2, idEmpleado);
       mesa2.setBackground(colorPintar);
    }//GEN-LAST:event_mesa2ActionPerformed

    private void mesa3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mesa3ActionPerformed
      mesaData.actualizarMesaEmpleado(3, idEmpleado);
       mesa1.setBackground(colorPintar);
    }//GEN-LAST:event_mesa3ActionPerformed

    private void mesa4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mesa4ActionPerformed
        mesaData.actualizarMesaEmpleado(4, idEmpleado);
       mesa1.setBackground(colorPintar);
    }//GEN-LAST:event_mesa4ActionPerformed

    private void mesa5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mesa5ActionPerformed
        mesaData.actualizarMesaEmpleado(5, idMesero);
       mesa5.setBackground(colorPintar);
    }//GEN-LAST:event_mesa5ActionPerformed

    private void mesa6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mesa6ActionPerformed
         mesaData.actualizarMesaEmpleado(6,idMesero);
       mesa6.setBackground(colorPintar);
    }//GEN-LAST:event_mesa6ActionPerformed

    private void mesa7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mesa7ActionPerformed
         mesaData.actualizarMesaEmpleado(7,idMesero);
       mesa7.setBackground(colorPintar);
    }//GEN-LAST:event_mesa7ActionPerformed

    private void mesa8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mesa8ActionPerformed
         mesaData.actualizarMesaEmpleado(8,idMesero);
       mesa8.setBackground(colorPintar);
    }//GEN-LAST:event_mesa8ActionPerformed

    private void mesa9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mesa9ActionPerformed
         mesaData.actualizarMesaEmpleado(9,idMesero);
       mesa9.setBackground(colorPintar);
    }//GEN-LAST:event_mesa9ActionPerformed

    private void mesa10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mesa10ActionPerformed
       mesaData.actualizarMesaEmpleado(10, idEmpleado);
       mesa1.setBackground(colorPintar);
    }//GEN-LAST:event_mesa10ActionPerformed

    private void mesa11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mesa11ActionPerformed
        mesaData.actualizarMesaEmpleado(11, idEmpleado);
       mesa1.setBackground(colorPintar);
    }//GEN-LAST:event_mesa11ActionPerformed

    private void mesa12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mesa12ActionPerformed
        mesaData.actualizarMesaEmpleado(12, idEmpleado);
       mesa1.setBackground(colorPintar);
    }//GEN-LAST:event_mesa12ActionPerformed

    private void mesa13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mesa13ActionPerformed
        mesaData.actualizarMesaEmpleado(13, idEmpleado);
       mesa1.setBackground(colorPintar);
    }//GEN-LAST:event_mesa13ActionPerformed

    private void mesa14ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mesa14ActionPerformed
        mesaData.actualizarMesaEmpleado(14, idEmpleado);
       mesa1.setBackground(colorPintar);
    }//GEN-LAST:event_mesa14ActionPerformed

    private void mesa15ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mesa15ActionPerformed
        mesaData.actualizarMesaEmpleado(15, idEmpleado);
       mesa1.setBackground(colorPintar);
    }//GEN-LAST:event_mesa15ActionPerformed

    private void campo1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_campo1MouseClicked
     //color =new Color(255,255,204);
     colorPintar=color1;
     //recupero el id del campo de texto
     String seleccionado=campo1.getText();
     String[] parts = seleccionado.split("-");
     String part1 = parts[0]; // devuelve el id
     int id=Integer.parseInt(part1);
     idMesero=id;
    }//GEN-LAST:event_campo1MouseClicked

    private void campo3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_campo3MouseClicked
    //color =new Color(255,204,102);
     colorPintar=color3;
      //recupero el id del campo de texto
     String seleccionado=campo3.getText();
     String[] parts = seleccionado.split("-");
     String part1 = parts[0]; // devuelve el id
     int id=Integer.parseInt(part1);
     idMesero=id;//JOptionPane.showMessageDialog(this, "idMesero "+idMesero+" id "+id);
    }//GEN-LAST:event_campo3MouseClicked

    private void campo5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_campo5MouseClicked
//        color =new Color(204,204,0);
 colorPintar=color5;
  //recupero el id del campo de texto
     String seleccionado=campo5.getText();
     String[] parts = seleccionado.split("-");
     String part1 = parts[0]; // devuelve el id
     int id=Integer.parseInt(part1);
     idMesero=id;
    }//GEN-LAST:event_campo5MouseClicked

    private void campo2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_campo2MouseClicked
       // color =new Color(255,255,153);
        colorPintar=color2;
         //recupero el id del campo de texto
     String seleccionado=campo2.getText();
     String[] parts = seleccionado.split("-");
     String part1 = parts[0]; // devuelve el id
     int id=Integer.parseInt(part1);
     idMesero=id;
    }//GEN-LAST:event_campo2MouseClicked

    private void campo4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_campo4MouseClicked
        //color =new Color(255,153,0);
         colorPintar=color4;
          //recupero el id del campo de texto
     String seleccionado=campo4.getText();
     String[] parts = seleccionado.split("-");
     String part1 = parts[0]; // devuelve el id
     int id=Integer.parseInt(part1);
     idMesero=id;
    }//GEN-LAST:event_campo4MouseClicked

    private void campo6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_campo6MouseClicked
//        color =new Color(153,153,0);
 //recupero el id del campo de texto
     String seleccionado=campo6.getText();
     String[] parts = seleccionado.split("-");
     String part1 = parts[0]; // devuelve el id
     int id=Integer.parseInt(part1);
     idMesero=id;
 colorPintar=color6;
    }//GEN-LAST:event_campo6MouseClicked

    private void btnSALIRActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSALIRActionPerformed
        dispose();
    }//GEN-LAST:event_btnSALIRActionPerformed

    private void campo7MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_campo7MouseClicked
         colorPintar=color7;
         idMesero=0;
    }//GEN-LAST:event_campo7MouseClicked

    private void campo5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_campo5ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_campo5ActionPerformed
private void cargarListaMeseros(){
     ArrayList<Empleado> listaEmpleados=(ArrayList)empleadoData.listarEmpleado(); 
     listaMeseros= new ArrayList();
     Categoria categoria;
     int id;
     String tarea="MESERO";
      for(Empleado empleado:listaEmpleados){
        id=empleado.getCategoria().getId_categoria();
        categoria=categoriaData.buscarCategoria(id);
        if(categoria.getTarea_desempeniada().equals(tarea)) {
         listaMeseros.add(empleado);
         }

      }
}

    private void cargarEmpleados(){
    int i=0;
    String cadena="";
    String panel="";
    String[] meseros=new String[6];
    //asignar un campo de texto a cada empleado(así le doy un color a cada uno)
    for(Empleado empleado:listaMeseros){
           meseros[i]=empleado.getId_empleado()+"-"+empleado.getNombre();
            i++;
        }
   campo1.setText(meseros[0]);
   campo2.setText(meseros[1]);
   campo3.setText(meseros[2]);
   campo4.setText(meseros[3]);
   campo5.setText(meseros[4]);
   campo6.setText(meseros[5]);
  
   }
public void pintarMesas(){
listaMesas=(ArrayList)mesaData.listarMesas();
int idMesa=0;
int atiende=0;
color1 =campo1.getBackground();
color2 =campo2.getBackground();
color3 =campo3.getBackground();
color4 =campo4.getBackground();
color5 =campo5.getBackground();
color6 =campo6.getBackground();
color7=campo7.getBackground();
//voy buscado el mesero de cada mesa para pintarla
for(Mesa m:listaMesas){
   int i=1;
   int aviso=0;
   idMesa=m.getId_mesa();
   if(m.getEmpleado()!=null)
        atiende=m.getEmpleado().getId_empleado();
   else
        atiende=0;
   switch(idMesa){
       case 1:{
               for(Empleado empleado:listaMeseros)
                    {i++;
                     int id=empleado.getId_empleado();
                     if(idMesero==id)
                        {aviso=i;}
                    }
                      switch(aviso){
                          case 1:mesa1.setBackground(color1);break;
                          case 2:mesa1.setBackground(color2);break;
                          case 3:mesa1.setBackground(color3);break;
                          case 4:mesa1.setBackground(color4);break;
                          case 5:mesa1.setBackground(color5);break;
                          case 6:mesa1.setBackground(color6);break;
                          default:mesa1.setBackground(color7);break;
                    }

           break;
       }


       case 2:{for(Empleado empleado:listaMeseros)
                    {i++;
                     int id=empleado.getId_empleado();
                     if(idMesero==id)
                        {aviso=i;}
                   }
                  switch(aviso){

                      case 1:mesa2.setBackground(color1);break;
                      case 2:mesa2.setBackground(color2);break;
                      case 3:mesa2.setBackground(color3);break;
                      case 4:mesa2.setBackground(color4);break;
                      case 5:mesa2.setBackground(color5);break;
                      case 6:mesa2.setBackground(color6);break;
                       default:mesa2.setBackground(color7);break;
                  }

           break;
       }

       case 3:{
           for(Empleado empleado:listaMeseros)
                    {i++;
                     int id=empleado.getId_empleado();
                     if(idMesero==id)
                        {aviso=i;}
                   }
                  switch(aviso){

                      case 1:mesa3.setBackground(color1);break;
                      case 2:mesa3.setBackground(color2);break;
                      case 3:mesa3.setBackground(color3);break;
                      case 4:mesa3.setBackground(color4);break;
                      case 5:mesa3.setBackground(color5);break;
                      case 6:mesa3.setBackground(color6);break;
                       default:mesa3.setBackground(color7);break;
                  }

           break;
       }
       case 4:{
           for(Empleado empleado:listaMeseros)
                    {i++;
                     int id=empleado.getId_empleado();
                     if(idMesero==id)
                        {aviso=i;}
                    }
                  switch(aviso){

                      case 1:mesa4.setBackground(color1);break;
                      case 2:mesa4.setBackground(color2);break;
                      case 3:mesa4.setBackground(color3);break;
                      case 4:mesa4.setBackground(color4);break;
                      case 5:mesa4.setBackground(color5);break;
                      case 6:mesa4.setBackground(color6);break;
                       default:mesa4.setBackground(color7);break;
                 }

           break;
       }
       case 5:{
           for(Empleado empleado:listaMeseros)
                    {i++;
                    int id=empleado.getId_empleado();
                     if(atiende==id)
                        {aviso=i;}
                     }
                  switch(aviso){
                      case 1:mesa5.setBackground(color1);break;
                      case 2:mesa5.setBackground(color2);break;
                      case 3:mesa5.setBackground(color3);break;
                      case 4:mesa5.setBackground(color4);break;
                      case 5:mesa5.setBackground(color5);break;
                      case 6:mesa5.setBackground(color6);break;
                       default:mesa5.setBackground(color7);break;
                  }

           break;
       }
       case 6:{
           for(Empleado empleado:listaMeseros)
                    {i++;
                    int id=empleado.getId_empleado();
                     if(atiende==id)
                        {aviso=i;}
                    }
           switch(aviso){
                      case 1:mesa6.setBackground(color1);break;
                      case 2:mesa6.setBackground(color2);break;
                      case 3:mesa6.setBackground(color3);break;
                      case 4:mesa6.setBackground(color4);break;
                      case 5:mesa6.setBackground(color5);break;
                      case 6:mesa6.setBackground(color6);break;
                       default:mesa6.setBackground(color7);break;
                  }

           break;
       }
       case 7:{
           for(Empleado empleado:listaMeseros)
                    {i++;
                     int id=empleado.getId_empleado();
                     if(atiende==id)
                        {aviso=i;}
                    }
                  switch(aviso){
                      case 1:mesa7.setBackground(color1);break;
                      case 2:mesa7.setBackground(color2);break;
                      case 3:mesa7.setBackground(color3);break;
                      case 4:mesa7.setBackground(color4);break;
                      case 5:mesa7.setBackground(color5);break;
                      case 6:mesa7.setBackground(color6);break;
                       default:mesa7.setBackground(color7);break;
                  }

           break;
       }
       case 8:{
            for(Empleado empleado:listaMeseros)
                    {i++;
                     int id=empleado.getId_empleado();
                     if(atiende==id)
                        {aviso=i;}
                    }
                  switch(aviso){
                      case 1:mesa8.setBackground(color1);break;
                      case 2:mesa8.setBackground(color2);break;
                      case 3:mesa8.setBackground(color3);break;
                      case 4:mesa8.setBackground(color4);break;
                      case 5:mesa8.setBackground(color5);break;
                      case 6:mesa8.setBackground(color6);break;
                     default:mesa8.setBackground(color7);break;
                  }

           break;
       }
       case 9:{
           for(Empleado empleado:listaMeseros)
                    {i++;
                     int id=empleado.getId_empleado();
                     if(atiende==id)
                        {aviso=i;}
                    }
                  switch(aviso){
                      case 1:mesa9.setBackground(color1);break;
                      case 2:mesa9.setBackground(color2);break;
                      case 3:mesa9.setBackground(color3);break;
                      case 4:mesa9.setBackground(color4);break;
                      case 5:mesa9.setBackground(color5);break;
                      case 6:mesa9.setBackground(color6);break;
                       default:mesa9.setBackground(color7);break;
                  }

           break;
       }
       case 10:{
           for(Empleado empleado:listaMeseros)
                    {i++;
                     int id=empleado.getId_empleado();
                     if(idMesero==id)
                        {aviso=i;}

                    }
                  switch(aviso){
                       case 1:mesa10.setBackground(color1);break;
                      case 2:mesa10.setBackground(color2);break;
                      case 3:mesa10.setBackground(color3);break;
                      case 4:mesa10.setBackground(color4);break;
                      case 5:mesa10.setBackground(color5);break;
                      case 6:mesa10.setBackground(color6);break;
                       default:mesa10.setBackground(color7);break;
                  }

           break;
       }
       case 11:{
           for(Empleado empleado:listaMeseros)
                    {i++;
                     int id=empleado.getId_empleado();
                     if(idMesero==id)
                        {aviso=i;}

                    }
                  switch(aviso){
                      case 1:mesa11.setBackground(color1);break;
                      case 2:mesa11.setBackground(color2);break;
                      case 3:mesa11.setBackground(color3);break;
                      case 4:mesa11.setBackground(color4);break;
                      case 5:mesa11.setBackground(color5);break;
                      case 6:mesa11.setBackground(color6);break;
                       default:mesa11.setBackground(color7);break;
                  }

           break;
       }
       case 12:{
           for(Empleado empleado:listaMeseros)
                    {i++;
                     int id=empleado.getId_empleado();
                     if(idMesero==id)
                        {aviso=i;}

                    }
                  switch(aviso){
                      case 1:mesa12.setBackground(color1);break;
                      case 2:mesa12.setBackground(color2);break;
                      case 3:mesa12.setBackground(color3);break;
                      case 4:mesa12.setBackground(color4);break;
                      case 5:mesa12.setBackground(color5);break;
                      case 6:mesa12.setBackground(color6);break;
                       default:mesa12.setBackground(color7);break;
                  }

           break;
       }
       case 13:{
           for(Empleado empleado:listaMeseros)
                    {i++;
                     int id=empleado.getId_empleado();
                     if(idMesero==id)
                        {aviso=i;}

                    }
           switch(aviso){
                case 1:mesa13.setBackground(color1);break;
                      case 2:mesa13.setBackground(color2);break;
                      case 3:mesa13.setBackground(color3);break;
                      case 4:mesa13.setBackground(color4);break;
                      case 5:mesa13.setBackground(color5);break;
                      case 6:mesa13.setBackground(color6);break;
                       default:mesa13.setBackground(color7);break;
                  }

           break;
       }
       case 14:{
           for(Empleado empleado:listaMeseros)
                    {i++;
                     int id=empleado.getId_empleado();
                     if(idMesero==id)
                        {aviso=i;}

                    }
                  switch(aviso){
                      case 1:mesa14.setBackground(color1);break;
                      case 2:mesa14.setBackground(color2);break;
                      case 3:mesa14.setBackground(color3);break;
                      case 4:mesa14.setBackground(color4);break;
                      case 5:mesa14.setBackground(color5);break;
                      case 6:mesa14.setBackground(color6);break;
                       default:mesa14.setBackground(color7);break;
                  }

           break;
       }
       case 15:{
           for(Empleado empleado:listaMeseros)
                    {i++;
                      int id=empleado.getId_empleado();
                     if(idMesero==id)
                        {aviso=i;}

                    }
                  switch(aviso){
                      case 1:mesa15.setBackground(color1);break;
                      case 2:mesa15.setBackground(color2);break;
                      case 3:mesa15.setBackground(color3);break;
                      case 4:mesa15.setBackground(color4);break;
                      case 5:mesa15.setBackground(color5);break;
                      case 6:mesa15.setBackground(color6);break;
                       default:mesa15.setBackground(color7);break;
                  }

           break;
       }
   }

}
}
  
    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(EmpleadosMesas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(EmpleadosMesas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(EmpleadosMesas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(EmpleadosMesas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {

            }
        });
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnSALIR;
    private javax.swing.JTextField campo1;
    private javax.swing.JTextField campo2;
    private javax.swing.JTextField campo3;
    private javax.swing.JTextField campo4;
    private javax.swing.JTextField campo5;
    private javax.swing.JTextField campo6;
    private javax.swing.JTextField campo7;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JButton mesa1;
    private javax.swing.JButton mesa10;
    private javax.swing.JButton mesa11;
    private javax.swing.JButton mesa12;
    private javax.swing.JButton mesa13;
    private javax.swing.JButton mesa14;
    private javax.swing.JButton mesa15;
    private javax.swing.JButton mesa2;
    private javax.swing.JButton mesa3;
    private javax.swing.JButton mesa4;
    private javax.swing.JButton mesa5;
    private javax.swing.JButton mesa6;
    private javax.swing.JButton mesa7;
    private javax.swing.JButton mesa8;
    private javax.swing.JButton mesa9;
    // End of variables declaration//GEN-END:variables

//    private void mesa1() {
//        mesa1.setIcon(img);
//
//    }
//
//    private void mesa2() {
//        mesa2.setIcon(img);
//    }
//
//    private void mesa3() {
//        mesa3.setIcon(img);
//    }
//
//    private void mesa4() {
//        mesa4.setIcon(img);
//    }
//
//    private void mesa5() {
//        mesa5.setIcon(img);
//
//    }
//
//    private void mesa6() {
//        mesa6.setIcon(img);
//    }
//
//    private void mesa7() {
//        mesa7.setIcon(img);
//    }
//
//    private void mesa8() {
//        mesa8.setIcon(img);
//    }
//
//    private void mesa9() {
//        mesa9.setIcon(img);
//    }
//
//    private void mesa10() {
//        mesa10.setIcon(img);
//    }
//
//    private void mesa11() {
//        mesa11.setIcon(img);
//    }
//
//    private void mesa12() {
//        mesa12.setIcon(img);
//    }
//
//    private void mesa13() {
//        mesa13.setIcon(img);
//    }
//
//    private void mesa14() {
//        mesa14.setIcon(img);
//    }
//
//    private void mesa15() {
//        mesa15.setIcon(img);
//    }
//    
////     private void mesasv() {
////        mesa1.setIcon(im);
////        mesa2.setIcon(im);
////        mesa3.setIcon(im);
////        mesa4.setIcon(im);
////        mesa5.setIcon(im);
////        mesa6.setIcon(im);
////    }
}
