package vistas;


import java.awt.Color;
import java.awt.Font;
import java.awt.Toolkit;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;
import modelo.Categoria;
import modelo.CategoriaData;
import modelo.Empleado;
import modelo.EmpleadoData;
import modelo.conexion;


/**
 *
 * @author gabriel gonzalez
 */
public class EmpleadosRegistro extends javax.swing.JFrame {
    private EmpleadoData empleadoData;
    private CategoriaData categoriaData;
    boolean opc = true;
    EmpleadosABM empleadosABM = new EmpleadosABM();
    EmpleadosMesas empleadosMesas= new EmpleadosMesas();
    private ArrayList<Empleado> listaEmpleados;
    DefaultTableModel modelo;
   
    
    public EmpleadosRegistro() {
        initComponents();
        this.setLocationRelativeTo(null);
        Toolkit lo = Toolkit.getDefaultToolkit();                                          //AQUI LE DOY UN ICONO AL PROGRAMA.
        setIconImage(lo.getImage(getClass().getResource("/Imagenes/Portada.jpg")));       //AQUI LE DOY UN ICONO AL PROGRAMA.
        empleadoData= new EmpleadoData();
        categoriaData=new CategoriaData();
        
       

        //ACA SE HACE TRANSPARENTE EL JTABLE.
        Tabla.setBackground(new Color(0, 0, 0, 0));
        ((DefaultTableCellRenderer) Tabla.getDefaultRenderer(Object.class)).setBackground(new Color(0, 0, 0, 0));
        Tabla.setGridColor(Color.DARK_GRAY);
        Tabla.setForeground(Color.DARK_GRAY);
        jScrollPane1.setBackground(new Color(0, 0, 0, 0));
        jScrollPane1.setOpaque(false);
        Tabla.setOpaque(false);
        ((DefaultTableCellRenderer) Tabla.getDefaultRenderer(Object.class)).setOpaque(false);
        // jScrollPane1.getViewport().setOpaque(false);
        Tabla.setShowGrid(true);

        //ACA CAMBIO LA LETRA Y EL TAMAÑO Y TAMBIEN AGRANDO O ACHICO LAS COLUMNAS DE LA TABLA.
//        Tabla.setFont(new Font("Tahoma", 1, 13));
//        TableColumn TableColumn = Tabla.getColumnModel().getColumn(0);
//        TableColumn.setPreferredWidth(20);
//        TableColumn TableColumn1 = Tabla.getColumnModel().getColumn(1);
//        TableColumn1.setPreferredWidth(100);
//        TableColumn TableColumn2 = Tabla.getColumnModel().getColumn(2);
//        TableColumn2.setPreferredWidth(50);
//        TableColumn TableColumn3 = Tabla.getColumnModel().getColumn(3);
//        TableColumn3.setPreferredWidth(50);
       

        //inicializa la tabla    
        modelo=new DefaultTableModel();
        modelo.addColumn("Nº Empleado");
        modelo.addColumn("Nombre");
        modelo.addColumn("DNI");
        modelo.addColumn("Referencias");
        modelo.addColumn("Telefono");
        modelo.addColumn("e_mail");
        
        
        modelo.addColumn("Id Categoria");
        modelo.addColumn("Puesto");
        modelo.addColumn("Categoria");
        modelo.addColumn("Sueldo");
        this.Tabla.setModel(modelo);
        cargarTabla();
    }

    

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnEmpleadoABM = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        btbSalir = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        btnAsignar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        Tabla = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setUndecorated(true);
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnEmpleadoABM.setFont(new java.awt.Font("Segoe UI Black", 1, 20)); // NOI18N
        btnEmpleadoABM.setText("EMPLEADOS ABM");
        btnEmpleadoABM.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnEmpleadoABM.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEmpleadoABMActionPerformed(evt);
            }
        });
        getContentPane().add(btnEmpleadoABM, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 160, 250, 40));

        btnEliminar.setFont(new java.awt.Font("Segoe UI Black", 1, 20)); // NOI18N
        btnEliminar.setText("ELIMINAR ");
        btnEliminar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });
        getContentPane().add(btnEliminar, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 160, 160, 40));

        btbSalir.setBackground(new java.awt.Color(227, 227, 227));
        btbSalir.setFont(new java.awt.Font("Segoe UI Black", 1, 20)); // NOI18N
        btbSalir.setText("SALIR");
        btbSalir.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btbSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btbSalirActionPerformed(evt);
            }
        });
        getContentPane().add(btbSalir, new org.netbeans.lib.awtextra.AbsoluteConstraints(880, 160, 140, 40));

        jLabel2.setFont(new java.awt.Font("Segoe Script", 1, 35)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(102, 102, 102));
        jLabel2.setText("REGISTRO DE EMPLEADOS");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 60, 570, 40));

        btnAsignar.setFont(new java.awt.Font("Segoe UI Black", 1, 20)); // NOI18N
        btnAsignar.setForeground(new java.awt.Color(51, 51, 51));
        btnAsignar.setText("ASIGNAR MESAS");
        btnAsignar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnAsignar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAsignarActionPerformed(evt);
            }
        });
        getContentPane().add(btnAsignar, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 160, 210, 40));

        Tabla.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        Tabla.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jScrollPane1.setViewportView(Tabla);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 220, 970, 150));

        jLabel1.setFont(new java.awt.Font("Trebuchet MS", 1, 25)); // NOI18N
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/FondoM.png"))); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1100, 580));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnEmpleadoABMActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEmpleadoABMActionPerformed
       if (opc == true) {
            empleadosABM.setVisible(true);
            opc = false;
        } else {
            empleadosABM.dispose();
            opc = true;
            empleadosABM.setVisible(true);
        }
        cargarTabla();
    }//GEN-LAST:event_btnEmpleadoABMActionPerformed

    private void btbSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btbSalirActionPerformed
        dispose();
    }//GEN-LAST:event_btbSalirActionPerformed

    private void btnAsignarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAsignarActionPerformed
     if (opc == true) {
            empleadosMesas.setVisible(true);
            opc = false;
        } else {
            empleadosMesas.dispose();
            opc = true;
            empleadosMesas.setVisible(true);
        }
        cargarTabla();
    }//GEN-LAST:event_btnAsignarActionPerformed

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed

        Empleado empleado=null;
        int rta=0;
        int row = Tabla.getSelectedRow();
        String idCadena = Tabla.getValueAt(row, 0).toString();
        int id=Integer.parseInt(idCadena);
        // me fijo qe el empleado exista
        empleado=empleadoData.buscarEmpleado(id);
        if(empleado!=null)
        { //confirmo si quiere eliminar
            rta=confirmar_ventana();
            if(rta==1)
            { //si me dice que si, devuelve un 1, y elimino el empleado
                rta=empleadoData.borrarEmpleado(id);
                //aviso si se eliminó o no
                if(rta==1) JOptionPane.showMessageDialog(this, "Empleado Eliminado");
                else JOptionPane.showMessageDialog(this, "Empleado NO Eliminado");
            }
            else JOptionPane.showMessageDialog(this, "Operación CANCELADA");
        }
        else
        JOptionPane.showMessageDialog(this, "NO EXISTE el  empleado Nº "+id);
        cargarTabla();
        ////        String result = null;
        ////        Connection conn = conexion.getConnection(); //Para tener conexión a la Base de Datos.
        ////
        ////        String sql = "DELETE FROM empleados where id_empleado=?";
        ////        try {
            ////            Connection cn = conexion.getConnection();
            ////            PreparedStatement ps = cn.prepareStatement(sql);
            ////            ps.setString(1, id);
            ////            int n = ps.executeUpdate();
            ////            cn.close();
            ////            ps.close();
            ////            if (n > 0) {
                ////                JOptionPane.showMessageDialog(this, "Empleado Eliminado");
                ////            }
            ////        } catch (Exception e) {
            ////            System.out.println("Error: " + e.getMessage());
            ////            result = e.getMessage();
            ////        }
        //
        //        tabla();
        //
    }//GEN-LAST:event_btnEliminarActionPerformed
private int confirmar_ventana() {
      String botones[] = {"BORRAR", "CANCELAR"};
      int rta=0;
      int eleccion = JOptionPane.showOptionDialog(this, "Los DATOS se BORRARAN  permenentemente", "SOFTWARE PROGRAMADORES 3.0 ULP SAN LUIS ARGENTINA", 0, 0, null, botones, this);
      if (eleccion == JOptionPane.YES_OPTION)  rta=1;
      return rta;
    }

public void cargarTabla(){
   borraFilasTabla();
   Categoria categoria;
   listaEmpleados=(ArrayList)empleadoData.listarEmpleado();
   for(Empleado m:listaEmpleados){
         categoria=categoriaData.buscarCategoria(m.getCategoria().getId_categoria());
         modelo.addRow(new Object[]{m.getId_empleado(),m.getNombre(),m.getDni(),m.getRefrencias(),m.getTelefono(),m.getE_mail(),categoria.getId_categoria(),categoria.getTarea_desempeniada(),categoria.getTipo_categoria(),categoria.getSueldo()});
     }
   }
public void borraFilasTabla(){
  int a =modelo.getRowCount()-1;
  System.out.println("Tabla "+a); 
  for(int i=a;i>=0;i--)
    {modelo.removeRow(i );}
  }
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(EmpleadosRegistro.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(EmpleadosRegistro.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(EmpleadosRegistro.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(EmpleadosRegistro.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new EmpleadosRegistro().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable Tabla;
    private javax.swing.JButton btbSalir;
    private javax.swing.JButton btnAsignar;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnEmpleadoABM;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables


}
