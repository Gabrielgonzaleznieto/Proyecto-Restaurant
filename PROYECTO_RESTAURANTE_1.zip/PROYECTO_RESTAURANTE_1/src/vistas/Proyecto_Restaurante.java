
package vistas;



/**
 *
 * @author gabriel gonzalez
 */
public class Proyecto_Restaurante {

   
    public static void main(String[] args) {
        
        InicioLogin i = new InicioLogin();
        i.setVisible(true);
       
            
         
    }
    
}
