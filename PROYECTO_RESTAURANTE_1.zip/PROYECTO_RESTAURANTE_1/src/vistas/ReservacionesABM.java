package vistas;

import java.awt.Color;
import java.awt.Toolkit;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import modelo.conexion;
import java.util.Date;
import modelo.Categoria;
import modelo.CategoriaData;
import modelo.Empleado;
import modelo.EmpleadoData;
import javax.swing.DefaultComboBoxModel;
import javax.swing.table.DefaultTableModel;
import modelo.Cliente;
import modelo.ClienteData;
import modelo.Mesa;
import modelo.MesaData;
import modelo.Reserva;
import modelo.ReservaData;
/**
 *
 * @author gabriel gonzalez
 */
public class ReservacionesABM extends javax.swing.JFrame {
boolean opc = true;
MesaData mesaData;
ClienteData clienteData;
ReservaData reservaData;
private ArrayList<Reserva> listaReservas;
private ArrayList<Reserva> listaReservasDeMesas;
DefaultTableModel modelo;

    public ReservacionesABM() {

        initComponents();
        mesaData=new MesaData();
        clienteData=new ClienteData();
        reservaData= new ReservaData();
        
        this.setLocationRelativeTo(null);
        Toolkit lo = Toolkit.getDefaultToolkit();                                          //AQUI LE DOY UN ICONO AL PROGRAMA.
        setIconImage(lo.getImage(getClass().getResource("/Imagenes/Portada.jpg"))); 
       
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        campoObservacion = new javax.swing.JTextArea();
        jLabel1 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        jPanel8 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jPanel10 = new javax.swing.JPanel();
        jLabel13 = new javax.swing.JLabel();
        jPanel11 = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();
        jPanel7 = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        jPanel9 = new javax.swing.JPanel();
        jLabel11 = new javax.swing.JLabel();
        jsPersonas = new javax.swing.JSpinner();
        campoFecha = new javax.swing.JTextField();
        campoDni = new javax.swing.JTextField();
        campoNombre = new javax.swing.JTextField();
        campoTelefono = new javax.swing.JTextField();
        campoE_mail = new javax.swing.JTextField();
        jPanel12 = new javax.swing.JPanel();
        jLabel16 = new javax.swing.JLabel();
        jsHora = new javax.swing.JSpinner();
        jPanel13 = new javax.swing.JPanel();
        jLabel14 = new javax.swing.JLabel();
        jsMinuto = new javax.swing.JSpinner();
        campoId = new javax.swing.JTextField();
        cbVigente = new javax.swing.JCheckBox();
        jsCosto = new javax.swing.JSpinner();
        jPanel14 = new javax.swing.JPanel();
        jLabel15 = new javax.swing.JLabel();
        campoMesa = new javax.swing.JTextField();
        botonVerMesas = new javax.swing.JButton();
        botonGuardar = new javax.swing.JButton();
        botonBuscar = new javax.swing.JButton();
        botonActualizar = new javax.swing.JButton();
        botonBorrar = new javax.swing.JButton();
        botonLimpiar = new javax.swing.JButton();
        botonRegresar = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setUndecorated(true);
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        campoObservacion.setBackground(new java.awt.Color(227, 227, 227));
        campoObservacion.setColumns(20);
        campoObservacion.setFont(new java.awt.Font("Segoe Script", 1, 20)); // NOI18N
        campoObservacion.setRows(5);
        jScrollPane1.setViewportView(campoObservacion);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(820, 310, 270, 110));

        jLabel1.setFont(new java.awt.Font("Segoe Script", 1, 35)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(102, 102, 102));
        jLabel1.setText("RESERVACIONES");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 0, 360, 50));

        jPanel1.setBackground(new java.awt.Color(227, 227, 227));

        jLabel6.setFont(new java.awt.Font("Segoe Script", 1, 23)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(102, 102, 102));
        jLabel6.setText("FECHA RESERVA");
        jPanel1.add(jLabel6);

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 60, 240, 40));

        jPanel2.setBackground(new java.awt.Color(227, 227, 227));

        jLabel2.setFont(new java.awt.Font("Segoe Script", 1, 21)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(102, 102, 102));
        jLabel2.setText("LUGARES A RESERVAR");
        jPanel2.add(jLabel2);

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 60, 280, 40));

        jPanel3.setBackground(new java.awt.Color(227, 227, 227));

        jLabel5.setFont(new java.awt.Font("Segoe Script", 1, 23)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(102, 102, 102));
        jLabel5.setText("OBSERVACIONES");
        jPanel3.add(jLabel5);

        getContentPane().add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 310, 250, 40));

        jPanel4.setBackground(new java.awt.Color(227, 227, 227));

        jLabel3.setFont(new java.awt.Font("Segoe Script", 1, 21)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(102, 102, 102));
        jLabel3.setText("NÚMERO DE DOCUMENTO");
        jPanel4.add(jLabel3);

        jPanel6.setBackground(new java.awt.Color(227, 227, 227));

        jLabel9.setFont(new java.awt.Font("Segoe Script", 1, 21)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(102, 102, 102));
        jLabel9.setText("RESERVA A NOMBRE DE");
        jPanel6.add(jLabel9);

        jPanel4.add(jPanel6);

        getContentPane().add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 210, 310, 40));

        jPanel5.setBackground(new java.awt.Color(227, 227, 227));
        jPanel5.setForeground(new java.awt.Color(102, 102, 102));

        jLabel7.setFont(new java.awt.Font("Segoe Script", 1, 20)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(102, 102, 102));
        jLabel7.setText("COSTO RESERVACIÓN $150 C/U");
        jPanel5.add(jLabel7);

        getContentPane().add(jPanel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 210, 400, 40));

        jPanel8.setBackground(new java.awt.Color(227, 227, 227));

        jLabel8.setFont(new java.awt.Font("Segoe Script", 1, 23)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(102, 102, 102));
        jLabel8.setText("Nº RESERVACIÓN");
        jPanel8.add(jLabel8);

        getContentPane().add(jPanel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 160, 240, 40));

        jPanel10.setBackground(new java.awt.Color(227, 227, 227));

        jLabel13.setFont(new java.awt.Font("Segoe Script", 1, 23)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(102, 102, 102));
        jLabel13.setText("E_MAIL");
        jPanel10.add(jLabel13);

        getContentPane().add(jPanel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 310, 140, 40));

        jPanel11.setBackground(new java.awt.Color(227, 227, 227));

        jLabel12.setFont(new java.awt.Font("Segoe Script", 1, 23)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(102, 102, 102));
        jLabel12.setText("NUMERO TELEFÓNICO");
        jPanel11.add(jLabel12);

        getContentPane().add(jPanel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 260, 280, 40));

        jPanel7.setBackground(new java.awt.Color(227, 227, 227));

        jLabel10.setFont(new java.awt.Font("Segoe Script", 1, 21)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(102, 102, 102));
        jLabel10.setText("RESERVA A NOMBRE DE");
        jPanel7.add(jLabel10);

        jPanel9.setBackground(new java.awt.Color(227, 227, 227));

        jLabel11.setFont(new java.awt.Font("Segoe Script", 1, 21)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(102, 102, 102));
        jLabel11.setText("RESERVA A NOMBRE DE");
        jPanel9.add(jLabel11);

        jPanel7.add(jPanel9);

        getContentPane().add(jPanel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 160, 310, 40));

        jsPersonas.setFont(new java.awt.Font("Segoe Script", 1, 23)); // NOI18N
        jsPersonas.setModel(new javax.swing.SpinnerNumberModel(1, 1, 60, 1));
        jsPersonas.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                jsPersonasStateChanged(evt);
            }
        });
        getContentPane().add(jsPersonas, new org.netbeans.lib.awtextra.AbsoluteConstraints(990, 60, 110, 40));

        campoFecha.setBackground(new java.awt.Color(227, 227, 227));
        campoFecha.setFont(new java.awt.Font("Segoe Script", 1, 20)); // NOI18N
        getContentPane().add(campoFecha, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 60, 190, 40));

        campoDni.setBackground(new java.awt.Color(227, 227, 227));
        campoDni.setFont(new java.awt.Font("Segoe Script", 1, 20)); // NOI18N
        getContentPane().add(campoDni, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 210, 200, 40));

        campoNombre.setBackground(new java.awt.Color(227, 227, 227));
        campoNombre.setFont(new java.awt.Font("Segoe Script", 1, 20)); // NOI18N
        campoNombre.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                campoNombreKeyTyped(evt);
            }
        });
        getContentPane().add(campoNombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 160, 200, 40));

        campoTelefono.setBackground(new java.awt.Color(227, 227, 227));
        campoTelefono.setFont(new java.awt.Font("Segoe Script", 1, 20)); // NOI18N
        getContentPane().add(campoTelefono, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 260, 200, 40));

        campoE_mail.setBackground(new java.awt.Color(227, 227, 227));
        campoE_mail.setFont(new java.awt.Font("Segoe Script", 1, 20)); // NOI18N
        getContentPane().add(campoE_mail, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 310, 200, 40));

        jPanel12.setBackground(new java.awt.Color(227, 227, 227));

        jLabel16.setFont(new java.awt.Font("Segoe Script", 1, 23)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(102, 102, 102));
        jLabel16.setText("HORA");
        jPanel12.add(jLabel16);

        getContentPane().add(jPanel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 60, 80, 40));

        jsHora.setFont(new java.awt.Font("Segoe Script", 1, 23)); // NOI18N
        jsHora.setModel(new javax.swing.SpinnerNumberModel(8, 8, 22, 1));
        jsHora.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                jsHoraStateChanged(evt);
            }
        });
        getContentPane().add(jsHora, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 60, 60, -1));

        jPanel13.setBackground(new java.awt.Color(227, 227, 227));
        jPanel13.setToolTipText("");

        jLabel14.setFont(new java.awt.Font("Segoe Script", 1, 23)); // NOI18N
        jLabel14.setText(":");
        jPanel13.add(jLabel14);

        getContentPane().add(jPanel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 60, -1, -1));

        jsMinuto.setFont(new java.awt.Font("Segoe Script", 1, 23)); // NOI18N
        jsMinuto.setModel(new javax.swing.SpinnerNumberModel(0, 0, 30, 30));
        jsMinuto.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                jsMinutoStateChanged(evt);
            }
        });
        getContentPane().add(jsMinuto, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 60, 60, -1));

        campoId.setBackground(new java.awt.Color(227, 227, 227));
        campoId.setFont(new java.awt.Font("Segoe Script", 1, 20)); // NOI18N
        getContentPane().add(campoId, new org.netbeans.lib.awtextra.AbsoluteConstraints(820, 160, 120, 40));

        cbVigente.setBackground(new java.awt.Color(227, 227, 227));
        cbVigente.setFont(new java.awt.Font("Segoe Script", 1, 20)); // NOI18N
        cbVigente.setForeground(new java.awt.Color(102, 102, 102));
        cbVigente.setText("VIGENTE");
        getContentPane().add(cbVigente, new org.netbeans.lib.awtextra.AbsoluteConstraints(950, 160, -1, -1));

        jsCosto.setFont(new java.awt.Font("Segoe Script", 1, 23)); // NOI18N
        jsCosto.setModel(new javax.swing.SpinnerNumberModel(Float.valueOf(150.0f), Float.valueOf(150.0f), Float.valueOf(60000.0f), Float.valueOf(50.0f)));
        jsCosto.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                jsCostoStateChanged(evt);
            }
        });
        getContentPane().add(jsCosto, new org.netbeans.lib.awtextra.AbsoluteConstraints(950, 210, 120, -1));

        jPanel14.setBackground(new java.awt.Color(227, 227, 227));

        jLabel15.setFont(new java.awt.Font("Segoe Script", 1, 23)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(102, 102, 102));
        jLabel15.setText(" NÚMERO DE MESA:");
        jPanel14.add(jLabel15);

        getContentPane().add(jPanel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 260, -1, 40));

        campoMesa.setBackground(new java.awt.Color(227, 227, 227));
        campoMesa.setFont(new java.awt.Font("Segoe Script", 1, 20)); // NOI18N
        campoMesa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                campoMesaActionPerformed(evt);
            }
        });
        campoMesa.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                campoMesaKeyTyped(evt);
            }
        });
        getContentPane().add(campoMesa, new org.netbeans.lib.awtextra.AbsoluteConstraints(820, 260, 260, 40));

        botonVerMesas.setFont(new java.awt.Font("Segoe UI Black", 0, 24)); // NOI18N
        botonVerMesas.setText("VERFICAR MESAS");
        botonVerMesas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonVerMesasActionPerformed(evt);
            }
        });
        getContentPane().add(botonVerMesas, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 110, 490, 40));

        botonGuardar.setFont(new java.awt.Font("Segoe UI Black", 0, 20)); // NOI18N
        botonGuardar.setText("GUARDAR");
        botonGuardar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        botonGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonGuardarActionPerformed(evt);
            }
        });
        getContentPane().add(botonGuardar, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 460, 150, 50));

        botonBuscar.setFont(new java.awt.Font("Segoe UI Black", 0, 20)); // NOI18N
        botonBuscar.setText("BUSCAR");
        botonBuscar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        botonBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonBuscarActionPerformed(evt);
            }
        });
        getContentPane().add(botonBuscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 460, 140, 50));

        botonActualizar.setFont(new java.awt.Font("Segoe UI Black", 0, 20)); // NOI18N
        botonActualizar.setText("ACTUALIZAR");
        botonActualizar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        botonActualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonActualizarActionPerformed(evt);
            }
        });
        getContentPane().add(botonActualizar, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 460, 190, 50));

        botonBorrar.setFont(new java.awt.Font("Segoe UI Black", 0, 20)); // NOI18N
        botonBorrar.setText("BORRAR");
        botonBorrar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        botonBorrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonBorrarActionPerformed(evt);
            }
        });
        getContentPane().add(botonBorrar, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 460, 150, 50));

        botonLimpiar.setFont(new java.awt.Font("Segoe UI Black", 0, 20)); // NOI18N
        botonLimpiar.setText("LIMPIAR");
        botonLimpiar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        botonLimpiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonLimpiarActionPerformed(evt);
            }
        });
        getContentPane().add(botonLimpiar, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 460, 150, 50));

        botonRegresar.setFont(new java.awt.Font("Segoe UI Black", 0, 20)); // NOI18N
        botonRegresar.setText("REGRESAR");
        botonRegresar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        botonRegresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonRegresarActionPerformed(evt);
            }
        });
        getContentPane().add(botonRegresar, new org.netbeans.lib.awtextra.AbsoluteConstraints(910, 460, 170, 50));

        jLabel4.setFont(new java.awt.Font("Trebuchet MS", 1, 25)); // NOI18N
        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/FondoM.png"))); // NOI18N
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1100, 580));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jsPersonasStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_jsPersonasStateChanged
       int personas=(int)jsPersonas.getValue();
        jsCosto.setValue(personas*150);
    }//GEN-LAST:event_jsPersonasStateChanged

    private void campoNombreKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_campoNombreKeyTyped
        char a = evt.getKeyChar();          //verifica que solo se ingresen letras.
        if (Character.isDigit(a)) {
            Toolkit.getDefaultToolkit().beep();
            evt.consume();
            JOptionPane.showMessageDialog(this, "Ingrese SOLAMENTE letras");
        }
    }//GEN-LAST:event_campoNombreKeyTyped

    private void jsHoraStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_jsHoraStateChanged
        // TODO add your handling code here:
    }//GEN-LAST:event_jsHoraStateChanged

    private void jsMinutoStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_jsMinutoStateChanged
        //jLabel2.setText("El valor es: "+jsCantidad.getValue().toString());
    }//GEN-LAST:event_jsMinutoStateChanged

    private void jsCostoStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_jsCostoStateChanged
        // TODO add your handling code here:
    }//GEN-LAST:event_jsCostoStateChanged

    private void campoMesaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_campoMesaActionPerformed

    }//GEN-LAST:event_campoMesaActionPerformed

    private void campoMesaKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_campoMesaKeyTyped
        char a = evt.getKeyChar();           //verifica que solo se ingresen NUMEROS.
        if (!Character.isDigit(a)) {
            Toolkit.getDefaultToolkit().beep();
            evt.consume();
        }
        JOptionPane.showMessageDialog(this, "Ingrese SOLAMENTE números");
    }//GEN-LAST:event_campoMesaKeyTyped

    private void botonVerMesasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonVerMesasActionPerformed
        //LLAMA A LA VISTA RESERVACIONES MESAS
        if(!campoFecha.getText().equals("")){
        
             LocalDate fecha = LocalDate.parse(campoFecha.getText(), DateTimeFormatter.ofPattern("yyyy-M-d"));
             int personas=(int)jsPersonas.getValue();
             int hora=((int) jsHora.getValue())*100;
             ReservacionesMesas reservacionesMesas= new ReservacionesMesas(fecha,hora,personas);
             if (opc == true) {
                reservacionesMesas.setVisible(true);
                opc = false;
                } 
             else {
                reservacionesMesas.dispose();
                opc = true;
                reservacionesMesas.setVisible(true);
                }
            }
        else {
            JOptionPane.showMessageDialog(this, "Ingrese la fecha, cantidad de personas y hora");

        }
        //         String f1;
        //        Date fe;
        //        fe = jfecha.getDate();
        //        String formato = jfecha.getDateFormatString();
        //        SimpleDateFormat sdf = new SimpleDateFormat(formato);
        //        f1 = String.valueOf(sdf.format(fe));
        //        MesasDisponibles map = new MesasDisponibles(f1);
        //        map
        
    }//GEN-LAST:event_botonVerMesasActionPerformed

    private void botonGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonGuardarActionPerformed
      //traigo as reservas con cliente con dni 00.00, son las reservas que vienen de la vista de ReservacionesMesas
    String mesasReservadas="";
    String reservasCreadas="";
       listaReservasDeMesas=(ArrayList)reservaData.listarReservasPorDni("0");
       if(listaReservasDeMesas.size()>0) //si la lista está vacía, no hago nada
       {  
        campoMesa.setText("0");
        if(!campoDni.getText().equals("") && !campoNombre.getText().equals("") && !campoMesa.getText().equals("") && !campoTelefono.getText().equals("") && !campoE_mail.getText().equals(""))
        {
             System.out.println("entro a boton guardar");
            //recupero la hora
            int minuto=(int) jsMinuto.getValue();
            int hora=((int) jsHora.getValue())*100+minuto;
            //recupero observaciones
            String observacion=campoObservacion.getText();
            // saco la marca de los campos
            camposColor(1);

            //creo un objeto cliente
            Cliente cliente= armarCliente();

            Boolean vigente=true;
            //recorro la lista de reservas nuevas para "armar cada reserva" y guardarla
            //uso un contador para saber si se guardaron todas las reservas
             int contador=listaReservasDeMesas.size();
             for(Reserva reservaNueva:listaReservasDeMesas){
                //creo un objeto reserva con todo lo que recuperé del formulario
                int id=reservaNueva.getId_reserva();
                Mesa mesa=reservaNueva.getMesa();
                LocalDate fecha=reservaNueva.getFecha();
                int personas=reservaNueva.getNumPersonas();
                double senia=150*personas;
                //voy guardando el id y la mesa para mostrarlo al final
                reservasCreadas+="-"+id;
                mesasReservadas+="-"+mesa.getId_mesa();
                Reserva reserva=new Reserva(id,mesa,cliente,fecha,hora,personas,senia,observacion,vigente);
                //ACTUALIZO la reserva en la base de datos, uso la clase dataReserva co el método guardarReserva
                int rta=reservaData.actualizarReserva(reserva);
                //ME QUEDA UNA RESERVACION MENOS EN LA LISTA....
                if(rta==1) contador--; 
                }
                if(contador==0)
                {
                    JOptionPane.showMessageDialog(this, "Operacion exitosa");
                    //muestro las reservas recién guardadas
                    campoId.setText(reservasCreadas);
                    //muestro las mesas de las reservas
                    campoMesa.setText(mesasReservadas);
                }
                else
                   JOptionPane.showMessageDialog(this, "Fallo de operacion");
            }
        else
         {
            //si falta algún campo le aviso al usuario
            JOptionPane.showMessageDialog(this, "COMPLETAR DATOS/ REGRESAR");
            camposColor(2);
         }
       }
    
        //////     String nom, f1, mes, mail, tel;
        //////                int np;
        //////                Date fe;
        //////                double cost;
        //////
        //////                nom = txtnombrepersonareserva.getText();
        //////                np = Integer.parseInt(txtnumeropersonas.getText());
        //////                cost = Double.parseDouble(txtcostoreservacion.getText());
        //////                mes = txtmesas.getText();
        //////
        //////                mail = txtmail.getText();
        //////                tel = txttelefono.getText();
        //////
        //////                Date fe = jDateChooser1.getDate();
        //////                String formato = jDateChooser1.getDateFormatString();
        //////                SimpleDateFormat sdf = new SimpleDateFormat(formato);
        //////                String f1 = String.valueOf(sdf.format(fe));
        //////
        //////                Connection conn = conexion.getConnection(); //Para tener conexión a la Base de Datos.
        //////
        //////                String sql = "INSERT INTO reservaciones(id_res,nombres,numpersonas,fecha,mesas,costo,tel,mail) VALUES (?,?,?,?,?,?,?,?)";
        //////                try {
            //////                        PreparedStatement pst = conn.prepareStatement(sql);
            //////                        pst.setString(1, null);
            //////                        pst.setString(2, nom);
            //////                        pst.setInt(3, np);
            //////                        pst.setString(4, f1);
            //////                        pst.setString(5, mes);
            //////                        pst.setDouble(6, cost);
            //////                        pst.setString(7, tel);
            //////                        pst.setString(8, mail);
            //////
            //////                        int n = pst.executeUpdate();
            //////                        if (n > 0) {
                //////                                JOptionPane.showMessageDialog(this, "RESERVACION REALIZADA");
                //////
                //////                                txtnombrepersonareserva.setText("");
                //////                                txttelefono.setText("");
                //////                                txtmail.setText("");
                //////                                txtnumeropersonas.setText("");
                //////                                txtcostoreservacion.setText("");
                //////                                txtmesas.setText("");
                //////                                jDateChooser1.setDate(null);                //Se vacian al registrar
                //////
                //////                                this.setLocationRelativeTo(null);
                //////                            }
            //////                    } catch (Exception e) {
            //////
            //////                        JOptionPane.showMessageDialog(this, "El error es:" + e.getMessage());
            //////                    }
    }//GEN-LAST:event_botonGuardarActionPerformed

    private void botonBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonBuscarActionPerformed
        Color  color=new Color(227,227,227);
        if(!campoId.getText().equals(""))
        {
            campoId.setBackground(color);
            int id=Integer.parseInt(campoId.getText());
            Reserva reserva=reservaData.buscarReservaId(id);
            
            if(reserva!=null)
            {
                limpiar();
                mostrarReserva(reserva);
            }
            else
            JOptionPane.showMessageDialog(this, "No se encontró la reserva Nº"+id);
        }
        else
        {
            JOptionPane.showMessageDialog(this, "Ingrese el ID");
            color=new Color(255,255,153);
            campoId.setBackground(color);
        }
    }//GEN-LAST:event_botonBuscarActionPerformed

    private void botonActualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonActualizarActionPerformed
        //  LocalDate fecha = LocalDate.parse(campoFecha.getText(), DateTimeFormatter.ofPattern("yyyy-M-d"));

        if(!campoId.getText().equals("")){
            int id=Integer.parseInt(campoId.getText());
            //Me fijo que esté la resera que quiero actualizar
            Reserva reservaAux=reservaData.buscarReservaId(id);
            if(reservaAux!=null){
                if(!campoDni.getText().equals("") && !campoNombre.getText().equals("") && !campoTelefono.getText().equals("") && !campoMesa.getText().equals("") && !campoE_mail.getText().equals(""))
                {
                    //cargo el id de la mesa y creo un objeto mesa con ese id
                    int idMesa=Integer.parseInt(campoMesa.getText());
                    Mesa mesa=new Mesa(idMesa);
                    //recupero la feccha y le doy formato
                    LocalDate fecha = LocalDate.parse(campoFecha.getText(), DateTimeFormatter.ofPattern("yyyy-M-d"));//("dd/MM/yyyy"));
                //recupero la hora
                int minuto=(int) jsMinuto.getValue();
                int hora=((int) jsHora.getValue())*100+minuto;
                //recupero  los lugares a reservar
                int personas=(int)jsPersonas.getValue();
                //recupro el costo
                double senia=(double) jsCosto.getValue();
                //recupero observaciones
                String observacion=campoObservacion.getText();

                boolean vigente=reservaAux.getVigente();

                // saco la marca de los campos
                camposColor(1);

                //creo un objeto cliente con la funcion armarCliente()
                Cliente cliente= armarCliente();

                //creo un objeto reserva con todo lo que recuperé del formulario
                Reserva reserva=new Reserva(id,mesa,cliente,fecha,hora,personas,senia,observacion,vigente);

                //guardo la reserva en la base de datos, uso la clase dataReserva co el método guardarReserva
                int rta=reservaData.actualizarReserva(reserva);

                //verifico si se guardó y aviso por sí o por no
                if(rta==1)
                JOptionPane.showMessageDialog(this, "Operacion exitosa");
                else
                JOptionPane.showMessageDialog(this, "Fallo de operacion");
            }
            else
            {
                //si falta algún campo le aviso al usuario
                JOptionPane.showMessageDialog(this, "COMPLETE los ");
                camposColor(2);
            }

        }
        else
        JOptionPane.showMessageDialog(this, "No se encontró la RESERVA Nº "+ id);
        }
        else
        {
            JOptionPane.showMessageDialog(this, "Ingrese el ID");
            Color  color=new Color(255,255,153);
            campoId.setBackground(color);
        }

    }//GEN-LAST:event_botonActualizarActionPerformed

    private void botonBorrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonBorrarActionPerformed
        int rta=0;
        Color  color=new Color(227,227,227);
        if(!campoId.getText().equals(""))
        {
            campoId.setBackground(Color.white);
            int id=Integer.parseInt(campoId.getText());
            Reserva reserva=reservaData.buscarReservaId(id);
            campoId.setBackground(color);
            if(reserva!=null)
            {
                rta=reservaData.borrarReserva(id);
                if(rta>0)
                JOptionPane.showMessageDialog(this, "Operacion exitosa");
                else
                JOptionPane.showMessageDialog(this, "Fallo de operacion");
            }
            else
            JOptionPane.showMessageDialog(this, "No se encontró la RESERVA Nº "+ id);
        }
        else
        {
            JOptionPane.showMessageDialog(this, "Ingrese el ID");
            color=new Color(255,255,153);
            campoId.setBackground(color);
        }
    }//GEN-LAST:event_botonBorrarActionPerformed

    private void botonLimpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonLimpiarActionPerformed
        limpiar();
    }//GEN-LAST:event_botonLimpiarActionPerformed

    private void botonRegresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonRegresarActionPerformed
    listaReservasDeMesas=(ArrayList)reservaData.listarReservasPorDni("0");
    int idBorrar=0;
    for(Reserva reservaNueva:listaReservasDeMesas){
            idBorrar=reservaNueva.getId_reserva();
            reservaData.borrarReserva(idBorrar);
     }  
    dispose();
    }//GEN-LAST:event_botonRegresarActionPerformed
private Cliente armarCliente(){
     Cliente cliente=null;  
     Cliente clienteAux;  
     Cliente clienteDevolver=null;
     int rta=0;
     //me fjo si el cliente existe 
     String dni=campoDni.getText();
     cliente=clienteData.buscarClienteDni(dni);
     //cargo los datos nuevos lo guardo en clienteAux
     String nombre=campoNombre.getText();
     String telefono=campoTelefono.getText();
     String e_mail=campoE_mail.getText();
     clienteAux=new Cliente(dni,nombre,telefono,e_mail);
     //si el cliente no existe, lo guardo
     if(cliente==null){
         rta=clienteData.guardarCliente(clienteAux);
     }
     else//si ya existe, me fijo si tiene los mismos datos
     {
         if(cliente!=clienteAux)//si los datos son distintos, lo actualizo
           rta=clienteData.actualizarCliente(clienteAux);
     }
      clienteDevolver=clienteData.buscarClienteDni(dni);
      return clienteDevolver;
 }
private void camposColor(int nuevoColor){
Color color;
if(nuevoColor==2)
    color=new Color(255,255,153);
else 
    color=new Color(227,227,227);
    
if(campoFecha.getText().equals(""))campoFecha.setBackground(color);
if(campoDni.getText().equals(""))campoDni.setBackground(color);
if(campoNombre.getText().equals(""))campoNombre.setBackground(color);
if(campoTelefono.getText().equals(""))campoTelefono.setBackground(color);
if(campoE_mail.getText().equals(""))campoE_mail.setBackground(color);
}
private void limpiar(){
    campoId.setText("");
    campoMesa.setText("");
    campoFecha.setText("");
    campoObservacion.setText("");
     
    campoDni.setText("");
    campoNombre.setText("");
    campoTelefono.setText("");
    campoE_mail.setText("");
    camposColor(1);

 }
private void mostrarReserva(Reserva reserva){
 String id= String.valueOf(reserva.getId_reserva());
 campoId.setText(id);
 
 String idMesa=String.valueOf(reserva.getMesa().getId_mesa());
 campoMesa.setText(idMesa);
 
  campoFecha.setText(reserva.getFecha().toString());
  
  campoObservacion.setText(reserva.getObsevacion());
  
  jsPersonas.setValue(reserva.getNumPersonas());
  
  int hora=reserva.getHora()/100;
  int minuto=reserva.getHora()%100;
  jsHora.setValue(hora);
  jsMinuto.setValue(minuto);
  
  jsCosto.setValue(reserva.getSenia());
  
 
 String dni=reserva.getCliente().getDni();
 Cliente cliente=clienteData.buscarClienteDni(dni);
 
 campoDni.setText(cliente.getDni());JOptionPane.showMessageDialog(this, cliente.getDni());
 campoNombre.setText(cliente.getNombre());JOptionPane.showMessageDialog(this,cliente.getNombre());
 campoTelefono.setText(cliente.getTelefono());JOptionPane.showMessageDialog(this, cliente.getTelefono());
 campoE_mail.setText(cliente.getE_mail());JOptionPane.showMessageDialog(this, cliente.getE_mail());

}  
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ReservacionesABM.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ReservacionesABM.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ReservacionesABM.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ReservacionesABM.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ReservacionesABM().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton botonActualizar;
    private javax.swing.JButton botonBorrar;
    private javax.swing.JButton botonBuscar;
    private javax.swing.JButton botonGuardar;
    private javax.swing.JButton botonLimpiar;
    private javax.swing.JButton botonRegresar;
    private javax.swing.JButton botonVerMesas;
    private javax.swing.JTextField campoDni;
    private javax.swing.JTextField campoE_mail;
    private javax.swing.JTextField campoFecha;
    private javax.swing.JTextField campoId;
    private javax.swing.JTextField campoMesa;
    private javax.swing.JTextField campoNombre;
    private javax.swing.JTextArea campoObservacion;
    private javax.swing.JTextField campoTelefono;
    private javax.swing.JCheckBox cbVigente;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSpinner jsCosto;
    private javax.swing.JSpinner jsHora;
    private javax.swing.JSpinner jsMinuto;
    private javax.swing.JSpinner jsPersonas;
    // End of variables declaration//GEN-END:variables
}
