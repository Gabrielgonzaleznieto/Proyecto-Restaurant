package vistas;

import java.awt.Color;
import java.awt.Font;
import java.awt.Toolkit;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;
import modelo.Reserva;
import modelo.ReservaData;
import modelo.conexion;

/**
 *
 * @author gabriel gonzalez
 */
public class ReservacionesListados extends javax.swing.JFrame {

    DefaultTableModel modelo;
    boolean opc = true;
    ReservacionesABM reservacionesABM = new ReservacionesABM();
    private ArrayList<Reserva> listaReservas;
    ReservaData reservaData;

    public ReservacionesListados() {

        initComponents();

     
        this.setLocationRelativeTo(null);
        Toolkit lo = Toolkit.getDefaultToolkit();                                          //AQUI LE DOY UN ICONO AL PROGRAMA.
        setIconImage(lo.getImage(getClass().getResource("/Imagenes/Portada.jpg")));       //AQUI LE DOY UN ICONO AL PROGRAMA.

       
        reservaData=new ReservaData();
        //ACA SE HACE TRANSPARENTE EL JTABLE.
        Tabla.setBackground(new Color(0, 0, 0, 0));
       ((DefaultTableCellRenderer) Tabla.getDefaultRenderer(Object.class)).setBackground(new Color(0, 0, 0, 0));
        Tabla.setGridColor(Color.DARK_GRAY);
        Tabla.setForeground(Color.DARK_GRAY);
        jScrollPane1.setBackground(new Color(0, 0, 0, 0));
        jScrollPane1.setOpaque(false);
        Tabla.setOpaque(false);
        ((DefaultTableCellRenderer) Tabla.getDefaultRenderer(Object.class)).setOpaque(false);
       // jScrollPane1.getViewport().setOpaque(false);
        Tabla.setShowGrid(true);
        
        //ACA CAMBIO LA LETRA Y EL TAMAÑO Y TAMBIEN AGRANDO O ACHICO LAS COLUMNAS DE LA TABLA.
//        Tabla.setFont(new Font("Tahoma",1,13));
//        TableColumn TableColumn = Tabla.getColumnModel().getColumn(0);
//        TableColumn.setPreferredWidth(10);
//        TableColumn TableColumn1 = Tabla.getColumnModel().getColumn(1);
//        TableColumn1.setPreferredWidth(80);
//        TableColumn TableColumn2 = Tabla.getColumnModel().getColumn(2);
//        TableColumn2.setPreferredWidth(50);
//        TableColumn TableColumn3 = Tabla.getColumnModel().getColumn(3);
//        TableColumn3.setPreferredWidth(20);
//        TableColumn TableColumn4 = Tabla.getColumnModel().getColumn(4);
//        TableColumn4.setPreferredWidth(20);
//        TableColumn TableColumn5 = Tabla.getColumnModel().getColumn(5);
//        TableColumn5.setPreferredWidth(20);
//        TableColumn TableColumn6 = Tabla.getColumnModel().getColumn(6);
//        TableColumn6.setPreferredWidth(20);
        
        modelo=new DefaultTableModel();
        modelo.addColumn("Id Reserva");
        modelo.addColumn("Nº Mesa");
        modelo.addColumn("Cliente");
        modelo.addColumn("Fecha");
        modelo.addColumn("Hora");
        modelo.addColumn("Cantidad de Personas");
        modelo.addColumn("Seña");
        modelo.addColumn("Vigente");
        modelo.addColumn("Observaciones");
        Tabla.setModel(modelo);
        cargarTabla();
    }

    private void cerrar_ventana() {

        String botones[] = {"ACEPTAR", "CANCELAR"};
        int eleccion = JOptionPane.showOptionDialog(this, "¿DESEA ELIMINAR EL REGISTRO?", null, 0, 0, null, botones, this);
        if (eleccion == JOptionPane.YES_OPTION) {
        } else if (eleccion == JOptionPane.NO_OPTION) {
            System.out.println("Se cancelo el cierre");
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnABM = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        btbSalir = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        Tabla = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setUndecorated(true);
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnABM.setFont(new java.awt.Font("Segoe UI Black", 1, 20)); // NOI18N
        btnABM.setText("ABM Reservas");
        btnABM.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnABM.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnABMActionPerformed(evt);
            }
        });
        getContentPane().add(btnABM, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 130, 190, 40));

        btnEliminar.setFont(new java.awt.Font("Segoe UI Black", 1, 20)); // NOI18N
        btnEliminar.setText("ELIMINAR");
        btnEliminar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });
        getContentPane().add(btnEliminar, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 130, 200, 40));

        btbSalir.setFont(new java.awt.Font("Segoe UI Black", 1, 20)); // NOI18N
        btbSalir.setText("SALIR");
        btbSalir.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btbSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btbSalirActionPerformed(evt);
            }
        });
        getContentPane().add(btbSalir, new org.netbeans.lib.awtextra.AbsoluteConstraints(840, 130, 190, 40));

        Tabla.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jScrollPane1.setViewportView(Tabla);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 180, 970, 350));

        jLabel2.setFont(new java.awt.Font("Segoe Script", 0, 35)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(102, 102, 102));
        jLabel2.setText("RESERVAS");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 50, 600, 40));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/FondoM.png"))); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1100, 580));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btbSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btbSalirActionPerformed
        dispose();
    }//GEN-LAST:event_btbSalirActionPerformed

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
    int rta=0;
    int row = Tabla.getSelectedRow();
    String idCadena = Tabla.getValueAt(row, 0).toString();
    int id=Integer.parseInt(idCadena);
    Reserva reserva=reservaData.buscarReservaId(id);
    if(reserva!=null)
            { //confirmo si quiere eliminar
                rta=confirmar_ventana();
                if(rta==1)
                { //si me dice que si, devuelve un 1, y elimino el empleado
                    rta=reservaData.borrarReserva(id);
                    //aviso si se eliminó o no
                    if(rta==1) 
                        JOptionPane.showMessageDialog(this, "Operacion exitosa");
                    else 
                        JOptionPane.showMessageDialog(this, "Fallo de operacion");
                }
                else JOptionPane.showMessageDialog(this, "Operación CANCELADA");
            }
        else
            JOptionPane.showMessageDialog(this, "NO EXISTE la RESERVA Nº "+id);
   cargarTabla();    
//        cerrar_ventana();
//
//        int row = jTable1.getSelectedRow();
//        String id = jTable1.getValueAt(row, 0).toString();
//        String result = null;
//        Connection conn = conexion.getConnection(); //Para tener conexión a la Base de Datos.
//
//        String sql = "DELETE FROM reservaciones WHERE id_res=?";
//        try {
//            Connection cn = conexion.getConnection();
//            PreparedStatement ps = cn.prepareStatement(sql);
//            ps.setString(1, id);
//            int n = ps.executeUpdate();
//            cn.close();
//            ps.close();
//            if (n > 0) {
//                JOptionPane.showMessageDialog(this, "Reserva Eliminada");
//            }
//        } catch (Exception e) {
//            System.out.println("Error: " + e.getMessage());
//            result = e.getMessage();
//        }
    }//GEN-LAST:event_btnEliminarActionPerformed

    private void btnABMActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnABMActionPerformed
       if (opc == true) {
            reservacionesABM.setVisible(true);
            opc = false;
        } else {
            reservacionesABM.dispose();
            opc = true;
            reservacionesABM.setVisible(true);
        }
    }//GEN-LAST:event_btnABMActionPerformed

  private int confirmar_ventana() {
      String botones[] = {"BORRAR", "CANCELAR"};
      int rta=0;
      int eleccion = JOptionPane.showOptionDialog(this, "Los DATOS se BORRARAN  permenentemente", "SOFTWARE PROGRAMADORES 3.0 ULP SAN LUIS ARGENTINA", 0, 0, null, botones, this);
      if (eleccion == JOptionPane.YES_OPTION)  rta=1;
      return rta;
    }  
  public void cargarTabla(){
   borraFilasTabla(); 
   listaReservas=(ArrayList)reservaData.listarReservas();
   for(Reserva m:listaReservas){
      LocalDate fecha=m.getFecha();
      String fechaCadena=fecha.toString(); 
      String senia= String.valueOf(m.getSenia() );
      String vigente="SI";
      if(!m.getVigente()) vigente="NO";
      modelo.addRow(new Object[]{m.getId_reserva(),m.getMesa().getId_mesa(), m.getCliente().getDni(),fecha,m.getHora(),m.getNumPersonas(),senia,vigente,m.getObsevacion()});
    }
   }
public void borraFilasTabla(){
  int a =modelo.getRowCount()-1;
  System.out.println("Tabla "+a);
  for(int i=a;i>=0;i--)
    {modelo.removeRow(i );}
  }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ReservacionesListados.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ReservacionesListados.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ReservacionesListados.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ReservacionesListados.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ReservacionesListados().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable Tabla;
    private javax.swing.JButton btbSalir;
    private javax.swing.JButton btnABM;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables

    
}
