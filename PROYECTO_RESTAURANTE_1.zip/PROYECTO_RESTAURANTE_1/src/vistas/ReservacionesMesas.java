package vistas;


import java.awt.Toolkit;
import java.awt.event.KeyEvent;
import java.net.URL;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import modelo.Cliente;
import modelo.Mesa;
import modelo.MesaData;
import modelo.Reserva;
import modelo.ReservaData;
import modelo.conexion;


/**
 *
 * @author gabriel gonzalez
 */
public class ReservacionesMesas extends javax.swing.JFrame {

    URL url = getClass().getResource("/Imagenes/MesaOcupada.png");
    ImageIcon imagenOcupada = new ImageIcon(url);
    URL urll = getClass().getResource("/Imagenes/MesaLibre.png");
    ImageIcon imagenLibre = new ImageIcon(urll);
    MesaData mesaData;
    ReservaData reservaData; 
    private int mesaElegida;
    private ArrayList<Reserva> listaReservas; 
    private ArrayList<Mesa> listaMesas; 
    private LocalDate fecha;
    private ArrayList<Integer> idMesasReservadas;
    private ArrayList<Integer> idNuevasReservadas; 
    private int cantidadLugares;
    private int hora;
    
 public ReservacionesMesas(LocalDate fecha,int hora, int cantidadLugares) {

        initComponents();
        //mesasv();
        this.fecha=fecha;
        this.hora=hora;
        this.cantidadLugares=cantidadLugares;
        mesaData=new MesaData();
        reservaData=new ReservaData();
        idMesasReservadas = new ArrayList<Integer>();
        idNuevasReservadas = new ArrayList<Integer>();
        
        this.setLocationRelativeTo(null);
        Toolkit lo = Toolkit.getDefaultToolkit();                                          //AQUI LE DOY UN ICONO AL PROGRAMA.
        setIconImage(lo.getImage(getClass().getResource("/Imagenes/Portada.jpg")));       //AQUI LE DOY UN ICONO AL PROGRAMA.
        //carga la fecha en el campo fecha
        
        String fechaCadena=fecha.toString();
        campoFecha.setText(fechaCadena);
        //traigo el listado de las mesas
        listaMesas=(ArrayList)mesaData.listarMesas();
        //habilito las mesas que no estan en el listado
        habilitarMesas();
        //cambia la imagen de la mesa ocupada
        limpiarMesas();
        cargarReservasDelDia();
        jsPersonas.setValue(cantidadLugares);
        if(hora<1600) labelTitulo.setText("ALMUERZO");
        else labelTitulo.setText("CENA");
    }
 private void habilitarMesas(){
    int idMesaHabilitada;
    String capacidad;
    for(Mesa mesa:listaMesas){
        idMesaHabilitada=mesa.getId_mesa();  
        capacidad=String.valueOf(mesa.getCantidad());
         switch(idMesaHabilitada){ 
          case 1: mesa1.setEnabled(true); label101.setText(" "+capacidad+" lugares");  break;
          case 2: mesa2.setEnabled(true); label102.setText(" "+capacidad+" lugares");  break;
          case 3: mesa3.setEnabled(true); label103.setText(" "+capacidad+" lugares");  break;
          case 4: mesa4.setEnabled(true); label104.setText(" "+capacidad+" lugares");  break;
          case 5: mesa5.setEnabled(true); label105.setText(" "+capacidad+" lugares");  break;
          
          case 6: mesa6.setEnabled(true); label106.setText(" "+capacidad+" lugares");  break;
          case 7: mesa7.setEnabled(true); label107.setText(" "+capacidad+" lugares");  break;
          case 8: mesa8.setEnabled(true); label108.setText(" "+capacidad+" lugares");  break;
          case 9: mesa9.setEnabled(true); label109.setText(" "+capacidad+" lugares");  break;
          case 10: mesa10.setEnabled(true); label110.setText(" "+capacidad+" lugares");  break;  
          
          case 11: mesa11.setEnabled(true); label111.setText(" "+capacidad+" lugares");  break;
          case 12: mesa12.setEnabled(true); label112.setText(" "+capacidad+" lugares");  break;
          case 13: mesa13.setEnabled(true); label113.setText(" "+capacidad+" lugares");  break;
          case 14: mesa14.setEnabled(true); label114.setText(" "+capacidad+" lugares");  break;
          case 15: mesa15.setEnabled(true); label115.setText(" "+capacidad+" lugares");  break;
    }
   }
}
 private void limpiarMesas(){ 
       mesa1.setIcon(imagenLibre);mesa1.setFocusable(true);
       mesa2.setIcon(imagenLibre);mesa2.setFocusable(true);
       mesa3.setIcon(imagenLibre);mesa3.setFocusable(true);
       mesa4.setIcon(imagenLibre);mesa4.setFocusable(true);
       mesa5.setIcon(imagenLibre);mesa5.setFocusable(true);

       mesa6.setIcon(imagenLibre);mesa6.setFocusable(true);
       mesa7.setIcon(imagenLibre);mesa7.setFocusable(true);
       mesa8.setIcon(imagenLibre);mesa8.setFocusable(true);
       mesa9.setIcon(imagenLibre);mesa9.setFocusable(true);
       mesa10.setIcon(imagenLibre);mesa10.setFocusable(true);

       mesa11.setIcon(imagenLibre);mesa11.setFocusable(true);
       mesa12.setIcon(imagenLibre);mesa12.setFocusable(true);
       mesa13.setIcon(imagenLibre);mesa13.setFocusable(true);
       mesa14.setIcon(imagenLibre);mesa14.setFocusable(true);
       mesa15.setIcon(imagenLibre); mesa15.setFocusable(true);
    }
 private void cargarReservasDelDia(){
 fecha = LocalDate.parse(campoFecha.getText(), DateTimeFormatter.ofPattern("yyyy-M-d"));
 listaReservas=(ArrayList)reservaData.listarReservas();
 int idMesa;
 for(Reserva reserva:listaReservas){
    idMesa=reserva.getMesa().getId_mesa(); 
    if(reserva.getFecha().compareTo(fecha)==0 && ((hora<1600 && reserva.getHora()<1600)|| (hora>1600 && reserva.getHora()>1600))){
      switch(idMesa){ 
      case 1: mesa1.setIcon(imagenOcupada);mesa1.setFocusable(false);idMesasReservadas.add(idMesa); break;
      case 2: mesa2.setIcon(imagenOcupada);mesa2.setFocusable(false);idMesasReservadas.add(idMesa);break;
      case 3: mesa3.setIcon(imagenOcupada);mesa3.setFocusable(false);idMesasReservadas.add(idMesa);break;
      case 4: mesa4.setIcon(imagenOcupada);mesa4.setFocusable(false);idMesasReservadas.add(idMesa);break;
      case 5: mesa5.setIcon(imagenOcupada);mesa5.setFocusable(false);idMesasReservadas.add(idMesa);break;

      case 6: mesa6.setIcon(imagenOcupada);mesa6.setFocusable(false);idMesasReservadas.add(idMesa);break;
      case 7: mesa7.setIcon(imagenOcupada);mesa7.setFocusable(false);idMesasReservadas.add(idMesa);break;
      case 8: mesa8.setIcon(imagenOcupada);mesa8.setFocusable(false);idMesasReservadas.add(idMesa);break;
      case 9: mesa9.setIcon(imagenOcupada);mesa9.setFocusable(false);idMesasReservadas.add(idMesa);break;
      case 10: mesa10.setIcon(imagenOcupada);mesa10.setFocusable(false);idMesasReservadas.add(idMesa);break;

      case 11: mesa11.setIcon(imagenOcupada);mesa11.setFocusable(false);idMesasReservadas.add(idMesa);break;
      case 12: mesa12.setIcon(imagenOcupada);mesa12.setFocusable(false);idMesasReservadas.add(idMesa);break;
      case 13: mesa13.setIcon(imagenOcupada);mesa13.setFocusable(false);idMesasReservadas.add(idMesa);break;
      case 14: mesa14.setIcon(imagenOcupada);mesa14.setFocusable(false);idMesasReservadas.add(idMesa);break;
      case 15: mesa15.setIcon(imagenOcupada);mesa15.setFocusable(false);idMesasReservadas.add(idMesa);break;
      }
    }
  }
 }
 private void cambiarLugares(int id, String operacion){
    Mesa mesa=mesaData.buscarMesa(id);
    int capacidadMesa=mesa.getCantidad();
    int lugares=(int) jsPersonas.getValue();
    if(operacion.equals("SUMAR"))
        jsPersonas.setValue(lugares+capacidadMesa);
    else
        jsPersonas.setValue(lugares-capacidadMesa);
} 
 
 

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        label1 = new javax.swing.JLabel();
        label2 = new javax.swing.JLabel();
        label3 = new javax.swing.JLabel();
        label4 = new javax.swing.JLabel();
        label5 = new javax.swing.JLabel();
        label6 = new javax.swing.JLabel();
        label7 = new javax.swing.JLabel();
        label8 = new javax.swing.JLabel();
        label9 = new javax.swing.JLabel();
        label10 = new javax.swing.JLabel();
        label11 = new javax.swing.JLabel();
        label12 = new javax.swing.JLabel();
        label13 = new javax.swing.JLabel();
        label14 = new javax.swing.JLabel();
        label15 = new javax.swing.JLabel();
        mesa1 = new javax.swing.JLabel();
        mesa2 = new javax.swing.JLabel();
        mesa3 = new javax.swing.JLabel();
        mesa4 = new javax.swing.JLabel();
        mesa5 = new javax.swing.JLabel();
        mesa6 = new javax.swing.JLabel();
        mesa7 = new javax.swing.JLabel();
        mesa8 = new javax.swing.JLabel();
        mesa9 = new javax.swing.JLabel();
        mesa10 = new javax.swing.JLabel();
        mesa11 = new javax.swing.JLabel();
        mesa12 = new javax.swing.JLabel();
        mesa13 = new javax.swing.JLabel();
        mesa14 = new javax.swing.JLabel();
        mesa15 = new javax.swing.JLabel();
        btnSALIR = new javax.swing.JButton();
        labelTitulo = new javax.swing.JLabel();
        campoFecha = new javax.swing.JTextField();
        botonConfirmar = new javax.swing.JButton();
        botonCancelar = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        label102 = new javax.swing.JLabel();
        label101 = new javax.swing.JLabel();
        label103 = new javax.swing.JLabel();
        label104 = new javax.swing.JLabel();
        label105 = new javax.swing.JLabel();
        label106 = new javax.swing.JLabel();
        label107 = new javax.swing.JLabel();
        label108 = new javax.swing.JLabel();
        label109 = new javax.swing.JLabel();
        label110 = new javax.swing.JLabel();
        label111 = new javax.swing.JLabel();
        label112 = new javax.swing.JLabel();
        label113 = new javax.swing.JLabel();
        label114 = new javax.swing.JLabel();
        label115 = new javax.swing.JLabel();
        jsPersonas = new javax.swing.JSpinner();
        jLabel2 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Mapa de mesas");
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        label1.setBackground(new java.awt.Color(204, 204, 255));
        label1.setFont(new java.awt.Font("Segoe UI Black", 1, 16)); // NOI18N
        label1.setText("MESA 1");
        getContentPane().add(label1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 150, 70, 30));

        label2.setBackground(new java.awt.Color(204, 204, 255));
        label2.setFont(new java.awt.Font("Segoe UI Black", 1, 16)); // NOI18N
        label2.setText("MESA 2");
        getContentPane().add(label2, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 140, 80, 30));

        label3.setBackground(new java.awt.Color(204, 204, 255));
        label3.setFont(new java.awt.Font("Segoe UI Black", 1, 16)); // NOI18N
        label3.setText("MESA 3");
        getContentPane().add(label3, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 140, 70, 30));

        label4.setBackground(new java.awt.Color(204, 204, 255));
        label4.setFont(new java.awt.Font("Segoe UI Black", 1, 16)); // NOI18N
        label4.setText("MESA 4");
        getContentPane().add(label4, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 140, 70, 30));

        label5.setBackground(new java.awt.Color(204, 204, 255));
        label5.setFont(new java.awt.Font("Segoe UI Black", 1, 16)); // NOI18N
        label5.setText("MESA 5");
        getContentPane().add(label5, new org.netbeans.lib.awtextra.AbsoluteConstraints(870, 140, 70, 30));

        label6.setBackground(new java.awt.Color(204, 204, 255));
        label6.setFont(new java.awt.Font("Segoe UI Black", 1, 16)); // NOI18N
        label6.setText("MESA 6");
        getContentPane().add(label6, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 260, 80, -1));

        label7.setBackground(new java.awt.Color(204, 204, 255));
        label7.setFont(new java.awt.Font("Segoe UI Black", 1, 16)); // NOI18N
        label7.setText("MESA 7");
        getContentPane().add(label7, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 260, 70, -1));

        label8.setBackground(new java.awt.Color(204, 204, 255));
        label8.setFont(new java.awt.Font("Segoe UI Black", 1, 16)); // NOI18N
        label8.setText("MESA 8");
        getContentPane().add(label8, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 260, 70, -1));

        label9.setBackground(new java.awt.Color(204, 204, 255));
        label9.setFont(new java.awt.Font("Segoe UI Black", 1, 16)); // NOI18N
        label9.setText("MESA 9");
        getContentPane().add(label9, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 260, 70, -1));

        label10.setBackground(new java.awt.Color(204, 204, 255));
        label10.setFont(new java.awt.Font("Segoe UI Black", 1, 16)); // NOI18N
        label10.setText("MESA 10");
        getContentPane().add(label10, new org.netbeans.lib.awtextra.AbsoluteConstraints(860, 260, -1, -1));

        label11.setBackground(new java.awt.Color(204, 204, 255));
        label11.setFont(new java.awt.Font("Segoe UI Black", 1, 16)); // NOI18N
        label11.setText("MESA 11");
        getContentPane().add(label11, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 380, -1, -1));

        label12.setBackground(new java.awt.Color(204, 204, 255));
        label12.setFont(new java.awt.Font("Segoe UI Black", 1, 16)); // NOI18N
        label12.setText("MESA 12");
        getContentPane().add(label12, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 390, -1, -1));

        label13.setBackground(new java.awt.Color(204, 204, 255));
        label13.setFont(new java.awt.Font("Segoe UI Black", 1, 16)); // NOI18N
        label13.setText("MESA 13");
        getContentPane().add(label13, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 390, -1, -1));

        label14.setBackground(new java.awt.Color(204, 204, 255));
        label14.setFont(new java.awt.Font("Segoe UI Black", 1, 16)); // NOI18N
        label14.setText("MESA 14");
        getContentPane().add(label14, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 390, -1, -1));

        label15.setBackground(new java.awt.Color(204, 204, 255));
        label15.setFont(new java.awt.Font("Segoe UI Black", 1, 16)); // NOI18N
        label15.setText("MESA 15");
        getContentPane().add(label15, new org.netbeans.lib.awtextra.AbsoluteConstraints(860, 390, -1, -1));

        mesa1.setBorder(new javax.swing.border.MatteBorder(null));
        mesa1.setEnabled(false);
        mesa1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                mesa1MouseClicked(evt);
            }
        });
        getContentPane().add(mesa1, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 150, 110, 80));

        mesa2.setBorder(new javax.swing.border.MatteBorder(null));
        mesa2.setEnabled(false);
        mesa2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                mesa2MouseClicked(evt);
            }
        });
        getContentPane().add(mesa2, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 150, 110, 80));

        mesa3.setBorder(new javax.swing.border.MatteBorder(null));
        mesa3.setEnabled(false);
        mesa3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                mesa3MouseClicked(evt);
            }
        });
        getContentPane().add(mesa3, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 150, 110, 80));

        mesa4.setBorder(new javax.swing.border.MatteBorder(null));
        mesa4.setEnabled(false);
        mesa4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                mesa4MouseClicked(evt);
            }
        });
        getContentPane().add(mesa4, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 150, 110, 80));

        mesa5.setBorder(new javax.swing.border.MatteBorder(null));
        mesa5.setEnabled(false);
        mesa5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                mesa5MouseClicked(evt);
            }
        });
        getContentPane().add(mesa5, new org.netbeans.lib.awtextra.AbsoluteConstraints(940, 150, 100, 80));

        mesa6.setBorder(new javax.swing.border.MatteBorder(null));
        mesa6.setEnabled(false);
        mesa6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                mesa6MouseClicked(evt);
            }
        });
        getContentPane().add(mesa6, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 260, 110, 80));

        mesa7.setBorder(new javax.swing.border.MatteBorder(null));
        mesa7.setEnabled(false);
        mesa7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                mesa7MouseClicked(evt);
            }
        });
        getContentPane().add(mesa7, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 260, 110, 80));

        mesa8.setBorder(new javax.swing.border.MatteBorder(null));
        mesa8.setEnabled(false);
        mesa8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                mesa8MouseClicked(evt);
            }
        });
        getContentPane().add(mesa8, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 260, 110, 80));

        mesa9.setBorder(new javax.swing.border.MatteBorder(null));
        mesa9.setEnabled(false);
        mesa9.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                mesa9MouseClicked(evt);
            }
        });
        getContentPane().add(mesa9, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 260, 110, 80));

        mesa10.setBorder(new javax.swing.border.MatteBorder(null));
        mesa10.setEnabled(false);
        mesa10.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                mesa10MouseClicked(evt);
            }
        });
        getContentPane().add(mesa10, new org.netbeans.lib.awtextra.AbsoluteConstraints(940, 260, 100, 80));

        mesa11.setBorder(new javax.swing.border.MatteBorder(null));
        mesa11.setEnabled(false);
        mesa11.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                mesa11MouseClicked(evt);
            }
        });
        getContentPane().add(mesa11, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 390, 110, 80));

        mesa12.setBorder(new javax.swing.border.MatteBorder(null));
        mesa12.setEnabled(false);
        mesa12.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                mesa12MouseClicked(evt);
            }
        });
        getContentPane().add(mesa12, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 390, 110, 80));

        mesa13.setBorder(new javax.swing.border.MatteBorder(null));
        mesa13.setEnabled(false);
        mesa13.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                mesa13MouseClicked(evt);
            }
        });
        getContentPane().add(mesa13, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 390, 110, 80));

        mesa14.setBorder(new javax.swing.border.MatteBorder(null));
        mesa14.setEnabled(false);
        mesa14.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                mesa14MouseClicked(evt);
            }
        });
        getContentPane().add(mesa14, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 390, 110, 80));

        mesa15.setBorder(new javax.swing.border.MatteBorder(null));
        mesa15.setEnabled(false);
        mesa15.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                mesa15MouseClicked(evt);
            }
        });
        getContentPane().add(mesa15, new org.netbeans.lib.awtextra.AbsoluteConstraints(940, 390, 110, 80));

        btnSALIR.setFont(new java.awt.Font("Segoe UI Black", 1, 20)); // NOI18N
        btnSALIR.setText("REGRESAR");
        btnSALIR.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnSALIR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSALIRActionPerformed(evt);
            }
        });
        getContentPane().add(btnSALIR, new org.netbeans.lib.awtextra.AbsoluteConstraints(930, 510, 140, 40));

        labelTitulo.setFont(new java.awt.Font("Segoe Script", 1, 28)); // NOI18N
        labelTitulo.setText("ALMUERZO");
        getContentPane().add(labelTitulo, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 20, 210, 50));

        campoFecha.setBackground(new java.awt.Color(227, 227, 227));
        campoFecha.setFont(new java.awt.Font("Segoe Script", 1, 18)); // NOI18N
        campoFecha.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                campoFechaKeyPressed(evt);
            }
        });
        getContentPane().add(campoFecha, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 90, 210, 30));

        botonConfirmar.setFont(new java.awt.Font("Segoe UI Black", 1, 20)); // NOI18N
        botonConfirmar.setText("CONFIRMAR");
        botonConfirmar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        botonConfirmar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonConfirmarActionPerformed(evt);
            }
        });
        getContentPane().add(botonConfirmar, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 510, 140, 40));

        botonCancelar.setFont(new java.awt.Font("Segoe UI Black", 1, 20)); // NOI18N
        botonCancelar.setText("CANCELAR");
        botonCancelar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        botonCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonCancelarActionPerformed(evt);
            }
        });
        getContentPane().add(botonCancelar, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 510, 140, 40));

        jButton1.setBackground(new java.awt.Color(204, 102, 0));
        jButton1.setFont(new java.awt.Font("Segoe Script", 1, 14)); // NOI18N
        jButton1.setText("OCUPADA");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(930, 20, 120, 30));

        jButton2.setBackground(new java.awt.Color(0, 204, 0));
        jButton2.setFont(new java.awt.Font("Segoe Script", 1, 14)); // NOI18N
        jButton2.setText("LIBRE");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 20, 90, -1));

        label102.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        label102.setText("MESA 1");
        getContentPane().add(label102, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 180, 70, 30));

        label101.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        label101.setText("MESA 1");
        getContentPane().add(label101, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 180, 70, 30));

        label103.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        label103.setText("MESA 1");
        getContentPane().add(label103, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 180, 70, 30));

        label104.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        label104.setText("MESA 1");
        getContentPane().add(label104, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 180, 70, 30));

        label105.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        label105.setText("MESA 1");
        getContentPane().add(label105, new org.netbeans.lib.awtextra.AbsoluteConstraints(870, 180, 70, 30));

        label106.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        label106.setText("MESA 1");
        getContentPane().add(label106, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 290, 70, 30));

        label107.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        label107.setText("MESA 1");
        getContentPane().add(label107, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 290, 70, 30));

        label108.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        label108.setText("MESA 1");
        getContentPane().add(label108, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 290, 70, 30));

        label109.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        label109.setText("MESA 1");
        getContentPane().add(label109, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 290, 70, 30));

        label110.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        label110.setText("MESA 1");
        getContentPane().add(label110, new org.netbeans.lib.awtextra.AbsoluteConstraints(860, 290, 70, 30));

        label111.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        label111.setText("MESA 1");
        getContentPane().add(label111, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 410, 70, 30));

        label112.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        label112.setText("MESA 1");
        getContentPane().add(label112, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 420, 70, 30));

        label113.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        label113.setText("MESA 1");
        getContentPane().add(label113, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 420, 70, 30));

        label114.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        label114.setText("MESA 1");
        getContentPane().add(label114, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 420, 70, 30));

        label115.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        label115.setText("MESA 1");
        getContentPane().add(label115, new org.netbeans.lib.awtextra.AbsoluteConstraints(860, 420, 70, 30));

        jsPersonas.setFont(new java.awt.Font("Segoe Script", 1, 18)); // NOI18N
        jsPersonas.setModel(new javax.swing.SpinnerNumberModel(1, 1, 60, 1));
        jsPersonas.setFocusable(false);
        jsPersonas.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                jsPersonasStateChanged(evt);
            }
        });
        getContentPane().add(jsPersonas, new org.netbeans.lib.awtextra.AbsoluteConstraints(939, 90, 90, 30));

        jLabel2.setFont(new java.awt.Font("Segoe Script", 1, 18)); // NOI18N
        jLabel2.setText("LUGARES A RESERVAR");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 90, -1, -1));

        jLabel23.setFont(new java.awt.Font("Segoe Script", 1, 18)); // NOI18N
        jLabel23.setText("RESERVACIÓN DE MESAS DEL DÍA");
        getContentPane().add(jLabel23, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 80, 370, 50));

        jLabel3.setFont(new java.awt.Font("Segoe UI Black", 1, 16)); // NOI18N
        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/FondoM.png"))); // NOI18N
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1100, 580));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnSALIRActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSALIRActionPerformed
       dispose(); 
    }//GEN-LAST:event_btnSALIRActionPerformed

    private void mesa1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mesa1MouseClicked
      if(mesa1.getIcon().equals(imagenLibre))
       {
          cambiarLugares(1,"RESTAR"); 
          mesa1.setIcon(imagenOcupada);
          idNuevasReservadas.add(1);
       }
       else {
           cambiarLugares(1,"SUMAR");
           mesa1.setIcon(imagenLibre);
           idNuevasReservadas.remove(1);
       }
    }//GEN-LAST:event_mesa1MouseClicked

    private void mesa2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mesa2MouseClicked
        if(mesa2.getIcon().equals(imagenLibre))
       {
           cambiarLugares(2,"RESTAR"); 
           mesa2.setIcon(imagenOcupada);
           idNuevasReservadas.add(2);
       }
       else {
           cambiarLugares(2,"SUMAR");
           mesa2.setIcon(imagenLibre);
           idNuevasReservadas.remove(2);
       } 
    }//GEN-LAST:event_mesa2MouseClicked

    private void mesa3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mesa3MouseClicked
       if(mesa3.getIcon().equals(imagenLibre))
       {
           cambiarLugares(3,"RESTAR"); 
           mesa3.setIcon(imagenOcupada);
           idNuevasReservadas.add(3);
       }
       else {
           cambiarLugares(3,"SUMAR");
           mesa3.setIcon(imagenLibre);
           idNuevasReservadas.remove(3);
       } 
    }//GEN-LAST:event_mesa3MouseClicked

    private void mesa4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mesa4MouseClicked
      if(mesa4.getIcon().equals(imagenLibre))
       {
          cambiarLugares(4,"RESTAR"); 
           mesa4.setIcon(imagenOcupada);
           idNuevasReservadas.add(4);
       }
       else {
           cambiarLugares(4,"SUMAR");
           mesa4.setIcon(imagenLibre);
           idNuevasReservadas.remove(4);
       } 
    }//GEN-LAST:event_mesa4MouseClicked

    private void mesa5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mesa5MouseClicked
        if(mesa5.getIcon().equals(imagenLibre))
       {
           cambiarLugares(5,"RESTAR"); 
           mesa5.setIcon(imagenOcupada);
           idNuevasReservadas.add(5);
       }
       else {
           cambiarLugares(5,"SUMAR");
           mesa5.setIcon(imagenLibre);
           idNuevasReservadas.remove(5);
       } 
    }//GEN-LAST:event_mesa5MouseClicked

    private void mesa6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mesa6MouseClicked
       if(mesa6.getIcon().equals(imagenLibre))
       {
           cambiarLugares(6,"RESTAR"); 
           mesa6.setIcon(imagenOcupada);
           idNuevasReservadas.add(6);
       }
       else {
           cambiarLugares(6,"SUMAR");
           mesa6.setIcon(imagenLibre);
           idNuevasReservadas.remove(6);
       } 
    }//GEN-LAST:event_mesa6MouseClicked

    private void mesa7MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mesa7MouseClicked
       if(mesa7.getIcon().equals(imagenLibre))
       {
           cambiarLugares(7,"RESTAR"); 
           mesa7.setIcon(imagenOcupada);
           idNuevasReservadas.add(7);
       }
       else {
           cambiarLugares(7,"SUMAR");
           mesa7.setIcon(imagenLibre);
           idNuevasReservadas.remove(7);
       } 
    }//GEN-LAST:event_mesa7MouseClicked

    private void mesa8MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mesa8MouseClicked
      if(mesa8.getIcon().equals(imagenLibre))
       {
           cambiarLugares(8,"RESTAR"); 
           mesa8.setIcon(imagenOcupada);
           idNuevasReservadas.add(8);
       }
       else {
           cambiarLugares(8,"SUMAR"); 
           mesa8.setIcon(imagenLibre);
           idNuevasReservadas.remove(8);
       } 
    }//GEN-LAST:event_mesa8MouseClicked

    private void mesa9MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mesa9MouseClicked
        if(mesa9.getIcon().equals(imagenLibre))
       {
           cambiarLugares(9,"RESTAR"); 
           mesa9.setIcon(imagenOcupada);
           idNuevasReservadas.add(9);
       }
       else {
            cambiarLugares(9,"SUMAR");
            mesa9.setIcon(imagenLibre);
            idNuevasReservadas.remove(9);
       } 
    }//GEN-LAST:event_mesa9MouseClicked

    private void mesa10MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mesa10MouseClicked
        if(mesa10.getIcon().equals(imagenLibre))
       {
           cambiarLugares(10,"RESTAR"); 
           mesa10.setIcon(imagenOcupada);
           idNuevasReservadas.add(10);
       }
       else {
            cambiarLugares(10,"SUMAR");
            mesa10.setIcon(imagenLibre);
            idNuevasReservadas.remove(10);
       } 
    }//GEN-LAST:event_mesa10MouseClicked

    private void mesa11MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mesa11MouseClicked
        if(mesa11.getIcon().equals(imagenLibre))
       {
           cambiarLugares(11,"RESTAR"); 
           mesa11.setIcon(imagenOcupada);
           idNuevasReservadas.add(11);
       }
       else {
            cambiarLugares(11,"SUMAR");
            mesa11.setIcon(imagenLibre);
            idNuevasReservadas.remove(11);
       } 
    }//GEN-LAST:event_mesa11MouseClicked

    private void mesa12MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mesa12MouseClicked
        if(mesa12.getIcon().equals(imagenLibre))
       {
           cambiarLugares(12,"RESTAR"); 
           mesa12.setIcon(imagenOcupada);
           idNuevasReservadas.add(12);
       }
       else {
           cambiarLugares(12,"SUMAR");
           mesa12.setIcon(imagenLibre);
           idNuevasReservadas.remove(12);
       } 
    }//GEN-LAST:event_mesa12MouseClicked

    private void mesa13MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mesa13MouseClicked
        if(mesa13.getIcon().equals(imagenLibre))
       { 
           cambiarLugares(13,"RESTAR"); 
           mesa13.setIcon(imagenOcupada);
           idNuevasReservadas.add(13);
       }
       else {
           cambiarLugares(13,"SUMAR");
           mesa13.setIcon(imagenLibre);
           idNuevasReservadas.remove(13);
       } 
    }//GEN-LAST:event_mesa13MouseClicked

    private void mesa14MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mesa14MouseClicked
          if(mesa14.getIcon().equals(imagenLibre))
       {
           cambiarLugares(14,"RESTAR"); 
           mesa14.setIcon(imagenOcupada);
           idNuevasReservadas.add(14);
       }
       else {
           cambiarLugares(14,"SUMAR");
           mesa14.setIcon(imagenLibre);
           idNuevasReservadas.remove(14);
       }
    }//GEN-LAST:event_mesa14MouseClicked

    private void mesa15MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mesa15MouseClicked
         if(mesa15.getIcon().equals(imagenLibre))
       {
           cambiarLugares(15,"RESTAR"); 
           mesa15.setIcon(imagenOcupada);
           idNuevasReservadas.add(15);
       }
       else {
           cambiarLugares(15,"SUMAR");
           mesa15.setIcon(imagenLibre);
           idNuevasReservadas.remove(15);
       }
    }//GEN-LAST:event_mesa15MouseClicked

    private void campoFechaKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_campoFechaKeyPressed
        if (evt.getKeyCode() == KeyEvent.VK_ENTER) {   //ACA AL COLOCAR LA CONTRASEÑA Y PULSAR ENTER DEL TECLADO SE ACCEDE PARA ELLO DEBEMOS DECLARAR UN EVENTO.
           this. fecha = LocalDate.parse(campoFecha.getText(), DateTimeFormatter.ofPattern("yyyy-M-d"));
           limpiarMesas();
           cargarReservasDelDia();
        }
    }//GEN-LAST:event_campoFechaKeyPressed

    private void botonConfirmarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonConfirmarActionPerformed
        Mesa mesa;
        Cliente cliente=new Cliente("0");
        int seniaTotal=cantidadLugares *150;
        int seniaPorMesa=0;
        for(int idMesa :idNuevasReservadas)
        {
            mesa=mesaData.buscarMesa(idMesa) ;
            int personas=mesa.getCantidad();
            seniaPorMesa=personas*150;
            seniaTotal-=seniaPorMesa;
            if(seniaTotal>0)
                seniaPorMesa+= seniaTotal;
            Reserva reserva=new Reserva(mesa,cliente,fecha,0,personas,seniaPorMesa,"",false);
            int rta=reservaData.guardarReserva(reserva);
        }
      JOptionPane.showMessageDialog(this, "Mesas reservadas");
    }//GEN-LAST:event_botonConfirmarActionPerformed

    private void botonCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonCancelarActionPerformed
      ArrayList<Reserva>  listaReservasDeMesas=(ArrayList)reservaData.listarReservasPorDni("0");
      int idBorrar=0;
      for(Reserva reservaNueva:listaReservasDeMesas){
         idBorrar=reservaNueva.getId_reserva();
         reservaData.borrarReserva(idBorrar);
      }
        JOptionPane.showMessageDialog(this, "Opeación CANCELADA");  
    }//GEN-LAST:event_botonCancelarActionPerformed

    private void jsPersonasStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_jsPersonasStateChanged
        // TODO add your handling code here:
    }//GEN-LAST:event_jsPersonasStateChanged

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton1ActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ReservacionesMesas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ReservacionesMesas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ReservacionesMesas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ReservacionesMesas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {

            }
        });
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton botonCancelar;
    private javax.swing.JButton botonConfirmar;
    private javax.swing.JButton btnSALIR;
    private javax.swing.JTextField campoFecha;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JSpinner jsPersonas;
    private javax.swing.JLabel label1;
    private javax.swing.JLabel label10;
    private javax.swing.JLabel label101;
    private javax.swing.JLabel label102;
    private javax.swing.JLabel label103;
    private javax.swing.JLabel label104;
    private javax.swing.JLabel label105;
    private javax.swing.JLabel label106;
    private javax.swing.JLabel label107;
    private javax.swing.JLabel label108;
    private javax.swing.JLabel label109;
    private javax.swing.JLabel label11;
    private javax.swing.JLabel label110;
    private javax.swing.JLabel label111;
    private javax.swing.JLabel label112;
    private javax.swing.JLabel label113;
    private javax.swing.JLabel label114;
    private javax.swing.JLabel label115;
    private javax.swing.JLabel label12;
    private javax.swing.JLabel label13;
    private javax.swing.JLabel label14;
    private javax.swing.JLabel label15;
    private javax.swing.JLabel label2;
    private javax.swing.JLabel label3;
    private javax.swing.JLabel label4;
    private javax.swing.JLabel label5;
    private javax.swing.JLabel label6;
    private javax.swing.JLabel label7;
    private javax.swing.JLabel label8;
    private javax.swing.JLabel label9;
    private javax.swing.JLabel labelTitulo;
    private javax.swing.JLabel mesa1;
    private javax.swing.JLabel mesa10;
    private javax.swing.JLabel mesa11;
    private javax.swing.JLabel mesa12;
    private javax.swing.JLabel mesa13;
    private javax.swing.JLabel mesa14;
    private javax.swing.JLabel mesa15;
    private javax.swing.JLabel mesa2;
    private javax.swing.JLabel mesa3;
    private javax.swing.JLabel mesa4;
    private javax.swing.JLabel mesa5;
    private javax.swing.JLabel mesa6;
    private javax.swing.JLabel mesa7;
    private javax.swing.JLabel mesa8;
    private javax.swing.JLabel mesa9;
    // End of variables declaration//GEN-END:variables

}
