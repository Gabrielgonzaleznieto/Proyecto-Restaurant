package vistas;

import java.awt.Toolkit;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.ImageIcon;

/**
 *
 * @author gabriel gonzalez
 */
public class ReservacionesRegistro extends javax.swing.JFrame {

    boolean opc = true;
//    ConsultaMesasAcargo mes = new ConsultaMesasAcargo();
    ReservacionesABM reservacionesABM = new ReservacionesABM();
    ReservacionesListados reservacionesListados = new ReservacionesListados();
  
    private SimpleDateFormat f;

    public ReservacionesRegistro() {

        initComponents();
        this.setLocationRelativeTo(null);
        Toolkit lo = Toolkit.getDefaultToolkit();                                          //AQUI LE DOY UN ICONO AL PROGRAMA.
        setIconImage(lo.getImage(getClass().getResource("/Imagenes/Portada.jpg")));       //AQUI LE DOY UN ICONO AL PROGRAMA.

    }

 
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnReservacionesABM = new javax.swing.JButton();
        btnAsignarMesa = new javax.swing.JButton();
        btnMesasDisponibles = new javax.swing.JButton();
        btnSalir = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        btnReservasListados = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnReservacionesABM.setBackground(new java.awt.Color(227, 227, 227));
        btnReservacionesABM.setFont(new java.awt.Font("Segoe UI Black", 1, 20)); // NOI18N
        btnReservacionesABM.setText("ABM RESERVACIONES");
        btnReservacionesABM.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnReservacionesABM.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnReservacionesABMActionPerformed(evt);
            }
        });
        getContentPane().add(btnReservacionesABM, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 150, 380, 90));

        btnAsignarMesa.setBackground(new java.awt.Color(227, 227, 227));
        btnAsignarMesa.setFont(new java.awt.Font("Segoe UI Black", 1, 20)); // NOI18N
        btnAsignarMesa.setText("MESAS A CARGO");
        btnAsignarMesa.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnAsignarMesa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAsignarMesaActionPerformed(evt);
            }
        });
        getContentPane().add(btnAsignarMesa, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 150, 380, 90));

        btnMesasDisponibles.setBackground(new java.awt.Color(227, 227, 227));
        btnMesasDisponibles.setFont(new java.awt.Font("Segoe UI Black", 1, 20)); // NOI18N
        btnMesasDisponibles.setText("CONSULTA MESAS DISPONIBLES");
        btnMesasDisponibles.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnMesasDisponibles.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMesasDisponiblesActionPerformed(evt);
            }
        });
        getContentPane().add(btnMesasDisponibles, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 280, 380, 100));

        btnSalir.setFont(new java.awt.Font("Segoe UI Black", 1, 20)); // NOI18N
        btnSalir.setText("SALIR");
        btnSalir.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalirActionPerformed(evt);
            }
        });
        getContentPane().add(btnSalir, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 460, 300, 70));

        jLabel1.setFont(new java.awt.Font("Segoe Script", 1, 35)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(102, 102, 102));
        jLabel1.setText("RESERVACION DE MESAS:");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 60, 540, 50));

        btnReservasListados.setBackground(new java.awt.Color(227, 227, 227));
        btnReservasListados.setFont(new java.awt.Font("Segoe UI Black", 0, 20)); // NOI18N
        btnReservasListados.setText("LISTADOS RESERVACIONES");
        btnReservasListados.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnReservasListados.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnReservasListadosActionPerformed(evt);
            }
        });
        getContentPane().add(btnReservasListados, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 280, 380, 100));

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/FondoM.png"))); // NOI18N
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1100, 580));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalirActionPerformed
      dispose();
    }//GEN-LAST:event_btnSalirActionPerformed

    private void btnReservacionesABMActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnReservacionesABMActionPerformed
     
        if (opc == true) {
            reservacionesABM.setVisible(true);
            opc = false;
        } else {
            reservacionesABM.dispose();
            opc = true;
            reservacionesABM.setVisible(true);
        }

    }//GEN-LAST:event_btnReservacionesABMActionPerformed

    private void btnAsignarMesaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAsignarMesaActionPerformed
     
//        if (opc == true) {
//            mes.setVisible(true);
//            opc = false;
//        } else {
//            mes.dispose();
//            opc = true;
//            mes.setVisible(true);
//        }
//    
    }//GEN-LAST:event_btnAsignarMesaActionPerformed

    private void btnMesasDisponiblesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMesasDisponiblesActionPerformed
//        f = new SimpleDateFormat("yyyy-MM-dd"); //FECHA
//        String b = f.format(new Date()); //depende de donde se quiera visualizar
//        MesasDisponibles map = new MesasDisponibles(b);
//        map.setVisible(true);


    }//GEN-LAST:event_btnMesasDisponiblesActionPerformed

    private void btnReservasListadosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnReservasListadosActionPerformed
//        if (opc == true) {
//            reservacionesListados.setVisible(true);
//            opc = false;
//        } else {
//            reservacionesListados.dispose();
//            opc = true;
//            reservacionesListados.setVisible(true);
//        }
        
    }//GEN-LAST:event_btnReservasListadosActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ReservacionesRegistro.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ReservacionesRegistro.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ReservacionesRegistro.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ReservacionesRegistro.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ReservacionesRegistro().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAsignarMesa;
    private javax.swing.JButton btnMesasDisponibles;
    private javax.swing.JButton btnReservacionesABM;
    private javax.swing.JButton btnReservasListados;
    private javax.swing.JButton btnSalir;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    // End of variables declaration//GEN-END:variables
}
